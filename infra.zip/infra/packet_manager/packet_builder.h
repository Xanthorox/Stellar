#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/packet.h"

/*
 * tcp_seq: the sequence number of the new TCP packet (in host byte order)
 * tcp_ack: the acknowledgment number of the new TCP packet (in host byte order)
 * tcp_options_len: the length of the options (must be a multiple of 4)
 */
struct packet *packet_build_tcp(const struct packet *origin_pkt, uint32_t tcp_seq, uint32_t tcp_ack, uint8_t tcp_flags,
                                const char *tcp_options, uint16_t tcp_options_len,
                                const char *tcp_payload, uint16_t tcp_payload_len);
struct packet *packet_build_udp(const struct packet *origin_pkt, const char *udp_payload, uint16_t udp_payload_len);
struct packet *packet_build_l3(const struct packet *origin_pkt, uint8_t ip_proto, const char *l3_payload, uint16_t l3_payload_len);

#ifdef __cplusplus
}
#endif
