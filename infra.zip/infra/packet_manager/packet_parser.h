#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/packet.h"

const char *packet_parse(struct packet *pkt, const char *data, uint16_t len);
const char *layer_proto_to_str(enum layer_proto proto);

#ifdef __cplusplus
}
#endif
