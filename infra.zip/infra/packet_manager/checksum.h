#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>
#include <arpa/inet.h>

uint16_t checksum(const void *data, int len);
uint16_t checksum_v4(const void *l4_hdr_ptr, uint16_t l4_total_len, uint8_t l4_proto, struct in_addr *src_addr, struct in_addr *dst_addr);
uint16_t checksum_v6(const void *l4_hdr_ptr, uint16_t l4_total_len, uint8_t l4_proto, struct in6_addr *src_addr, struct in6_addr *dst_addr);

#ifdef __cplusplus
}
#endif
