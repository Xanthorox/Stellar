#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/packet.h"

// Duplicated Packet Filter for IPv4 Packet
struct packet_dabloom;
struct packet_dabloom *packet_dabloom_new(uint32_t capacity, uint32_t timeout, double error_rate, uint64_t now);
void packet_dabloom_free(struct packet_dabloom *pkt_dab);

// return 1: found
// reutrn 0: no found
int packet_dabloom_lookup(struct packet_dabloom *pkt_dab, const struct packet *pkt, uint64_t now);
void packet_dabloom_add(struct packet_dabloom *pkt_dab, const struct packet *pkt, uint64_t now);

#ifdef __cplusplus
}
#endif
