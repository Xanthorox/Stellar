#include <gtest/gtest.h>

#include "packet_helper.h"

/*
 * Transmission Control Protocol, Src Port: 55555, Dst Port: 40856, Seq: 0, Ack: 1, Len: 0
 *     Source Port: 55555
 *     Destination Port: 40856
 *     [Stream index: 0]
 *     [Conversation completeness: Complete, WITH_DATA (31)]
 *     [TCP Segment Len: 0]
 *     Sequence Number: 0    (relative sequence number)
 *     Sequence Number (raw): 3965699644
 *     [Next Sequence Number: 1    (relative sequence number)]
 *     Acknowledgment Number: 1    (relative ack number)
 *     Acknowledgment number (raw): 991053714
 *     1010 .... = Header Length: 40 bytes (10)
 *     Flags: 0x012 (SYN, ACK)
 *         000. .... .... = Reserved: Not set
 *         ...0 .... .... = Accurate ECN: Not set
 *         .... 0... .... = Congestion Window Reduced: Not set
 *         .... .0.. .... = ECN-Echo: Not set
 *         .... ..0. .... = Urgent: Not set
 *         .... ...1 .... = Acknowledgment: Set
 *         .... .... 0... = Push: Not set
 *         .... .... .0.. = Reset: Not set
 *         .... .... ..1. = Syn: Set
 *             [Expert Info (Chat/Sequence): Connection establish acknowledge (SYN+ACK): server port 55555]
 *                 [Connection establish acknowledge (SYN+ACK): server port 55555]
 *                 [Severity level: Chat]
 *                 [Group: Sequence]
 *         .... .... ...0 = Fin: Not set
 *         [TCP Flags: ·······A··S·]
 *     Window: 43690
 *     [Calculated window size: 43690]
 *     Checksum: 0xfe30 incorrect, should be 0x65c9(maybe caused by "TCP checksum offload"?)
 *         [Expert Info (Error/Checksum): Bad checksum [should be 0x65c9]]
 *             [Bad checksum [should be 0x65c9]]
 *             [Severity level: Error]
 *             [Group: Checksum]
 *     [Checksum Status: Bad]
 *     [Calculated Checksum: 0x65c9]
 *     Urgent Pointer: 0
 *     Options: (20 bytes), Maximum segment size, SACK permitted, Timestamps, No-Operation (NOP), Window scale
 *         TCP Option - Maximum segment size: 65495 bytes
 *             Kind: Maximum Segment Size (2)
 *             Length: 4
 *             MSS Value: 65495
 *         TCP Option - SACK permitted
 *             Kind: SACK Permitted (4)
 *             Length: 2
 *         TCP Option - Timestamps
 *             Kind: Time Stamp Option (8)
 *             Length: 10
 *             Timestamp value: 2767168460: TSval 2767168460, TSecr 2767168460
 *             Timestamp echo reply: 2767168460
 *         TCP Option - No-Operation (NOP)
 *             Kind: No-Operation (1)
 *         TCP Option - Window scale: 7 (multiply by 128)
 *             Kind: Window Scale (3)
 *             Length: 3
 *             Shift count: 7
 *             [Multiplier: 128]
 *     [Timestamps]
 *         [Time since first frame in this TCP stream: 475471172.552028000 seconds]
 *         [Time since previous frame in this TCP stream: 475471172.552028000 seconds]
 *     [SEQ/ACK analysis]
 *         [This is an ACK to the segment in frame: 1]
 *         [The RTT to ACK the segment was: 475471172.552028000 seconds]
 *         [iRTT: 0.000039000 seconds]
 */

unsigned char data[] = {
    0xd9, 0x03, 0x9f, 0x98, 0xec, 0x5f, 0xc6, 0x3c, 0x3b, 0x12, 0x47, 0x92, 0xa0, 0x12, 0xaa, 0xaa, 0xfe, 0x30, 0x00, 0x00, 0x02, 0x04, 0xff, 0xd7, 0x04, 0x02,
    0x08, 0x0a, 0xa4, 0xef, 0xa3, 0xcc, 0xa4, 0xef, 0xa3, 0xcc, 0x01, 0x03, 0x03, 0x07};

TEST(TCP_UTILS, GET)
{
    const struct tcphdr *hdr = (struct tcphdr *)data;
    EXPECT_TRUE(tcp_hdr_get_src_port(hdr) == 55555);
    EXPECT_TRUE(tcp_hdr_get_dst_port(hdr) == 40856);
    EXPECT_TRUE(tcp_hdr_get_seq(hdr) == 3965699644);
    EXPECT_TRUE(tcp_hdr_get_ack(hdr) == 991053714);
    EXPECT_TRUE(tcp_hdr_get_hdr_len(hdr) == 40);
    EXPECT_TRUE(tcp_hdr_get_flags(hdr) == 0x012);
    EXPECT_TRUE(tcp_hdr_get_urg_flag(hdr) == false);
    EXPECT_TRUE(tcp_hdr_get_ack_flag(hdr) == true);
    EXPECT_TRUE(tcp_hdr_get_push_flag(hdr) == false);
    EXPECT_TRUE(tcp_hdr_get_rst_flag(hdr) == false);
    EXPECT_TRUE(tcp_hdr_get_syn_flag(hdr) == true);
    EXPECT_TRUE(tcp_hdr_get_fin_flag(hdr) == false);
    EXPECT_TRUE(tcp_hdr_get_window(hdr) == 43690);
    EXPECT_TRUE(tcp_hdr_get_checksum(hdr) == 0xfe30);
    EXPECT_TRUE(tcp_hdr_get_urg_ptr(hdr) == 0);
    EXPECT_TRUE(tcp_hdr_get_opt_len(hdr) == 20);
    EXPECT_TRUE(tcp_hdr_get_opt_data(hdr) == (const char *)(data + 20));
}

TEST(TCP_UTILS, SET1)
{
    char buff[40] = {0};

    struct tcphdr *hdr = (struct tcphdr *)buff;
    tcp_hdr_set_src_port(hdr, 55555);
    tcp_hdr_set_dst_port(hdr, 40856);
    tcp_hdr_set_seq(hdr, 3965699644);
    tcp_hdr_set_ack(hdr, 991053714);
    tcp_hdr_set_hdr_len(hdr, 40);
    tcp_hdr_set_flags(hdr, 0x012);
    tcp_hdr_set_window(hdr, 43690);
    tcp_hdr_set_checksum(hdr, 0xfe30);
    tcp_hdr_set_urg_ptr(hdr, 0);
    tcp_hdr_set_opt_len(hdr, 20);
    tcp_hdr_set_opt_data(hdr, (const char *)(data + 20));

    EXPECT_TRUE(memcmp(buff, data, 40) == 0);
}

TEST(TCP_UTILS, SET2)
{
    char buff[40] = {0};

    struct tcphdr *hdr = (struct tcphdr *)buff;
    tcp_hdr_set_src_port(hdr, 55555);
    tcp_hdr_set_dst_port(hdr, 40856);
    tcp_hdr_set_seq(hdr, 3965699644);
    tcp_hdr_set_ack(hdr, 991053714);
    tcp_hdr_set_hdr_len(hdr, 40);
    tcp_hdr_set_urg_flag(hdr, false);
    tcp_hdr_set_ack_flag(hdr, true);
    tcp_hdr_set_push_flag(hdr, false);
    tcp_hdr_set_rst_flag(hdr, false);
    tcp_hdr_set_syn_flag(hdr, true);
    tcp_hdr_set_fin_flag(hdr, false);
    tcp_hdr_set_window(hdr, 43690);
    tcp_hdr_set_checksum(hdr, 0xfe30);
    tcp_hdr_set_urg_ptr(hdr, 0);
    tcp_hdr_set_opt_len(hdr, 20);
    tcp_hdr_set_opt_data(hdr, (const char *)(data + 20));

    EXPECT_TRUE(memcmp(buff, data, 40) == 0);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
