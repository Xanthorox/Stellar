#include <gtest/gtest.h>
#include <arpa/inet.h>

#include "checksum.h"
#include "packet_helper.h"
#include "packet_internal.h"
#include "packet_dump.h"
#include "packet_parser.h"
#include "packet_builder.h"

#define PRINT_GREEN(fmt, ...) printf("\033[0;32m" fmt "\033[0m\n", ##__VA_ARGS__)
#define PRINT_RED(fmt, ...) printf("\033[0;31m" fmt "\033[0m\n", ##__VA_ARGS__)

// https://dox.ipxe.org/tcp_8h_source.html
#define TCP_OPTION_TS 8
#define TCP_OPTION_NOP 1
struct tcp_timestamp_option
{
	uint8_t kind;
	uint8_t length;
	uint32_t tsval;
	uint32_t tsecr;
} __attribute__((packed));

struct tcp_timestamp_padded_option
{
	uint8_t nop[2];
	struct tcp_timestamp_option tsopt;
} __attribute__((packed));

struct tcp_timestamp_padded_option ts_pad_opt =
	{
		.nop = {TCP_OPTION_NOP, TCP_OPTION_NOP},
		.tsopt = {
			.kind = TCP_OPTION_TS,
			.length = 10,
			.tsval = 0x12345678,
			.tsecr = 0x87654321,
		},
};

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:tcp]
 ******************************************************************************
 *
 * Frame 1: 60 bytes on wire (480 bits), 60 bytes captured (480 bits)
 * Ethernet II, Src: 52:54:00:94:27:9b (52:54:00:94:27:9b), Dst: 52:54:00:19:8f:63 (52:54:00:19:8f:63)
 *     Destination: 52:54:00:19:8f:63 (52:54:00:19:8f:63)
 *     Source: 52:54:00:94:27:9b (52:54:00:94:27:9b)
 *     Type: IPv4 (0x0800)
 *     Padding: 000000000000
 * Internet Protocol Version 4, Src: 192.168.122.202, Dst: 192.168.122.100
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 40
 *     Identification: 0x0c5e (3166)
 *     010. .... = Flags: 0x2, Don't fragment
 *         0... .... = Reserved bit: Not set
 *         .1.. .... = Don't fragment: Set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 64
 *     Protocol: TCP (6)
 *     Header Checksum: 0xb7f2 [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0xb7f2]
 *     Source Address: 192.168.122.202
 *     Destination Address: 192.168.122.100
 * Transmission Control Protocol, Src Port: 1080, Dst Port: 62395, Seq: 1457975085, Ack: 1047768425, Len: 0
 *     Source Port: 1080
 *     Destination Port: 62395
 *     [Stream index: 0]
 *     [Conversation completeness: Incomplete (4)]
 *         ..0. .... = RST: Absent
 *         ...0 .... = FIN: Absent
 *         .... 0... = Data: Absent
 *         .... .1.. = ACK: Present
 *         .... ..0. = SYN-ACK: Absent
 *         .... ...0 = SYN: Absent
 *         [Completeness Flags: ···A··]
 *     [TCP Segment Len: 0]
 *     Sequence Number: 1457975085
 *     [Next Sequence Number: 1457975085]
 *     Acknowledgment Number: 1047768425
 *     0101 .... = Header Length: 20 bytes (5)
 *     Flags: 0x010 (ACK)
 *         000. .... .... = Reserved: Not set
 *         ...0 .... .... = Accurate ECN: Not set
 *         .... 0... .... = Congestion Window Reduced: Not set
 *         .... .0.. .... = ECN-Echo: Not set
 *         .... ..0. .... = Urgent: Not set
 *         .... ...1 .... = Acknowledgment: Set
 *         .... .... 0... = Push: Not set
 *         .... .... .0.. = Reset: Not set
 *         .... .... ..0. = Syn: Not set
 *         .... .... ...0 = Fin: Not set
 *         [TCP Flags: ·······A····]
 *     Window: 457
 *     [Calculated window size: 457]
 *     [Window size scaling factor: -1 (unknown)]
 *     Checksum: 0x0da7 [correct]
 *         [Calculated Checksum: 0x0da7]
 *     [Checksum Status: Good]
 *     Urgent Pointer: 0
 *     [Timestamps]
 *         [Time since first frame in this TCP stream: 0.000000000 seconds]
 *         [Time since previous frame in this TCP stream: 0.000000000 seconds]
 */

unsigned char data1[] = {
	0x52, 0x54, 0x00, 0x19, 0x8f, 0x63, 0x52, 0x54, 0x00, 0x94, 0x27, 0x9b, 0x08, 0x00, 0x45, 0x00, 0x00, 0x28, 0x0c, 0x5e, 0x40, 0x00, 0x40, 0x06, 0xb7, 0xf2,
	0xc0, 0xa8, 0x7a, 0xca, 0xc0, 0xa8, 0x7a, 0x64, 0x04, 0x38, 0xf3, 0xbb, 0x56, 0xe6, 0xef, 0x2d, 0x3e, 0x73, 0xad, 0x69, 0x50, 0x10, 0x01, 0xc9, 0x0d, 0xa7,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

/*
 * packet_build_tcp()
 * 	-> ETH->IPv4->TCP
 *	-> with TCP options
 *	-> with TCP payload
 */
#if 1
TEST(PACKET_BUILD_TCP, ETH_IP4_TCP)
{
	struct packet orig_pkt;
	memset(&orig_pkt, 0, sizeof(orig_pkt));
	packet_parse(&orig_pkt, (const char *)data1, sizeof(data1));
	PRINT_GREEN("origin packet:");
	packet_print(&orig_pkt);

	struct packet *new_pkt = packet_build_tcp(&orig_pkt, 1, 2, TH_ACK, (const char *)&ts_pad_opt, sizeof(ts_pad_opt), "Hello", 5);
	EXPECT_TRUE(new_pkt != nullptr);
	PRINT_GREEN("new packet:");
	packet_print(new_pkt);

	packet_dump_hex(new_pkt, STDOUT_FILENO);
	packet_dump_pcap(new_pkt, "craft-eth-ipv4-tcp.pcap");

	const char *orig_pkt_data = packet_get_raw_data(&orig_pkt);
	uint16_t orig_pkt_len = packet_get_raw_len(&orig_pkt);

	const char *new_pkt_data = packet_get_raw_data(new_pkt);
	uint16_t new_pkt_len = packet_get_raw_len(new_pkt);

	EXPECT_TRUE(orig_pkt_len - 6 ==	   // trim Eth padding: 000000000000
				new_pkt_len - 12 - 5); // trim TCP options, TCP payload
	int count = packet_get_layer_count(new_pkt);
	for (int i = 0; i < count; i++)
	{
		const struct layer *layer = packet_get_layer_by_idx(new_pkt, i);
		if (layer->proto == LAYER_PROTO_IPV4)
		{
			const struct ip *ip = (const struct ip *)layer->hdr.raw;
			EXPECT_TRUE(ip4_hdr_get_total_len(ip) == 57);
			EXPECT_TRUE(ip4_hdr_get_checksum(ip) == 0xb7e1);
			break;
		}
		if (layer->proto == LAYER_PROTO_TCP)
		{
			const struct tcphdr *tcp = (const struct tcphdr *)layer->hdr.raw;
			EXPECT_TRUE(tcp_hdr_get_seq(tcp) == 1);
			EXPECT_TRUE(tcp_hdr_get_ack(tcp) == 2);
			EXPECT_TRUE(tcp_hdr_get_flags(tcp) == TH_ACK);
			EXPECT_TRUE(tcp_hdr_get_hdr_len(tcp) == 32);
			EXPECT_TRUE(tcp_hdr_get_checksum(tcp) == 0xaf73);
			break;
		}
	}
	for (uint16_t i = 0; i < new_pkt_len - 12 - 5; i++)
	{
		if ((16 <= i && i <= 17) || // skip IPv4 total length
			(24 <= i && i <= 25))	// skip IPv4 checksum
		{
			continue;
		}
		if ((38 <= i && i <= 41) || // skip TCP seq
			(42 <= i && i <= 45) || // skip TCP ack
			i == 46 ||				// skip TCP data offset
			i == 47 ||				// skip TCP flags
			(50 <= i && i <= 51))	// skip TCP checksum
		{
			continue;
		}

		// printf(("idx: %d, orig: %02x, new: %02x\n"), i, orig_pkt_data[i], new_pkt_data[i]);
		EXPECT_TRUE(orig_pkt_data[i] == new_pkt_data[i]);
	}

	packet_free(new_pkt);
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:ipv6:tcp]
 ******************************************************************************
 *
 * Frame 1: 106 bytes on wire (848 bits), 106 bytes captured (848 bits)
 * Ethernet II, Src: JuniperN_45:88:29 (2c:6b:f5:45:88:29), Dst: JuniperN_2a:a2:00 (5c:5e:ab:2a:a2:00)
 *  Destination: JuniperN_2a:a2:00 (5c:5e:ab:2a:a2:00)
 *  Source: JuniperN_45:88:29 (2c:6b:f5:45:88:29)
 *  Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 210.77.88.163, Dst: 59.66.4.50
 *  0100 .... = Version: 4
 *  .... 0101 = Header Length: 20 bytes (5)
 *  Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *  Total Length: 92
 *  Identification: 0x0b4d (2893)
 *  000. .... = Flags: 0x0
 *  ...0 0000 0000 0000 = Fragment Offset: 0
 *  Time to Live: 59
 *  Protocol: IPv6 (41)
 *  Header Checksum: 0x09c8 [validation disabled]
 *  [Header checksum status: Unverified]
 *  Source Address: 210.77.88.163
 *  Destination Address: 59.66.4.50
 * Internet Protocol Version 6, Src: 2001:da8:200:900e:200:5efe:d24d:58a3, Dst: 2600:140e:6::1702:1058
 *  0110 .... = Version: 6
 *  .... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *  .... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 *  Payload Length: 32
 *  Next Header: TCP (6)
 *  Hop Limit: 64
 *  Source Address: 2001:da8:200:900e:200:5efe:d24d:58a3
 *  Destination Address: 2600:140e:6::1702:1058
 *  [Source ISATAP IPv4: 210.77.88.163]
 * Transmission Control Protocol, Src Port: 52556, Dst Port: 80, Seq: 0, Len: 0
 *  Source Port: 52556
 *  Destination Port: 80
 *  [Stream index: 0]
 *  [Conversation completeness: Complete, WITH_DATA (31)]
 *  [TCP Segment Len: 0]
 *  Sequence Number: 0    (relative sequence number)
 *  Sequence Number (raw): 2172673142
 *  [Next Sequence Number: 1    (relative sequence number)]
 *  Acknowledgment Number: 0
 *  Acknowledgment number (raw): 0
 *  1000 .... = Header Length: 32 bytes (8)
 *  Flags: 0x002 (SYN)
 *  Window: 8192
 *  [Calculated window size: 8192]
 *  Checksum: 0xf757 [unverified]
 *  [Checksum Status: Unverified]
 *  Urgent Pointer: 0
 *  Options: (12 bytes), Maximum segment size, No-Operation (NOP), Window scale, No-Operation (NOP), No-Operation (NOP), SACK permitted
 *  [Timestamps]
 */

unsigned char data2[] = {
	0x5c, 0x5e, 0xab, 0x2a, 0xa2, 0x00, 0x2c, 0x6b, 0xf5, 0x45, 0x88, 0x29, 0x08, 0x00, 0x45, 0x00, 0x00, 0x5c, 0x0b, 0x4d, 0x00, 0x00, 0x3b, 0x29, 0x09, 0xc8,
	0xd2, 0x4d, 0x58, 0xa3, 0x3b, 0x42, 0x04, 0x32, 0x60, 0x00, 0x00, 0x00, 0x00, 0x20, 0x06, 0x40, 0x20, 0x01, 0x0d, 0xa8, 0x02, 0x00, 0x90, 0x0e, 0x02, 0x00,
	0x5e, 0xfe, 0xd2, 0x4d, 0x58, 0xa3, 0x26, 0x00, 0x14, 0x0e, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17, 0x02, 0x10, 0x58, 0xcd, 0x4c, 0x00, 0x50,
	0x81, 0x80, 0x5c, 0x76, 0x00, 0x00, 0x00, 0x00, 0x80, 0x02, 0x20, 0x00, 0xf7, 0x57, 0x00, 0x00, 0x02, 0x04, 0x04, 0xc4, 0x01, 0x03, 0x03, 0x08, 0x01, 0x01,
	0x04, 0x02};

/*
 * packet_build_tcp()
 * 	-> ETH->IPv4->IPv6->TCP
 *	-> with TCP payload
 */
#if 1
TEST(PACKET_BUILD_TCP, ETH_IP4_IP6_TCP)
{
	struct packet orig_pkt;
	memset(&orig_pkt, 0, sizeof(orig_pkt));
	packet_parse(&orig_pkt, (const char *)data2, sizeof(data2));
	PRINT_GREEN("origin packet:");
	packet_print(&orig_pkt);

	struct packet *new_pkt = packet_build_tcp(&orig_pkt, 1234, 2345, TH_ACK, NULL, 0, "Hello", 5);
	EXPECT_TRUE(new_pkt != nullptr);
	PRINT_GREEN("new packet:");
	packet_print(new_pkt);

	packet_dump_hex(new_pkt, STDOUT_FILENO);
	packet_dump_pcap(new_pkt, "craft-eth-ipv4-ipv6-tcp.pcap");

	const char *orig_pkt_data = packet_get_raw_data(&orig_pkt);
	uint16_t orig_pkt_len = packet_get_raw_len(&orig_pkt);

	const char *new_pkt_data = packet_get_raw_data(new_pkt);
	uint16_t new_pkt_len = packet_get_raw_len(new_pkt);

	EXPECT_TRUE(orig_pkt_len - 12 == // trim TCP options
				new_pkt_len - 5);	 // trim TCP payload
	int count = packet_get_layer_count(new_pkt);
	for (int i = 0; i < count; i++)
	{
		const struct layer *layer = packet_get_layer_by_idx(new_pkt, i);
		if (layer->proto == LAYER_PROTO_IPV4)
		{
			const struct ip *ip = (const struct ip *)layer->hdr.raw;
			EXPECT_TRUE(ip4_hdr_get_total_len(ip) == 85);
			EXPECT_TRUE(ip4_hdr_get_checksum(ip) == 0x09cf);
			break;
		}
		if (layer->proto == LAYER_PROTO_IPV6)
		{
			const struct ip6_hdr *ip6 = (const struct ip6_hdr *)layer->hdr.raw;
			EXPECT_TRUE(ip6_hdr_get_payload_len(ip6) == 25);
			break;
		}
		if (layer->proto == LAYER_PROTO_TCP)
		{
			const struct tcphdr *tcp = (const struct tcphdr *)layer->hdr.raw;
			EXPECT_TRUE(tcp_hdr_get_seq(tcp) == 1234);
			EXPECT_TRUE(tcp_hdr_get_ack(tcp) == 2345);
			EXPECT_TRUE(tcp_hdr_get_flags(tcp) == TH_ACK);
			EXPECT_TRUE(tcp_hdr_get_hdr_len(tcp) == 20);
			EXPECT_TRUE(tcp_hdr_get_checksum(tcp) == 0xe350);
			break;
		}
	}
	for (uint16_t i = 0; i < new_pkt_len - 5; i++)
	{
		if ((16 <= i && i <= 17) || // skip IPv4 total length
			(24 <= i && i <= 25))	// skip IPv4 checksum
		{
			continue;
		}
		if (38 <= i && i <= 39) // skip IPv6 payload length
		{
			continue;
		}
		if ((78 <= i && i <= 81) || // skip TCP seq
			(82 <= i && i <= 85) || // skip TCP ack
			i == 86 ||				// skip TCP data offset
			i == 87 ||				// skip TCP flags
			(90 <= i && i <= 91))	// skip TCP checksum
		{
			continue;
		}

		// printf(("idx: %d, orig: %02x, new: %02x\n"), i, orig_pkt_data[i], new_pkt_data[i]);
		EXPECT_TRUE(orig_pkt_data[i] == new_pkt_data[i]);
	}

	packet_free(new_pkt);
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ipv6:udp:gtp:ip:tcp:ja3:tls]
 ******************************************************************************
 *
 * Frame 1: 1470 bytes on wire (11760 bits), 1470 bytes captured (11760 bits)
 * Ethernet II, Src: HuaweiTe_62:ee:70 (60:d7:55:62:ee:70), Dst: zte_0e:f5:1c (74:4a:a4:0e:f5:1c)
 *  Destination: zte_0e:f5:1c (74:4a:a4:0e:f5:1c)
 *  Source: HuaweiTe_62:ee:70 (60:d7:55:62:ee:70)
 *  Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2409:8034:4025::50:a31, Dst: 2409:8034:4040:5301::204
 *  0110 .... = Version: 6
 *  .... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *  .... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 *  Payload Length: 1416
 *  Next Header: UDP (17)
 *  Hop Limit: 252
 *  Source Address: 2409:8034:4025::50:a31
 *  Destination Address: 2409:8034:4040:5301::204
 * User Datagram Protocol, Src Port: 2152, Dst Port: 2152
 *  Source Port: 2152
 *  Destination Port: 2152
 *  Length: 1416
 *  Checksum: 0xc8df [unverified]
 *  [Checksum Status: Unverified]
 *  [Stream index: 0]
 *  [Timestamps]
 *  UDP payload (1408 bytes)
 * GPRS Tunneling Protocol
 *  Flags: 0x30
 *  Message Type: T-PDU (0xff)
 *  Length: 1400
 *  TEID: 0x6c2a4753 (1814710099)
 * Internet Protocol Version 4, Src: 10.49.115.138, Dst: 121.196.250.66
 *  0100 .... = Version: 4
 *  .... 0101 = Header Length: 20 bytes (5)
 *  Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *  Total Length: 1400
 *  Identification: 0x0003 (3)
 *  010. .... = Flags: 0x2, Don't fragment
 *  ...0 0000 0000 0000 = Fragment Offset: 0
 *  Time to Live: 64
 *  Protocol: TCP (6)
 *  Header Checksum: 0x43bb [validation disabled]
 *  [Header checksum status: Unverified]
 *  Source Address: 10.49.115.138
 *  Destination Address: 121.196.250.66
 * Transmission Control Protocol, Src Port: 50081, Dst Port: 443, Seq: 1, Ack: 1, Len: 1348
 *  Source Port: 50081
 *  Destination Port: 443
 *  [Stream index: 0]
 *  [Conversation completeness: Incomplete (8)]
 *  [TCP Segment Len: 1348]
 *  Sequence Number: 1    (relative sequence number)
 *  Sequence Number (raw): 1522577104
 *  [Next Sequence Number: 1349    (relative sequence number)]
 *  Acknowledgment Number: 1    (relative ack number)
 *  Acknowledgment number (raw): 3419365570
 *  1000 .... = Header Length: 32 bytes (8)
 *  Flags: 0x010 (ACK)
 *  Window: 2038
 *  [Calculated window size: 2038]
 *  [Window size scaling factor: -1 (unknown)]
 *  Checksum: 0xd3c2 [unverified]
 *  [Checksum Status: Unverified]
 *  Urgent Pointer: 0
 *  Options: (12 bytes), No-Operation (NOP), No-Operation (NOP), Timestamps
 *  [Timestamps]
 *  [SEQ/ACK analysis]
 *  TCP payload (1348 bytes)
 * Transport Layer Security
 */

unsigned char data3[] = {
	0x74, 0x4a, 0xa4, 0x0e, 0xf5, 0x1c, 0x60, 0xd7, 0x55, 0x62, 0xee, 0x70, 0x86, 0xdd, 0x60, 0x00, 0x00, 0x00, 0x05, 0x88, 0x11, 0xfc, 0x24, 0x09, 0x80, 0x34,
	0x40, 0x25, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x0a, 0x31, 0x24, 0x09, 0x80, 0x34, 0x40, 0x40, 0x53, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x02, 0x04, 0x08, 0x68, 0x08, 0x68, 0x05, 0x88, 0xc8, 0xdf, 0x30, 0xff, 0x05, 0x78, 0x6c, 0x2a, 0x47, 0x53, 0x45, 0x00, 0x05, 0x78, 0x00, 0x03, 0x40, 0x00,
	0x40, 0x06, 0x43, 0xbb, 0x0a, 0x31, 0x73, 0x8a, 0x79, 0xc4, 0xfa, 0x42, 0xc3, 0xa1, 0x01, 0xbb, 0x5a, 0xc0, 0xae, 0xd0, 0xcb, 0xcf, 0x60, 0xc2, 0x80, 0x10,
	0x07, 0xf6, 0xd3, 0xc2, 0x00, 0x00, 0x01, 0x01, 0x08, 0x0a, 0x85, 0x14, 0x0e, 0xb0, 0xcc, 0x45, 0xf8, 0x5f, 0xef, 0x49, 0x45, 0xa0, 0xbe, 0x21, 0xd6, 0x46,
	0x9f, 0xb5, 0x17, 0xb2, 0xfe, 0x61, 0x2d, 0xed, 0x4f, 0x0c, 0x1e, 0xb5, 0xda, 0x91, 0x40, 0x87, 0xab, 0x02, 0x0d, 0x01, 0xc8, 0xf1, 0x24, 0x05, 0x8a, 0x9d,
	0x8d, 0xfc, 0xbb, 0x82, 0x24, 0xf5, 0x7d, 0x2d, 0x10, 0x66, 0x30, 0x2a, 0xaa, 0x4a, 0x51, 0x8d, 0xe9, 0x9a, 0x65, 0xcf, 0x89, 0x0c, 0x9e, 0x0d, 0x82, 0xda,
	0x5e, 0xd3, 0x98, 0xe3, 0x23, 0xf7, 0x5a, 0xd4, 0x88, 0x94, 0xd2, 0xdf, 0xbe, 0x44, 0x20, 0x2b, 0x21, 0x2d, 0x38, 0xca, 0x29, 0x5e, 0xa3, 0xb7, 0xbb, 0x34,
	0x20, 0x42, 0x02, 0x71, 0x04, 0xda, 0xd2, 0xeb, 0xb8, 0x81, 0xa3, 0x48, 0xc8, 0x54, 0xad, 0x42, 0x35, 0xc4, 0x4f, 0x6b, 0x15, 0x50, 0x22, 0x3e, 0x26, 0xb3,
	0xfc, 0x30, 0x49, 0x71, 0x6f, 0x41, 0x66, 0xa2, 0x2e, 0xe9, 0xd3, 0x1a, 0x69, 0xa8, 0x87, 0x71, 0x65, 0xa2, 0xc7, 0xc7, 0x2b, 0x25, 0x1d, 0x3f, 0xfb, 0xe6,
	0x05, 0xe1, 0x09, 0xb9, 0x76, 0x1d, 0xb9, 0xf9, 0xaf, 0xb4, 0x79, 0xa1, 0x35, 0x05, 0x59, 0x88, 0xa0, 0x07, 0xb5, 0x2d, 0x02, 0x11, 0x0a, 0x89, 0xf1, 0x67,
	0xdb, 0xe5, 0x5c, 0x5c, 0xaa, 0x0e, 0x21, 0xa6, 0xa4, 0x1a, 0x9f, 0x9e, 0xc8, 0x2a, 0x36, 0x6f, 0xcc, 0xa3, 0x13, 0x78, 0xf1, 0xbe, 0x34, 0xa0, 0x35, 0xef,
	0x1f, 0xf4, 0x79, 0xcb, 0x37, 0x3e, 0x77, 0x14, 0xfb, 0x2e, 0x21, 0x4f, 0x6b, 0xe5, 0xe9, 0x3a, 0x90, 0x76, 0xa8, 0x55, 0x09, 0xb6, 0x68, 0xbf, 0x66, 0xae,
	0xf1, 0x55, 0xc0, 0x76, 0x8f, 0x16, 0x86, 0x49, 0x9a, 0x88, 0x01, 0xdb, 0x78, 0x1f, 0xde, 0xc2, 0x33, 0x92, 0xe3, 0x22, 0xc6, 0x8c, 0x20, 0x17, 0xa0, 0xb2,
	0x79, 0xf4, 0x60, 0x8e, 0x98, 0x53, 0xcd, 0x8f, 0xb2, 0x8f, 0x80, 0xda, 0x9f, 0xf6, 0x00, 0x0c, 0xf8, 0x6b, 0xdf, 0x7d, 0x93, 0x48, 0x5a, 0x23, 0x35, 0x0e,
	0x1b, 0xf7, 0x50, 0x87, 0x93, 0x29, 0xaa, 0xa1, 0xb8, 0x98, 0x9f, 0x89, 0xb2, 0x0a, 0x02, 0x27, 0x95, 0x01, 0x84, 0x5a, 0x09, 0xb8, 0xff, 0x23, 0x02, 0x89,
	0xef, 0x1b, 0x64, 0xb2, 0x38, 0x81, 0xc4, 0x36, 0xe3, 0xda, 0xb5, 0x3b, 0x80, 0x45, 0x52, 0x96, 0xab, 0x0e, 0xdb, 0xb6, 0x9c, 0xcb, 0xc4, 0xe5, 0xb9, 0x72,
	0x67, 0x57, 0x4b, 0xb9, 0x55, 0xcb, 0x6b, 0xc4, 0xec, 0x46, 0x4d, 0xa3, 0xe0, 0xda, 0xba, 0x70, 0x3d, 0xa6, 0xa7, 0x3f, 0x58, 0xd2, 0x9f, 0xb0, 0x11, 0x66,
	0xaf, 0x73, 0x09, 0x60, 0x6e, 0xe0, 0x71, 0xa5, 0x65, 0x41, 0x28, 0x3e, 0x70, 0x1d, 0x25, 0x77, 0x6a, 0x4e, 0xed, 0xb9, 0x27, 0x6c, 0xf0, 0xba, 0x54, 0x8d,
	0x77, 0xfb, 0xb6, 0x4e, 0xe2, 0xab, 0x8f, 0xe3, 0xd4, 0x02, 0x65, 0x0a, 0x49, 0xf3, 0xf9, 0xc7, 0x09, 0x76, 0x81, 0xf4, 0xf8, 0x3e, 0x1f, 0x74, 0x30, 0xaf,
	0x3b, 0x9e, 0x97, 0x00, 0xde, 0xd8, 0x9a, 0xaf, 0xcc, 0x72, 0xeb, 0x0a, 0xe7, 0xab, 0xc1, 0x53, 0x62, 0x3f, 0x08, 0xba, 0x43, 0x06, 0x13, 0x0a, 0x3b, 0x5c,
	0xb4, 0xe0, 0xc8, 0xa6, 0x41, 0x45, 0xaa, 0x1a, 0xc9, 0x88, 0x86, 0x31, 0x25, 0x02, 0x4a, 0x76, 0x66, 0xb6, 0x6d, 0xff, 0x50, 0x1d, 0x3c, 0xf3, 0x2d, 0xfe,
	0x7b, 0xb2, 0x75, 0x5d, 0x9a, 0x9a, 0xe5, 0x39, 0x31, 0x4f, 0x7b, 0xa5, 0x6f, 0x94, 0xed, 0x31, 0xd4, 0x61, 0xc7, 0x44, 0x1d, 0x37, 0x19, 0x76, 0x04, 0x0e,
	0xbd, 0xc4, 0x9e, 0xe3, 0xdf, 0x94, 0x49, 0x32, 0x65, 0xd0, 0x37, 0x64, 0xb5, 0x2a, 0x61, 0x2d, 0x05, 0xc5, 0xe5, 0x79, 0x3e, 0xcf, 0x5f, 0x77, 0x0a, 0x7c,
	0x29, 0x34, 0x1a, 0x45, 0x7e, 0x11, 0x68, 0xb4, 0x3a, 0xf6, 0x5b, 0x23, 0xe4, 0x32, 0xa4, 0x11, 0x1a, 0xba, 0xd6, 0x4a, 0x45, 0x42, 0x29, 0xac, 0xb0, 0x17,
	0x05, 0x1b, 0xee, 0xf6, 0x52, 0x6d, 0x8b, 0xb4, 0x3b, 0x63, 0xe2, 0xca, 0xbf, 0x7e, 0xd3, 0xf7, 0x96, 0x75, 0x67, 0x9d, 0x27, 0x15, 0x39, 0xde, 0x5f, 0x66,
	0x74, 0x7c, 0x46, 0x01, 0x48, 0xf7, 0x99, 0x33, 0x7d, 0xc6, 0x81, 0xc4, 0x82, 0x09, 0x00, 0x20, 0x3f, 0x5c, 0xe4, 0x51, 0x88, 0x5b, 0xac, 0x31, 0x17, 0x04,
	0xa4, 0xac, 0xbf, 0x3d, 0xff, 0xad, 0x51, 0x07, 0x0b, 0xc7, 0x26, 0xa7, 0x9f, 0x83, 0x17, 0xd8, 0x2f, 0x6a, 0x47, 0x96, 0x14, 0x47, 0x68, 0xd4, 0xc0, 0xc0,
	0x3b, 0x87, 0x51, 0x30, 0xe9, 0xfa, 0x21, 0x46, 0x80, 0x1a, 0x5a, 0xef, 0x78, 0xd0, 0x3a, 0xac, 0x73, 0x1e, 0x39, 0xba, 0x82, 0x43, 0x5d, 0xef, 0x15, 0x2c,
	0x9a, 0xe5, 0xeb, 0x6a, 0xe7, 0x24, 0x12, 0xe6, 0x2a, 0xd2, 0x09, 0xc2, 0x85, 0x69, 0x9d, 0x73, 0x16, 0xb0, 0xad, 0x51, 0xf8, 0x3d, 0x94, 0x6b, 0xb7, 0xb3,
	0x7f, 0xb4, 0x9e, 0xc1, 0xdc, 0x31, 0x27, 0xa1, 0x2d, 0xfe, 0x30, 0x15, 0x04, 0x20, 0x82, 0xdc, 0xbd, 0x8b, 0xc5, 0xb4, 0xcf, 0x91, 0x85, 0xae, 0x21, 0x5e,
	0x00, 0x10, 0x04, 0x62, 0x8a, 0xe2, 0x66, 0x74, 0xf8, 0x8d, 0x8b, 0x52, 0x17, 0xd9, 0x1a, 0xbd, 0x06, 0x2d, 0x07, 0x6a, 0xf5, 0x8b, 0xdf, 0x85, 0x2e, 0x36,
	0xec, 0x15, 0x6f, 0x7e, 0xd2, 0x04, 0x43, 0x6a, 0xd7, 0x60, 0xf5, 0x53, 0x0d, 0x2e, 0x2d, 0xf5, 0x52, 0x4c, 0xcc, 0xe5, 0xf4, 0x47, 0xdd, 0x34, 0xda, 0xc1,
	0xfc, 0x60, 0x00, 0xaa, 0x68, 0x01, 0x5c, 0x82, 0x4b, 0xf9, 0x57, 0x54, 0x9d, 0xd5, 0x8b, 0xb6, 0x42, 0x77, 0xd4, 0x47, 0x70, 0x23, 0x4c, 0xad, 0xc5, 0x00,
	0x73, 0x9b, 0xbb, 0x65, 0xa7, 0x46, 0x74, 0xcd, 0x2e, 0x61, 0x0f, 0xac, 0xeb, 0x53, 0x5a, 0x87, 0x70, 0xfc, 0x5d, 0x2e, 0xa1, 0xe3, 0x9a, 0x87, 0x01, 0x0f,
	0x2e, 0xef, 0x10, 0xe2, 0x82, 0xd8, 0x12, 0xe7, 0xb8, 0x94, 0xa4, 0xdd, 0x5f, 0xea, 0x21, 0x63, 0x26, 0x43, 0xec, 0xc3, 0x54, 0x76, 0xb1, 0xb2, 0x1c, 0x03,
	0x4c, 0x5c, 0x22, 0xb5, 0x00, 0x7d, 0x77, 0x3a, 0xb6, 0xbf, 0x50, 0xbd, 0xfd, 0x0a, 0x31, 0x2c, 0xdc, 0xab, 0xe2, 0xc0, 0x0b, 0xb6, 0x66, 0xad, 0x9c, 0xca,
	0x94, 0xed, 0xd8, 0x77, 0x1b, 0xf1, 0x94, 0xdd, 0x65, 0x61, 0xda, 0x7b, 0x04, 0x3c, 0x93, 0xcf, 0x96, 0x74, 0x35, 0x8e, 0x41, 0xe1, 0xa4, 0xbc, 0xf2, 0x4f,
	0xe9, 0xb8, 0x16, 0x55, 0x05, 0x5a, 0xac, 0x10, 0xd3, 0xdf, 0xea, 0x6a, 0xf8, 0xe0, 0xf3, 0xdf, 0x66, 0x00, 0xab, 0x3d, 0xb9, 0x44, 0x65, 0x34, 0x49, 0x89,
	0xf2, 0x1d, 0x09, 0xc9, 0xfc, 0xa5, 0x84, 0xa1, 0x03, 0x5b, 0x7a, 0x5c, 0x7e, 0x21, 0xe9, 0xb4, 0x3a, 0x4c, 0x2b, 0x94, 0x64, 0x1d, 0x9b, 0xa5, 0xbf, 0x7e,
	0x1c, 0x97, 0x7e, 0x3d, 0xbe, 0x84, 0xfc, 0xab, 0x6d, 0x2a, 0x50, 0x23, 0x9e, 0x11, 0x3f, 0xe2, 0xa0, 0x68, 0xe7, 0xd5, 0xba, 0x5e, 0x24, 0x8c, 0x4c, 0x46,
	0xe6, 0x5b, 0x10, 0xc3, 0x82, 0x32, 0x17, 0x32, 0xdc, 0xec, 0xaa, 0x1e, 0x73, 0xe5, 0x7d, 0xb8, 0x1c, 0x6c, 0x4c, 0x9f, 0x60, 0x7b, 0x66, 0x4c, 0x90, 0x69,
	0xc4, 0x23, 0x66, 0x67, 0xce, 0x6d, 0x24, 0x1d, 0xcc, 0x8e, 0x78, 0xa1, 0xa7, 0xde, 0x87, 0x81, 0xac, 0x62, 0x54, 0xbc, 0x47, 0x82, 0x3c, 0xad, 0x92, 0x29,
	0xd9, 0xc0, 0xed, 0x0c, 0x11, 0x0e, 0xc5, 0x75, 0xa4, 0xbd, 0xbf, 0xcb, 0x3a, 0xaf, 0x2b, 0x9f, 0xbe, 0xbb, 0xbc, 0x31, 0x07, 0xa7, 0xbe, 0x6c, 0xa9, 0x4e,
	0xff, 0x35, 0x80, 0x2f, 0x09, 0x77, 0xe0, 0xc0, 0xdc, 0x9c, 0xc6, 0xa6, 0x63, 0xab, 0x47, 0x74, 0x5f, 0x5c, 0xae, 0x75, 0xbf, 0x42, 0x67, 0x55, 0x89, 0xcf,
	0xd3, 0x65, 0x8d, 0x5b, 0x6f, 0x5c, 0xf9, 0xd1, 0x78, 0xa2, 0xfd, 0x4f, 0x54, 0x6a, 0x71, 0x0c, 0x58, 0x13, 0xb0, 0x48, 0x0a, 0x7b, 0xcc, 0x84, 0x61, 0xa7,
	0x7d, 0x39, 0xa2, 0xd1, 0xc0, 0xdb, 0x8e, 0x97, 0x20, 0x86, 0x97, 0x20, 0xda, 0xca, 0x56, 0x78, 0x61, 0xc2, 0x2f, 0x36, 0xdb, 0x95, 0xae, 0x7e, 0x8d, 0x97,
	0xcb, 0x45, 0x6a, 0x6d, 0x27, 0xaa, 0xab, 0x4e, 0x88, 0x23, 0xb6, 0x6a, 0x8a, 0xca, 0x71, 0xca, 0x39, 0xa2, 0x98, 0x0d, 0x53, 0xa9, 0x38, 0xd5, 0x9c, 0x5d,
	0x0e, 0x5e, 0xc9, 0xeb, 0x21, 0xab, 0x00, 0xca, 0xff, 0x92, 0x20, 0x9d, 0x65, 0x9d, 0x8d, 0x49, 0x46, 0xbe, 0x51, 0x97, 0xc1, 0x61, 0x02, 0x9e, 0xa8, 0xb9,
	0x2c, 0x27, 0x7d, 0x73, 0xf9, 0x12, 0x16, 0x45, 0x25, 0xbb, 0xb0, 0x51, 0x14, 0x18, 0x07, 0xab, 0xc7, 0x06, 0xc0, 0xe9, 0x1c, 0xf8, 0x6d, 0xe1, 0x80, 0x21,
	0x21, 0x68, 0x24, 0xf7, 0x28, 0xb9, 0x07, 0xd4, 0xd7, 0xdf, 0x3e, 0xff, 0xbc, 0xe3, 0xbc, 0x6e, 0x42, 0x76, 0x63, 0xbc, 0x82, 0x0a, 0xf5, 0x99, 0x65, 0x17,
	0xd2, 0x38, 0xa9, 0xa8, 0x31, 0xce, 0x1f, 0xf7, 0xef, 0x8d, 0x94, 0xae, 0x99, 0x50, 0x30, 0x12, 0xbd, 0x4b, 0x65, 0x56, 0x59, 0xfb, 0x33, 0x7b, 0x99, 0xc7,
	0xe5, 0x80, 0xe6, 0x92, 0x0e, 0x44, 0x1d, 0x17, 0xc2, 0xd0, 0x78, 0x76, 0x9d, 0x5b, 0x7d, 0x3c, 0xb4, 0xf8, 0xcb, 0x2f, 0x83, 0x23, 0x35, 0x49, 0xc0, 0x78,
	0x2d, 0x44, 0x05, 0x64, 0x0f, 0xaa, 0x84, 0x9d, 0x3f, 0xac, 0xef, 0x5b, 0x46, 0x44, 0xb8, 0x15, 0xbe, 0x4f, 0xe7, 0x25, 0xb7, 0xa0, 0xc8, 0x0f, 0x70, 0x1a,
	0xca, 0x7f, 0xce, 0x79, 0x7b, 0xf5, 0x7e, 0x21, 0x35, 0xc7, 0x0e, 0x99, 0xdc, 0x76, 0xe0, 0x36, 0x09, 0x6e, 0x6d, 0x5f, 0x98, 0x5e, 0xb8, 0xa4, 0x88, 0xea,
	0x0b, 0x4b, 0x21, 0xa2, 0x52, 0x86, 0x95, 0x4e, 0x18, 0xac, 0xa2, 0xaf, 0x29, 0x5b, 0xe7, 0x05, 0xa1, 0xc8, 0xe1, 0x80, 0xfa, 0xb6, 0x5a, 0xed, 0x94, 0x32,
	0x4f, 0xe9, 0xf5, 0xf0, 0x61, 0x5d, 0x7f, 0xc4, 0xc4, 0xd1, 0x05, 0x54, 0x13, 0xdb};

/*
 * packet_build_tcp()
 *  -> ETH->IPv6->UDP->GTP->IPv4->TCP
 *  -> with TCP payload
 */
#if 1
TEST(PACKET_BUILD_TCP, ETH_IP6_UDP_GTP_IP4_TCP)
{
	struct packet orig_pkt;
	memset(&orig_pkt, 0, sizeof(orig_pkt));
	packet_parse(&orig_pkt, (const char *)data3, sizeof(data3));
	PRINT_GREEN("origin packet:");
	packet_print(&orig_pkt);

	struct packet *new_pkt = packet_build_tcp(&orig_pkt, 1, 2, TH_ACK, NULL, 0, "Hello", 5);
	EXPECT_TRUE(new_pkt != nullptr);
	PRINT_GREEN("new packet:");
	packet_print(new_pkt);

	packet_dump_hex(new_pkt, STDOUT_FILENO);
	packet_dump_pcap(new_pkt, "craft-eth-ipv6-udp-gtp-ipv4-tcp.pcap");

	const char *orig_pkt_data = packet_get_raw_data(&orig_pkt);
	uint16_t orig_pkt_len = packet_get_raw_len(&orig_pkt);

	const char *new_pkt_data = packet_get_raw_data(new_pkt);
	uint16_t new_pkt_len = packet_get_raw_len(new_pkt);

	EXPECT_TRUE(orig_pkt_len - 12 - 1348 == // trim TCP options, TCP payload
				new_pkt_len - 5);			// trim TCP payload
	int count = packet_get_layer_count(new_pkt);
	for (int i = 0; i < count; i++)
	{
		const struct layer *layer = packet_get_layer_by_idx(new_pkt, i);
		if (layer->proto == LAYER_PROTO_IPV6)
		{
			const struct ip6_hdr *ip6 = (const struct ip6_hdr *)layer->hdr.raw;
			EXPECT_TRUE(ip6_hdr_get_payload_len(ip6) == 61);
			break;
		}
		if (layer->proto == LAYER_PROTO_UDP)
		{
			const struct udphdr *udp = (const struct udphdr *)layer->hdr.raw;
			EXPECT_TRUE(udp_hdr_get_total_len(udp) == 61);
			EXPECT_TRUE(udp_hdr_get_checksum(udp) == 0xd375);
			break;
		}
		if (layer->proto == LAYER_PROTO_GTP_U)
		{
			EXPECT_TRUE(peek_gtp_version(layer->hdr.raw, layer->hdr_len) == 1);
			const struct gtp1_hdr *gtp1 = (const struct gtp1_hdr *)layer->hdr.raw;
			EXPECT_TRUE(gtp1_hdr_get_msg_len(gtp1) == 45);
			break;
		}
		if (layer->proto == LAYER_PROTO_IPV4)
		{
			const struct ip *ip = (const struct ip *)layer->hdr.raw;
			EXPECT_TRUE(ip4_hdr_get_total_len(ip) == 45);
			EXPECT_TRUE(ip4_hdr_get_checksum(ip) == 0x4906);
			break;
		}
		if (layer->proto == LAYER_PROTO_TCP)
		{
			const struct tcphdr *tcp = (const struct tcphdr *)layer->hdr.raw;
			EXPECT_TRUE(tcp_hdr_get_seq(tcp) == 1);
			EXPECT_TRUE(tcp_hdr_get_ack(tcp) == 2);
			EXPECT_TRUE(tcp_hdr_get_flags(tcp) == TH_ACK);
			EXPECT_TRUE(tcp_hdr_get_hdr_len(tcp) == 20);
			EXPECT_TRUE(tcp_hdr_get_checksum(tcp) == 0xcce5);
			break;
		}
	}

	for (uint16_t i = 0; i < new_pkt_len - 5; i++)
	{
		if (18 <= i && i <= 19) // skip IPv6 payload length
		{
			continue;
		}
		if ((58 <= i && i <= 59) || // skip UDP length
			(60 <= i && i <= 61))	// skip UDP checksum
		{
			continue;
		}
		if ((64 <= i && i <= 65)) // skip gtp length
		{
			continue;
		}
		if ((72 <= i && i <= 73) || // skip IPv4 total length
			(80 <= i && i <= 81))	// skip IPv4 checksum
		{
			continue;
		}
		if ((94 <= i && i <= 98) ||	 // skip TCP seq
			(99 <= i && i <= 103) || // skip TCP ack
			i == 104 ||				 // skip TCP data offset
			i == 105 ||				 // skip TCP flags
			(106 <= i && i <= 107))	 // skip TCP checksum
		{
			continue;
		}

		// printf(("idx: %d, orig: %02x, new: %02x\n"), i, orig_pkt_data[i], new_pkt_data[i]);
		EXPECT_TRUE(orig_pkt_data[i] == new_pkt_data[i]);
	}

	packet_free(new_pkt);
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:gre:ipv6:tcp]
 ******************************************************************************
 *
 * Frame 1: 102 bytes on wire (816 bits), 102 bytes captured (816 bits)
 * Ethernet II, Src: a0:b1:c2:d3:e4:f5 (a0:b1:c2:d3:e4:f5), Dst: CIMSYS_33:44:55 (00:11:22:33:44:55)
 * 	Destination: CIMSYS_33:44:55 (00:11:22:33:44:55)
 * 		Address: CIMSYS_33:44:55 (00:11:22:33:44:55)
 * 		.... ..0. .... .... .... .... = LG bit: Globally unique address (factory default)
 * 		.... ...0 .... .... .... .... = IG bit: Individual address (unicast)
 * 	Source: a0:b1:c2:d3:e4:f5 (a0:b1:c2:d3:e4:f5)
 * 		Address: a0:b1:c2:d3:e4:f5 (a0:b1:c2:d3:e4:f5)
 * 		.... ..0. .... .... .... .... = LG bit: Globally unique address (factory default)
 * 		.... ...0 .... .... .... .... = IG bit: Individual address (unicast)
 * 	Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 10.0.0.1, Dst: 192.168.1.1
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 		0000 00.. = Differentiated Services Codepoint: Default (0)
 * 		.... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 * 	Total Length: 88
 * 	Identification: 0x0001 (1)
 * 	000. .... = Flags: 0x0
 * 		0... .... = Reserved bit: Not set
 * 		.0.. .... = Don't fragment: Not set
 * 		..0. .... = More fragments: Not set
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 64
 * 	Protocol: Generic Routing Encapsulation (47)
 * 	Header Checksum: 0xaecc [correct]
 * 	[Header checksum status: Good]
 * 	[Calculated Checksum: 0xaecc]
 * 	Source Address: 10.0.0.1
 * 	Destination Address: 192.168.1.1
 * Generic Routing Encapsulation (IPv6)
 * 	Flags and Version: 0x8000
 * 		1... .... .... .... = Checksum Bit: Yes
 * 		.0.. .... .... .... = Routing Bit: No
 * 		..0. .... .... .... = Key Bit: No
 * 		...0 .... .... .... = Sequence Number Bit: No
 * 		.... 0... .... .... = Strict Source Route Bit: No
 * 		.... .000 .... .... = Recursion control: 0
 * 		.... .... 0000 0... = Flags (Reserved): 0
 * 		.... .... .... .000 = Version: GRE (0)
 * 	Protocol Type: IPv6 (0x86dd)
 * 	Checksum: 0x92e7 [correct]
 * 	[Checksum Status: Good]
 * 	Offset: 0
 * Internet Protocol Version 6, Src: ::, Dst: 2001:db8::1
 * 	0110 .... = Version: 6
 * 	.... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 		.... 0000 00.. .... .... .... .... .... = Differentiated Services Codepoint: Default (0)
 * 		.... .... ..00 .... .... .... .... .... = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 * 	.... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 * 	Payload Length: 20
 * 	Next Header: TCP (6)
 * 	Hop Limit: 64
 * 	Source Address: ::
 * 	Destination Address: 2001:db8::1
 * Transmission Control Protocol, Src Port: 12345, Dst Port: 80, Seq: 0, Len: 0
 * 	Source Port: 12345
 * 	Destination Port: 80
 * 	[Stream index: 0]
 * 	[Conversation completeness: Incomplete, SYN_SENT (1)]
 * 		..0. .... = RST: Absent
 * 		...0 .... = FIN: Absent
 * 		.... 0... = Data: Absent
 * 		.... .0.. = ACK: Absent
 * 		.... ..0. = SYN-ACK: Absent
 * 		.... ...1 = SYN: Present
 * 		[Completeness Flags: ·····S]
 * 	[TCP Segment Len: 0]
 * 	Sequence Number: 0
 * 	[Next Sequence Number: 1]
 * 	Acknowledgment Number: 0
 * 	Acknowledgment number (raw): 0
 * 	0101 .... = Header Length: 20 bytes (5)
 * 	Flags: 0x002 (SYN)
 * 		000. .... .... = Reserved: Not set
 * 		...0 .... .... = Accurate ECN: Not set
 * 		.... 0... .... = Congestion Window Reduced: Not set
 * 		.... .0.. .... = ECN-Echo: Not set
 * 		.... ..0. .... = Urgent: Not set
 * 		.... ...0 .... = Acknowledgment: Not set
 * 		.... .... 0... = Push: Not set
 * 		.... .... .0.. = Reset: Not set
 * 		.... .... ..1. = Syn: Set
 * 			[Expert Info (Chat/Sequence): Connection establish request (SYN): server port 80]
 * 				[Connection establish request (SYN): server port 80]
 * 				[Severity level: Chat]
 * 				[Group: Sequence]
 * 		.... .... ...0 = Fin: Not set
 * 		[TCP Flags: ··········S·]
 * 	Window: 8192
 * 	[Calculated window size: 8192]
 * 	Checksum: 0x31a0 [correct]
 * 		[Calculated Checksum: 0x31a0]
 * 	[Checksum Status: Good]
 * 	Urgent Pointer: 0
 * 	[Timestamps]
 * 		[Time since first frame in this TCP stream: 0.000000000 seconds]
 * 		[Time since previous frame in this TCP stream: 0.000000000 seconds]
 */

unsigned char data4[] = {
	0x00, 0x11, 0x22, 0x33, 0x44, 0x55, 0xa0, 0xb1, 0xc2, 0xd3, 0xe4, 0xf5, 0x08, 0x00, 0x45, 0x00, 0x00, 0x58, 0x00, 0x01, 0x00, 0x00, 0x40, 0x2f, 0xae, 0xcc,
	0x0a, 0x00, 0x00, 0x01, 0xc0, 0xa8, 0x01, 0x01, 0x80, 0x00, 0x86, 0xdd, 0x92, 0xe7, 0x00, 0x00, 0x60, 0x00, 0x00, 0x00, 0x00, 0x14, 0x06, 0x40, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x20, 0x01, 0x0d, 0xb8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x01, 0x30, 0x39, 0x00, 0x50, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x02, 0x20, 0x00, 0x31, 0xa0, 0x00, 0x00};

/*
 * packet_build_tcp()
 * 	-> ETH->IPv4->GRE->IPv6->TCP
 *	-> with TCP payload
 *  -> with GRE checksum
 */
#if 1
TEST(PACKET_BUILD_TCP, ETH_IP4_GRE_IP6_TCP)
{
	struct packet orig_pkt;
	memset(&orig_pkt, 0, sizeof(orig_pkt));
	packet_parse(&orig_pkt, (const char *)data4, sizeof(data4));
	PRINT_GREEN("origin packet:");
	packet_print(&orig_pkt);

	struct packet *new_pkt = packet_build_tcp(&orig_pkt, 1, 2, TH_ACK, NULL, 0, "Hello", 5);
	EXPECT_TRUE(new_pkt != nullptr);
	PRINT_GREEN("new packet:");
	packet_print(new_pkt);

	packet_dump_hex(new_pkt, STDOUT_FILENO);
	packet_dump_pcap(new_pkt, "craft-eth-ipv4-gre-ipv6-tcp.pcap");

	const char *orig_pkt_data = packet_get_raw_data(&orig_pkt);
	uint16_t orig_pkt_len = packet_get_raw_len(&orig_pkt);

	const char *new_pkt_data = packet_get_raw_data(new_pkt);
	uint16_t new_pkt_len = packet_get_raw_len(new_pkt);

	EXPECT_TRUE(orig_pkt_len ==
				new_pkt_len - 5); // trim TCP payload
	int count = packet_get_layer_count(new_pkt);
	for (int i = 0; i < count; i++)
	{
		const struct layer *layer = packet_get_layer_by_idx(new_pkt, i);
		if (layer->proto == LAYER_PROTO_IPV4)
		{
			const struct ip *ip = (const struct ip *)layer->hdr.raw;
			EXPECT_TRUE(ip4_hdr_get_total_len(ip) == 93);
			EXPECT_TRUE(ip4_hdr_get_checksum(ip) == 0xaec7);
			break;
		}
		if (layer->proto == LAYER_PROTO_GRE)
		{
			const struct gre0_hdr *gre = (const struct gre0_hdr *)layer->hdr.raw;
			EXPECT_TRUE(gre0_hdr_get_version(gre) == 0);
			EXPECT_TRUE(gre0_hdr_get_checksum(gre) == 0x92e7);
			break;
		}
		if (layer->proto == LAYER_PROTO_IPV6)
		{
			const struct ip6_hdr *ip6 = (const struct ip6_hdr *)layer->hdr.raw;
			EXPECT_TRUE(ip6_hdr_get_payload_len(ip6) == 25);
			break;
		}
		if (layer->proto == LAYER_PROTO_TCP)
		{
			const struct tcphdr *tcp = (const struct tcphdr *)layer->hdr.raw;
			EXPECT_TRUE(tcp_hdr_get_seq(tcp) == 1);
			EXPECT_TRUE(tcp_hdr_get_ack(tcp) == 2);
			EXPECT_TRUE(tcp_hdr_get_flags(tcp) == TH_ACK);
			EXPECT_TRUE(tcp_hdr_get_hdr_len(tcp) == 20);
			EXPECT_TRUE(tcp_hdr_get_checksum(tcp) == 0x0db8);
			break;
		}
	}

	for (uint16_t i = 0; i < new_pkt_len - 5; i++)
	{
		if ((16 <= i && i <= 17) || // skip IP total length
			(24 <= i && i <= 25))	// skip IP checksum
		{
			continue;
		}
		if (38 <= i && i <= 39) // skip GRE checksum
		{
			continue;
		}
		if (47 <= i && i <= 48) // skip IPv6 payload length
		{
			continue;
		}
		if ((86 <= i && i <= 89) || // skip TCP seq
			(90 <= i && i <= 93) || // skip TCP ack
			i == 95 ||				// skip TCP flags
			(98 <= i && i <= 99))	// skip TCP checksum
		{
			continue;
		}

		// printf(("idx: %d, orig: %02x, new: %02x\n"), i, orig_pkt_data[i], new_pkt_data[i]);
		EXPECT_TRUE(orig_pkt_data[i] == new_pkt_data[i]);
	}

	packet_free(new_pkt);
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:vlan:ethertype:ipv6:ip:gre:ppp:ip:udp:dns]
 ******************************************************************************
 *
 * Frame 1: 197 bytes on wire (1576 bits), 197 bytes captured (1576 bits)
 * Ethernet II, Src: JuniperNetwo_f2:61:3d (00:12:1e:f2:61:3d), Dst: c5:00:00:00:82:c4 (c5:00:00:00:82:c4)
 *     Destination: c5:00:00:00:82:c4 (c5:00:00:00:82:c4)
 *     Source: JuniperNetwo_f2:61:3d (00:12:1e:f2:61:3d)
 *     Type: 802.1Q Virtual LAN (0x8100)
 * 802.1Q Virtual LAN, PRI: 0, DEI: 0, ID: 100
 *     000. .... .... .... = Priority: Best Effort (default) (0)
 *     ...0 .... .... .... = DEI: Ineligible
 *     .... 0000 0110 0100 = ID: 100
 *     Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2402:f000:1:8e01::5555, Dst: 2607:fcd0:100:2300::b108:2a6b
 *     0110 .... = Version: 6
 *     .... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         .... 0000 00.. .... .... .... .... .... = Differentiated Services Codepoint: Default (0)
 *         .... .... ..00 .... .... .... .... .... = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     .... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 *     Payload Length: 139
 *     Next Header: IPIP (4)
 *     Hop Limit: 246
 *     Source Address: 2402:f000:1:8e01::5555
 *     Destination Address: 2607:fcd0:100:2300::b108:2a6b
 * Internet Protocol Version 4, Src: 16.0.0.200, Dst: 192.52.166.154
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 139
 *     Identification: 0x8caf (36015)
 *     000. .... = Flags: 0x0
 *         0... .... = Reserved bit: Not set
 *         .0.. .... = Don't fragment: Not set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 64
 *     Protocol: Generic Routing Encapsulation (47)
 *     Header Checksum: 0x75fe [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0x75fe]
 *     Source Address: 16.0.0.200
 *     Destination Address: 192.52.166.154
 * Generic Routing Encapsulation (PPP)
 *     Flags and Version: 0x3081
 *         0... .... .... .... = Checksum Bit: No
 *         .0.. .... .... .... = Routing Bit: No
 *         ..1. .... .... .... = Key Bit: Yes
 *         ...1 .... .... .... = Sequence Number Bit: Yes
 *         .... 0... .... .... = Strict Source Route Bit: No
 *         .... .000 .... .... = Recursion control: 0
 *         .... .... 1... .... = Acknowledgment: Yes
 *         .... .... .000 0... = Flags (Reserved): 0
 *         .... .... .... .001 = Version: Enhanced GRE (1)
 *     Protocol Type: PPP (0x880b)
 *     Payload Length: 103
 *     Call ID: 6016
 *     Sequence Number: 430001
 *     Acknowledgment Number: 539254
 * Point-to-Point Protocol
 *     Address: 0xff
 *     Control: 0x03
 *     Protocol: Internet Protocol version 4 (0x0021)
 * Internet Protocol Version 4, Src: 172.16.44.3, Dst: 8.8.8.8
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 99
 *     Identification: 0x0000 (0)
 *     010. .... = Flags: 0x2, Don't fragment
 *         0... .... = Reserved bit: Not set
 *         .1.. .... = Don't fragment: Set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 60
 *     Protocol: UDP (17)
 *     Header Checksum: 0x5667 [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0x5667]
 *     Source Address: 172.16.44.3
 *     Destination Address: 8.8.8.8
 * User Datagram Protocol, Src Port: 40768, Dst Port: 53
 *     Source Port: 40768
 *     Destination Port: 53
 *     Length: 79
 *     Checksum: 0x2d23 [correct]
 *         [Calculated Checksum: 0x2d23]
 *     [Checksum Status: Good]
 *     [Stream index: 0]
 *     [Timestamps]
 *         [Time since first frame: 0.000000000 seconds]
 *         [Time since previous frame: 0.000000000 seconds]
 *     UDP payload (71 bytes)
 * Domain Name System (query)
 *     Transaction ID: 0xa62c
 *     Flags: 0x0100 Standard query
 *         0... .... .... .... = Response: Message is a query
 *         .000 0... .... .... = Opcode: Standard query (0)
 *         .... ..0. .... .... = Truncated: Message is not truncated
 *         .... ...1 .... .... = Recursion desired: Do query recursively
 *         .... .... .0.. .... = Z: reserved (0)
 *         .... .... ...0 .... = Non-authenticated data: Unacceptable
 *     Questions: 1
 *     Answer RRs: 0
 *     Authority RRs: 0
 *     Additional RRs: 0
 *     Queries
 *         xqt-detect-mode2-97712e88-167a-45b9-93ee-913140e76678: type AAAA, class IN
 *             Name: xqt-detect-mode2-97712e88-167a-45b9-93ee-913140e76678
 *             [Name Length: 53]
 *             [Label Count: 1]
 *             Type: AAAA (28) (IP6 Address)
 *             Class: IN (0x0001)
 *     [Response In: 2]
 */

unsigned char data5[] = {
	0xc5, 0x00, 0x00, 0x00, 0x82, 0xc4, 0x00, 0x12, 0x1e, 0xf2, 0x61, 0x3d, 0x81, 0x00, 0x00, 0x64, 0x86, 0xdd, 0x60, 0x00, 0x00, 0x00, 0x00, 0x8b, 0x04, 0xf6,
	0x24, 0x02, 0xf0, 0x00, 0x00, 0x01, 0x8e, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x55, 0x55, 0x26, 0x07, 0xfc, 0xd0, 0x01, 0x00, 0x23, 0x00, 0x00, 0x00,
	0x00, 0x00, 0xb1, 0x08, 0x2a, 0x6b, 0x45, 0x00, 0x00, 0x8b, 0x8c, 0xaf, 0x00, 0x00, 0x40, 0x2f, 0x75, 0xfe, 0x10, 0x00, 0x00, 0xc8, 0xc0, 0x34, 0xa6, 0x9a,
	0x30, 0x81, 0x88, 0x0b, 0x00, 0x67, 0x17, 0x80, 0x00, 0x06, 0x8f, 0xb1, 0x00, 0x08, 0x3a, 0x76, 0xff, 0x03, 0x00, 0x21, 0x45, 0x00, 0x00, 0x63, 0x00, 0x00,
	0x40, 0x00, 0x3c, 0x11, 0x56, 0x67, 0xac, 0x10, 0x2c, 0x03, 0x08, 0x08, 0x08, 0x08, 0x9f, 0x40, 0x00, 0x35, 0x00, 0x4f, 0x2d, 0x23, 0xa6, 0x2c, 0x01, 0x00,
	0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x35, 0x78, 0x71, 0x74, 0x2d, 0x64, 0x65, 0x74, 0x65, 0x63, 0x74, 0x2d, 0x6d, 0x6f, 0x64, 0x65, 0x32, 0x2d,
	0x39, 0x37, 0x37, 0x31, 0x32, 0x65, 0x38, 0x38, 0x2d, 0x31, 0x36, 0x37, 0x61, 0x2d, 0x34, 0x35, 0x62, 0x39, 0x2d, 0x39, 0x33, 0x65, 0x65, 0x2d, 0x39, 0x31,
	0x33, 0x31, 0x34, 0x30, 0x65, 0x37, 0x36, 0x36, 0x37, 0x38, 0x00, 0x00, 0x1c, 0x00, 0x01};

/*
 * packet_build_udp()
 * 	-> ETH->VLAN->IPv6->IPv4->GRE->PPP->IPv4->UDP->DNS
 *	-> with UDP payload
 *  -> with GRE payload length
 */
#if 1
TEST(PACKET_BUILD_UDP, ETH_VLAN_IPv6_IPv4_GRE_PPP_IPv4_UDP_DNS)
{
	struct packet orig_pkt;
	memset(&orig_pkt, 0, sizeof(orig_pkt));
	packet_parse(&orig_pkt, (const char *)data5, sizeof(data5));
	PRINT_GREEN("origin packet:");
	packet_print(&orig_pkt);

	struct packet *new_pkt = packet_build_udp(&orig_pkt, "Hello", 5);
	EXPECT_TRUE(new_pkt != nullptr);
	PRINT_GREEN("new packet:");
	packet_print(new_pkt);

	packet_dump_hex(new_pkt, STDOUT_FILENO);
	packet_dump_pcap(new_pkt, "craft-eth-vlan-ipv6-ipv4-gre-ppp-ipv4-udp-dns.pcap");

	const char *orig_pkt_data = packet_get_raw_data(&orig_pkt);
	uint16_t orig_pkt_len = packet_get_raw_len(&orig_pkt);

	const char *new_pkt_data = packet_get_raw_data(new_pkt);
	uint16_t new_pkt_len = packet_get_raw_len(new_pkt);

	EXPECT_TRUE(orig_pkt_len - 71 == // trim DNS payload
				new_pkt_len - 5);	 // trim UDP payload
	int flag = 0;
	int count = packet_get_layer_count(new_pkt);
	for (int i = 0; i < count; i++)
	{
		const struct layer *layer = packet_get_layer_by_idx(new_pkt, i);
		if (layer->proto == LAYER_PROTO_IPV6)
		{
			const struct ip6_hdr *ip6 = (const struct ip6_hdr *)layer->hdr.raw;
			EXPECT_TRUE(ip6_hdr_get_payload_len(ip6) == 73);
		}
		if (layer->proto == LAYER_PROTO_IPV4)
		{
			const struct ip *ip = (const struct ip *)layer->hdr.raw;
			if (flag == 0)
			{
				EXPECT_TRUE(ip4_hdr_get_total_len(ip) == 73);
				EXPECT_TRUE(ip4_hdr_get_checksum(ip) == 0x7640);
			}
			else
			{
				EXPECT_TRUE(ip4_hdr_get_total_len(ip) == 33);
				EXPECT_TRUE(ip4_hdr_get_checksum(ip) == 0x56a9);
			}
			flag++;
		}
		if (layer->proto == LAYER_PROTO_GRE)
		{
			const struct gre1_hdr *gre = (const struct gre1_hdr *)layer->hdr.raw;
			EXPECT_TRUE(gre1_hdr_get_version(gre) == 1);
			EXPECT_TRUE(gre1_hdr_get_payload_length(gre) == 37);
		}
		if (layer->proto == LAYER_PROTO_UDP)
		{
			const struct udphdr *udp = (const struct udphdr *)layer->hdr.raw;
			EXPECT_TRUE(udp_hdr_get_total_len(udp) == 13);
			EXPECT_TRUE(udp_hdr_get_checksum(udp) == 0x5469);
		}
	}

	for (uint16_t i = 0; i < new_pkt_len - 5; i++)
	{
		if (22 <= i && i <= 23) /// skip IPv6 payload length
		{
			continue;
		}
		if ((60 <= i && i <= 61) || // skip IPv4 total length
			(68 <= i && i <= 69))	// skip IPv4 checksum
		{
			continue;
		}
		if ((82 <= i && i <= 83)) // skip GRE payload length
		{
			continue;
		}
		if ((100 <= i && i <= 101) || // skip IPv4 total length
			(108 <= i && i <= 109))	  // skip IPv4 checksum
		{
			continue;
		}
		if ((122 <= i && i <= 123) || // skip UDP total length
			(124 <= i && i <= 125))	  // skip UDP checksum
		{
			continue;
		}

		// printf(("idx: %d, orig: %02x, new: %02x\n"), i, orig_pkt_data[i], new_pkt_data[i]);
		EXPECT_TRUE(orig_pkt_data[i] == new_pkt_data[i]);
	}

	packet_free(new_pkt);
}
#endif

/*
 * packet_build_l3()
 * 	-> ETH->IPv4->ICMP
 *  -> ICMPv4 checkum not include the pseudo-header of IPv4 header
 */
#if 1
TEST(PACKET_BUILD_L3, ETH_IP4_ICMP)
{
	/*
	 * Internet Control Message Protocol
	 * 	Type: 8 (Echo (ping) request)
	 * 	Code: 0
	 * 	Checksum: 0xaa4f [correct]
	 * 	[Checksum Status: Good]
	 * 	Identifier (BE): 27498 (0x6b6a)
	 * 	Identifier (LE): 27243 (0x6a6b)
	 * 	Sequence Number (BE): 0 (0x0000)
	 * 	Sequence Number (LE): 0 (0x0000)
	 * 	[Response frame: 31]
	 * 	Timestamp from icmp data: Aug  2, 2024 10:51:12.214771000 CST
	 * 	[Timestamp from icmp data (relative): 0.000093000 seconds]
	 * 	Data (48 bytes)
	 * 		Data: 08090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f3031323334353637
	 * 		[Length: 48]
	 */
	unsigned char icmp_resp[] = {
		0x08, 0x00, 0xaa, 0x4f, 0x6b, 0x6a, 0x00, 0x00, 0x66, 0xac, 0x49, 0xa0, 0x00, 0x03, 0x46, 0xf3, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10,
		0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29,
		0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37};

	struct packet orig_pkt;
	memset(&orig_pkt, 0, sizeof(orig_pkt));
	packet_parse(&orig_pkt, (const char *)data1, sizeof(data1));
	PRINT_GREEN("origin packet:");
	packet_print(&orig_pkt);

	struct icmphdr *icmp = (struct icmphdr *)icmp_resp;
	icmp->checksum = 0;
	icmp->checksum = checksum(icmp, sizeof(icmp_resp));

	struct packet *new_pkt = packet_build_l3(&orig_pkt, IPPROTO_ICMP, (const char *)icmp_resp, sizeof(icmp_resp));
	EXPECT_TRUE(new_pkt != nullptr);
	PRINT_GREEN("new packet:");
	packet_print(new_pkt);

	packet_dump_hex(new_pkt, STDOUT_FILENO);
	packet_dump_pcap(new_pkt, "craft-eth-ipv4-icmpv4.pcap");

	const char *orig_pkt_data = packet_get_raw_data(&orig_pkt);
	uint16_t orig_pkt_len = packet_get_raw_len(&orig_pkt);

	const char *new_pkt_data = packet_get_raw_data(new_pkt);
	uint16_t new_pkt_len = packet_get_raw_len(new_pkt);

	EXPECT_TRUE(orig_pkt_len - 20 - 6 == // trim Eth padding, trim TCP header
				new_pkt_len - 64);		 // trim ICMP
	int count = packet_get_layer_count(new_pkt);
	for (int i = 0; i < count; i++)
	{
		const struct layer *layer = packet_get_layer_by_idx(new_pkt, i);
		if (layer->proto == LAYER_PROTO_IPV4)
		{
			const struct ip *ip = (const struct ip *)layer->hdr.raw;
			EXPECT_TRUE(ip4_hdr_get_total_len(ip) == 84);
			EXPECT_TRUE(ip4_hdr_get_checksum(ip) == 0xb7cb);
			break;
		}
		if (layer->proto == LAYER_PROTO_ICMP)
		{
			// TODO
			break;
		}
	}
	for (uint16_t i = 0; i < new_pkt_len - sizeof(icmp_resp); i++)
	{
		if ((16 <= i && i <= 17) || // skip IPv4 total length
			23 == i ||				// skip IPv4 protocol
			(24 <= i && i <= 25))	// skip IPv4 checksum
		{
			continue;
		}

		// printf(("idx: %d, orig: %02x, new: %02x\n"), i, orig_pkt_data[i], new_pkt_data[i]);
		EXPECT_TRUE(orig_pkt_data[i] == new_pkt_data[i]);
	}

	packet_free(new_pkt);
}
#endif

/*
 * packet_build_l3()
 * 	-> ETH->IPv4->IPv6->ICMPv6
 *  -> ICMPv6 checkum need include the pseudo-header of IPv6 header
 */
#if 1
TEST(PACKET_BUILD_L3, ETH_IP6_ICMP)
{
	/*
	 * Internet Control Message Protocol v6
	 * 	Type: Echo (ping) request (128)
	 * 	Code: 0
	 * 	Checksum: 0x7e8f [correct]
	 * 	[Checksum Status: Good]
	 * 	Identifier: 0x18dc
	 * 	Sequence: 0
	 * 	[Response In: 2]
	 * 	Data (52 bytes)
	 * 		Data: 000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f30313233
	 * 		[Length: 52]
	 */
	unsigned char icmp_resp[] = {
		0x80, 0x00, 0x7e, 0x8f, 0x18, 0xdc, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f, 0x10,
		0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29,
		0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33};

	struct packet orig_pkt;
	memset(&orig_pkt, 0, sizeof(orig_pkt));
	packet_parse(&orig_pkt, (const char *)data2, sizeof(data2));
	PRINT_GREEN("origin packet:");
	packet_print(&orig_pkt);

	struct icmp6_hdr *icmp = (struct icmp6_hdr *)icmp_resp;
	icmp->icmp6_cksum = 0;

	int count = packet_get_layer_count(&orig_pkt);
	for (int i = count - 1; i >= 0; i--)
	{
		const struct layer *layer = packet_get_layer_by_idx(&orig_pkt, i);
		if (layer->proto == LAYER_PROTO_IPV6)
		{
			struct ip6_hdr *ip6 = (struct ip6_hdr *)layer->hdr.raw;
			icmp->icmp6_cksum = checksum_v6(icmp, sizeof(icmp_resp), IPPROTO_ICMPV6, &ip6->ip6_src, &ip6->ip6_dst);
			break;
		}
	}

	struct packet *new_pkt = packet_build_l3(&orig_pkt, IPPROTO_ICMPV6, (const char *)icmp_resp, sizeof(icmp_resp));
	EXPECT_TRUE(new_pkt != nullptr);
	PRINT_GREEN("new packet:");
	packet_print(new_pkt);

	packet_dump_hex(new_pkt, STDOUT_FILENO);
	packet_dump_pcap(new_pkt, "craft-eth-ipv4-ipv6-icmpv6.pcap");

	const char *orig_pkt_data = packet_get_raw_data(&orig_pkt);
	uint16_t orig_pkt_len = packet_get_raw_len(&orig_pkt);

	const char *new_pkt_data = packet_get_raw_data(new_pkt);
	uint16_t new_pkt_len = packet_get_raw_len(new_pkt);

	EXPECT_TRUE(orig_pkt_len - 32 == // trim TCP header
				new_pkt_len - 60);	 // trim ICMPv6 header
	count = packet_get_layer_count(new_pkt);
	for (int i = 0; i < count; i++)
	{
		const struct layer *layer = packet_get_layer_by_idx(new_pkt, i);
		if (layer->proto == LAYER_PROTO_IPV4)
		{
			const struct ip *ip = (const struct ip *)layer->hdr.raw;
			EXPECT_TRUE(ip4_hdr_get_total_len(ip) == 120);
			EXPECT_TRUE(ip4_hdr_get_checksum(ip) == 0x09ac);
			break;
		}
		if (layer->proto == LAYER_PROTO_IPV6)
		{
			const struct ip6_hdr *ip6 = (const struct ip6_hdr *)layer->hdr.raw;
			EXPECT_TRUE(ip6_hdr_get_payload_len(ip6) == 60);
			break;
		}
		if (layer->proto == LAYER_PROTO_ICMP6)
		{
			// TODO
			break;
		}
	}
	for (uint16_t i = 0; i < new_pkt_len - 60; i++)
	{
		if ((16 <= i && i <= 17) || // skip IPv4 total length
			(24 <= i && i <= 25))	// skip IPv4 checksum
		{
			continue;
		}
		if (38 <= i && i <= 39) // skip IPv6 payload length
		{
			continue;
		}
		if (40 == i) // skip IPv6 next header
		{
			continue;
		}

		// printf(("idx: %d, orig: %02x, new: %02x\n"), i, orig_pkt_data[i], new_pkt_data[i]);
		EXPECT_TRUE(orig_pkt_data[i] == new_pkt_data[i]);
	}

	packet_free(new_pkt);
}
#endif

int main(int argc, char **argv)
{
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
