#include <gtest/gtest.h>

#include "packet_helper.h"

/*
 * Generic Routing Encapsulation (IP)
 *     Flags and Version: 0x0000
 *         0... .... .... .... = Checksum Bit: No
 *         .0.. .... .... .... = Routing Bit: No
 *         ..0. .... .... .... = Key Bit: No
 *         ...0 .... .... .... = Sequence Number Bit: No
 *         .... 0... .... .... = Strict Source Route Bit: No
 *         .... .000 .... .... = Recursion control: 0
 *         .... .... 0000 0... = Flags (Reserved): 0
 *         .... .... .... .000 = Version: GRE (0)
 *     Protocol Type: IP (0x0800)
 */

unsigned char gre0_no_opt[] = {
    0x00, 0x00, 0x08, 0x00};

TEST(GRE0_UTILS, GET_1)
{
    const struct gre0_hdr *hdr = (struct gre0_hdr *)gre0_no_opt;

    EXPECT_TRUE(gre0_hdr_get_flags(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_checksum_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_routing_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_key_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_seq_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_strict_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_version(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_proto(hdr) == 0x0800);
    EXPECT_TRUE(gre0_hdr_get_checksum(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_offset(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_key(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_seq(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_routing_data(hdr) == NULL);
    EXPECT_TRUE(gre0_hdr_get_routing_len(hdr) == 0);

    EXPECT_TRUE(calc_gre0_hdr_len((const char *)gre0_no_opt, sizeof(gre0_no_opt)) == 4);
}

TEST(GRE0_UTILS, SET_1)
{
    char buff[4] = {0};

    struct gre0_hdr *hdr = (struct gre0_hdr *)buff;
    gre0_hdr_set_flags(hdr, 0);
    gre0_hdr_set_checksum_flag(hdr, 0);
    gre0_hdr_set_routing_flag(hdr, 0);
    gre0_hdr_set_key_flag(hdr, 0);
    gre0_hdr_set_seq_flag(hdr, 0);
    gre0_hdr_set_strict_flag(hdr, 0);
    gre0_hdr_set_version(hdr, 0);
    gre0_hdr_set_proto(hdr, 0x0800);
    gre0_hdr_set_checksum(hdr, 0);
    gre0_hdr_set_offset(hdr, 0);
    gre0_hdr_set_key(hdr, 0);
    gre0_hdr_set_seq(hdr, 0);
    gre0_hdr_set_routing_data(hdr, NULL, 0);

    EXPECT_TRUE(memcmp(buff, gre0_no_opt, 4) == 0);
}

/*
 * Generic Routing Encapsulation (IP)
 *     Flags and Version: 0x2000
 *         0... .... .... .... = Checksum Bit: No
 *         .0.. .... .... .... = Routing Bit: No
 *         ..1. .... .... .... = Key Bit: Yes
 *         ...0 .... .... .... = Sequence Number Bit: No
 *         .... 0... .... .... = Strict Source Route Bit: No
 *         .... .000 .... .... = Recursion control: 0
 *         .... .... 0000 0... = Flags (Reserved): 0
 *         .... .... .... .000 = Version: GRE (0)
 *     Protocol Type: IP (0x0800)
 *     Key: 0x00000384
 */

unsigned char gre0_opt_key[] = {0x20, 0x00, 0x08, 0x00, 0x00, 0x00, 0x03, 0x84};

TEST(GRE0_UTILS, GET_2)
{
    const struct gre0_hdr *hdr = (struct gre0_hdr *)gre0_opt_key;

    EXPECT_TRUE(gre0_hdr_get_flags(hdr) == 0x2000);
    EXPECT_TRUE(gre0_hdr_get_checksum_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_routing_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_key_flag(hdr) == 1);
    EXPECT_TRUE(gre0_hdr_get_seq_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_strict_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_version(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_proto(hdr) == 0x0800);
    EXPECT_TRUE(gre0_hdr_get_checksum(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_offset(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_key(hdr) == 0x00000384);
    EXPECT_TRUE(gre0_hdr_get_seq(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_routing_data(hdr) == NULL);
    EXPECT_TRUE(gre0_hdr_get_routing_len(hdr) == 0);

    EXPECT_TRUE(calc_gre0_hdr_len((const char *)gre0_opt_key, sizeof(gre0_opt_key)) == 8);
}

TEST(GRE0_UTILS, SET_2)
{
    char buff[8] = {0};

    struct gre0_hdr *hdr = (struct gre0_hdr *)buff;
    gre0_hdr_set_flags(hdr, 0x2000);
    gre0_hdr_set_checksum_flag(hdr, 0);
    gre0_hdr_set_routing_flag(hdr, 0);
    gre0_hdr_set_key_flag(hdr, 1);
    gre0_hdr_set_seq_flag(hdr, 0);
    gre0_hdr_set_strict_flag(hdr, 0);
    gre0_hdr_set_version(hdr, 0);
    gre0_hdr_set_proto(hdr, 0x0800);
    gre0_hdr_set_checksum(hdr, 0);
    gre0_hdr_set_offset(hdr, 0);
    gre0_hdr_set_key(hdr, 0x00000384);
    gre0_hdr_set_seq(hdr, 0);
    gre0_hdr_set_routing_data(hdr, NULL, 0);

    EXPECT_TRUE(memcmp(buff, gre0_opt_key, 8) == 0);
}

/*
 * Generic Routing Encapsulation (IP)
 *     Flags and Version: 0xc000
 *         1... .... .... .... = Checksum Bit: Yes
 *         .1.. .... .... .... = Routing Bit: Yes
 *         ..0. .... .... .... = Key Bit: No
 *         ...0 .... .... .... = Sequence Number Bit: No
 *         .... 0... .... .... = Strict Source Route Bit: No
 *         .... .000 .... .... = Recursion control: 0
 *         .... .... 0000 0... = Flags (Reserved): 0
 *         .... .... .... .000 = Version: GRE (0)
 *     Protocol Type: IP (0x0800)
 *     Checksum: 0x0000 incorrect, should be 0xea95
 *         [Expert Info (Warning/Protocol): Incorrect GRE Checksum [should be 0xea95]]
 *             [Incorrect GRE Checksum [should be 0xea95]]
 *             [Severity level: Warning]
 *             [Group: Protocol]
 *     [Checksum Status: Bad]
 *     Offset: 44
 *     Routing
 *     Address Family: 2
 *     SRE Offset: 0
 *     SRE Length: 44
 *     Routing Information: 6c696e6b5f696e666f206c696e6b5f696e666f206c696e6b5f696e666f206c696e6b5f696e666f2000000000
 *     Routing
 *     Address Family: 0
 *     SRE Offset: 0
 *     SRE Length: 0
 */

unsigned char gre0_opt_chek_rout[] = {
    0xc0, 0x00, 0x08, 0x00, 0x00, 0x00, 0x00, 0x2c, 0x00, 0x02, 0x00, 0x2c, 0x6c, 0x69, 0x6e, 0x6b, 0x5f, 0x69, 0x6e, 0x66, 0x6f, 0x20, 0x6c, 0x69, 0x6e, 0x6b,
    0x5f, 0x69, 0x6e, 0x66, 0x6f, 0x20, 0x6c, 0x69, 0x6e, 0x6b, 0x5f, 0x69, 0x6e, 0x66, 0x6f, 0x20, 0x6c, 0x69, 0x6e, 0x6b, 0x5f, 0x69, 0x6e, 0x66, 0x6f, 0x20,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

TEST(GRE0_UTILS, GET_3)
{
    const struct gre0_hdr *hdr = (struct gre0_hdr *)gre0_opt_chek_rout;

    EXPECT_TRUE(gre0_hdr_get_flags(hdr) == 0xc000);
    EXPECT_TRUE(gre0_hdr_get_checksum_flag(hdr) == 1);
    EXPECT_TRUE(gre0_hdr_get_routing_flag(hdr) == 1);
    EXPECT_TRUE(gre0_hdr_get_key_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_seq_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_strict_flag(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_version(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_proto(hdr) == 0x0800);
    EXPECT_TRUE(gre0_hdr_get_checksum(hdr) == 0x0000);
    EXPECT_TRUE(gre0_hdr_get_offset(hdr) == 44);
    EXPECT_TRUE(gre0_hdr_get_key(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_seq(hdr) == 0);
    EXPECT_TRUE(gre0_hdr_get_routing_data(hdr) == (const char *)gre0_opt_chek_rout + 8);
    EXPECT_TRUE(gre0_hdr_get_routing_len(hdr) == 52);

    EXPECT_TRUE(calc_gre0_hdr_len((const char *)gre0_opt_chek_rout, sizeof(gre0_opt_chek_rout)) == 60);
}

TEST(GRE0_UTILS, SET_3)
{
    char buff[60] = {0};

    struct gre0_hdr *hdr = (struct gre0_hdr *)buff;
    gre0_hdr_set_flags(hdr, 0xc000);
    gre0_hdr_set_checksum_flag(hdr, 1);
    gre0_hdr_set_routing_flag(hdr, 1);
    gre0_hdr_set_key_flag(hdr, 0);
    gre0_hdr_set_seq_flag(hdr, 0);
    gre0_hdr_set_strict_flag(hdr, 0);
    gre0_hdr_set_version(hdr, 0);
    gre0_hdr_set_proto(hdr, 0x0800);
    gre0_hdr_set_checksum(hdr, 0x0000);
    gre0_hdr_set_offset(hdr, 44);
    gre0_hdr_set_key(hdr, 0);
    gre0_hdr_set_seq(hdr, 0);
    gre0_hdr_set_routing_data(hdr, (const char *)gre0_opt_chek_rout + 8, 52);

    EXPECT_TRUE(memcmp(buff, gre0_opt_chek_rout, 60) == 0);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
