#include <gtest/gtest.h>
#include <arpa/inet.h>

#include "tuple.h"
#include "packet_internal.h"
#include "packet_parser.h"
#include "packet_dump.h"

/******************************************************************************
 * [Protocols in frame: eth:ethertype:vlan:ethertype:vlan:ethertype:ip:ip:udp:data]
 ******************************************************************************
 *
 * Frame 1: 170 bytes on wire (1360 bits), 170 bytes captured (1360 bits)
 * Ethernet II, Src: HuaweiTe_3b:b3:9a (a4:c6:4f:3b:b3:9a), Dst: 00:00:00_00:00:04 (00:00:00:00:00:04)
 * 	Destination: 00:00:00_00:00:04 (00:00:00:00:00:04)
 * 	Source: HuaweiTe_3b:b3:9a (a4:c6:4f:3b:b3:9a)
 * 	Type: 802.1Q Virtual LAN (0x8100)
 * 802.1Q Virtual LAN, PRI: 3, DEI: 0, ID: 1624
 * 	011. .... .... .... = Priority: Critical Applications (3)
 * 	...0 .... .... .... = DEI: Ineligible
 * 	.... 0110 0101 1000 = ID: 1624
 * 	Type: 802.1Q Virtual LAN (0x8100)
 * 802.1Q Virtual LAN, PRI: 3, DEI: 0, ID: 505
 * 	011. .... .... .... = Priority: Critical Applications (3)
 * 	...0 .... .... .... = DEI: Ineligible
 * 	.... 0001 1111 1001 = ID: 505
 * 	Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 69.67.35.146, Dst: 41.202.46.110
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0xb8 (DSCP: EF PHB, ECN: Not-ECT)
 * 	Total Length: 148
 * 	Identification: 0xe858 (59480)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 255
 * 	Protocol: IPIP (4)
 * 	Header Checksum: 0x1148 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 69.67.35.146
 * 	Destination Address: 41.202.46.110
 * Internet Protocol Version 4, Src: 10.10.100.25, Dst: 10.10.101.2
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0xb8 (DSCP: EF PHB, ECN: Not-ECT)
 * 	Total Length: 128
 * 	Identification: 0x0001 (1)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 254
 * 	Protocol: UDP (17)
 * 	Header Checksum: 0xde84 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 10.10.100.25
 * 	Destination Address: 10.10.101.2
 * User Datagram Protocol, Src Port: 62367, Dst Port: 17000
 * 	Source Port: 62367
 * 	Destination Port: 17000
 * 	Length: 108
 * 	Checksum: 0x4b9a [unverified]
 * 	[Checksum Status: Unverified]
 * 	[Stream index: 0]
 * 	[Timestamps]
 * 		[Time since first frame: 0.000000000 seconds]
 * 		[Time since previous frame: 0.000000000 seconds]
 * 	UDP payload (100 bytes)
 * Data (100 bytes)
 */

unsigned char data1[] = {
	0x00, 0x00, 0x00, 0x00, 0x00, 0x04, 0xa4, 0xc6, 0x4f, 0x3b, 0xb3, 0x9a, 0x81, 0x00, 0x66, 0x58, 0x81, 0x00, 0x61, 0xf9, 0x08, 0x00, 0x45, 0xb8, 0x00, 0x94,
	0xe8, 0x58, 0x00, 0x00, 0xff, 0x04, 0x11, 0x48, 0x45, 0x43, 0x23, 0x92, 0x29, 0xca, 0x2e, 0x6e, 0x45, 0xb8, 0x00, 0x80, 0x00, 0x01, 0x00, 0x00, 0xfe, 0x11,
	0xde, 0x84, 0x0a, 0x0a, 0x64, 0x19, 0x0a, 0x0a, 0x65, 0x02, 0xf3, 0x9f, 0x42, 0x68, 0x00, 0x6c, 0x4b, 0x9a, 0x00, 0x02, 0x00, 0x00, 0x04, 0x73, 0x6c, 0x10,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd,
	0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd,
	0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd,
	0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd, 0xab, 0xcd};

#if 1
TEST(PACKET_PARSE, ETH_VLAN_VLAN_IP4_IP4_UDP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data1, sizeof(data1));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data1 == 70);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 156);

	// LAYER_PROTO_VLAN
	const struct layer_internal *outer_vlan_record = packet_get_outermost_layer(&handler, LAYER_PROTO_VLAN);
	const struct layer_internal *inner_vlan_record = packet_get_innermost_layer(&handler, LAYER_PROTO_VLAN);

	EXPECT_TRUE(outer_vlan_record != nullptr);
	EXPECT_TRUE(inner_vlan_record != nullptr);
	EXPECT_TRUE(outer_vlan_record->hdr_offset == 14);
	EXPECT_TRUE(outer_vlan_record->hdr_len == 4);
	EXPECT_TRUE(outer_vlan_record->pld_len == 152);
	EXPECT_TRUE(inner_vlan_record->hdr_offset == 18);
	EXPECT_TRUE(inner_vlan_record->hdr_len == 4);
	EXPECT_TRUE(inner_vlan_record->pld_len == 148);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 22);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 128);
	EXPECT_TRUE(inner_ipv4_record->hdr_offset == 42);
	EXPECT_TRUE(inner_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(inner_ipv4_record->pld_len == 108);

	// LAYER_PROTO_UDP
	const struct layer_internal *outer_udp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_UDP);
	const struct layer_internal *inner_udp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(outer_udp_record != nullptr);
	EXPECT_TRUE(inner_udp_record != nullptr);
	EXPECT_TRUE(outer_udp_record == inner_udp_record);
	EXPECT_TRUE(outer_udp_record->hdr_offset == 62);
	EXPECT_TRUE(outer_udp_record->hdr_len == 8);
	EXPECT_TRUE(outer_udp_record->pld_len == 100);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "69.67.35.146-41.202.46.110");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.10.100.25-10.10.101.2");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.10.100.25:62367-10.10.101.2:17000");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.10.100.25:62367-10.10.101.2:17000");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.10.100.25:62367-10.10.101.2:17000-17-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.10.100.25:62367-10.10.101.2:17000-17-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ipv6:ip:tcp:ssh]
 ******************************************************************************
 *
 * Frame 1: 726 bytes on wire (5808 bits), 726 bytes captured (5808 bits)
 * Ethernet II, Src: EvocInte_36:51:3c (00:22:46:36:51:3c), Dst: EvocInte_36:51:38 (00:22:46:36:51:38)
 * 	Destination: EvocInte_36:51:38 (00:22:46:36:51:38)
 * 	Source: EvocInte_36:51:3c (00:22:46:36:51:3c)
 * 	Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2001::192:168:40:134, Dst: 2001::192:168:40:133
 * 	0110 .... = Version: 6
 * 	.... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	.... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 * 	Payload Length: 672
 * 	Next Header: IPIP (4)
 * 	Hop Limit: 64
 * 	Source Address: 2001::192:168:40:134
 * 	Destination Address: 2001::192:168:40:133
 * 	[Source Teredo Server IPv4: 0.0.0.0]
 * 	[Source Teredo Port: 65175]
 * 	[Source Teredo Client IPv4: 255.191.254.203]
 * 	[Destination Teredo Server IPv4: 0.0.0.0]
 * 	[Destination Teredo Port: 65175]
 * 	[Destination Teredo Client IPv4: 255.191.254.204]
 * Internet Protocol Version 4, Src: 1.1.1.1, Dst: 2.2.2.2
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 672
 * 	Identification: 0x0968 (2408)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 212
 * 	Protocol: TCP (6)
 * 	Header Checksum: 0xd4ea [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 1.1.1.1
 * 	Destination Address: 2.2.2.2
 * Transmission Control Protocol, Src Port: 57639, Dst Port: 22, Seq: 1, Ack: 1, Len: 632
 * 	Source Port: 57639
 * 	Destination Port: 22
 * 	[Stream index: 0]
 * 	[Conversation completeness: Incomplete (8)]
 * 	[TCP Segment Len: 632]
 * 	Sequence Number: 1    (relative sequence number)
 * 	Sequence Number (raw): 1508621024
 * 	[Next Sequence Number: 633    (relative sequence number)]
 * 	Acknowledgment Number: 1    (relative ack number)
 * 	Acknowledgment number (raw): 2828957019
 * 	0101 .... = Header Length: 20 bytes (5)
 * 	Flags: 0x018 (PSH, ACK)
 * 	Window: 28584
 * 	[Calculated window size: 28584]
 * 	[Window size scaling factor: -1 (unknown)]
 * 	Checksum: 0xc51f [unverified]
 * 	[Checksum Status: Unverified]
 * 	Urgent Pointer: 0
 * 	[Timestamps]
 * 	[SEQ/ACK analysis]
 * 	TCP payload (632 bytes)
 * SSH Protocol
 */

unsigned char data2[] = {
	0x00, 0x22, 0x46, 0x36, 0x51, 0x38, 0x00, 0x22, 0x46, 0x36, 0x51, 0x3c, 0x86, 0xdd, 0x60, 0x00, 0x00, 0x00, 0x02, 0xa0, 0x04, 0x40, 0x20, 0x01, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x01, 0x92, 0x01, 0x68, 0x00, 0x40, 0x01, 0x34, 0x20, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x92, 0x01, 0x68, 0x00, 0x40,
	0x01, 0x33, 0x45, 0x00, 0x02, 0xa0, 0x09, 0x68, 0x00, 0x00, 0xd4, 0x06, 0xd4, 0xea, 0x01, 0x01, 0x01, 0x01, 0x02, 0x02, 0x02, 0x02, 0xe1, 0x27, 0x00, 0x16,
	0x59, 0xeb, 0xba, 0xe0, 0xa8, 0x9e, 0x75, 0x5b, 0x50, 0x18, 0x6f, 0xa8, 0xc5, 0x1f, 0x00, 0x00, 0x4f, 0xe3, 0xa9, 0x48, 0x9b, 0xbe, 0xa8, 0x07, 0x0e, 0xbb,
	0x5b, 0xf1, 0x15, 0x1d, 0xc9, 0xbe, 0xdf, 0x78, 0x89, 0xa2, 0x8f, 0x12, 0x5f, 0xad, 0x51, 0xd5, 0xfa, 0xa7, 0x0b, 0xf2, 0x34, 0x00, 0x5b, 0x77, 0xae, 0xab,
	0xe4, 0x49, 0xa7, 0xa5, 0xa7, 0x1f, 0xda, 0x90, 0xcc, 0xe1, 0x8e, 0x9f, 0xe9, 0xee, 0x53, 0x59, 0xa4, 0x17, 0xf8, 0x0d, 0x40, 0xe5, 0x75, 0x97, 0xf0, 0x29,
	0xfa, 0x7c, 0xb8, 0x12, 0x7e, 0x93, 0xbc, 0x7e, 0x0a, 0x69, 0x8f, 0x1d, 0x7b, 0x1a, 0x2e, 0xf6, 0xa6, 0x78, 0x67, 0x26, 0xfe, 0x8f, 0xcf, 0x5a, 0x02, 0x7d,
	0xbb, 0x1b, 0xdb, 0xc7, 0x71, 0xee, 0xe9, 0xd9, 0xc1, 0x48, 0xbf, 0xc7, 0xcc, 0x00, 0x82, 0x7f, 0x69, 0x52, 0xa7, 0xe1, 0x12, 0xec, 0xf1, 0x93, 0xa8, 0x55,
	0x5b, 0x33, 0xd3, 0x35, 0x11, 0x5d, 0xf8, 0x3d, 0x5b, 0x94, 0xc9, 0x67, 0xae, 0xba, 0xc0, 0x4a, 0x8b, 0x25, 0x8d, 0xbf, 0xd4, 0xcc, 0x24, 0xb7, 0x3d, 0x0f,
	0x1a, 0x57, 0x20, 0x5c, 0x64, 0x62, 0xf7, 0x3c, 0xff, 0xaf, 0x6b, 0xf2, 0xf3, 0xca, 0xd1, 0xcb, 0x7b, 0x9f, 0xc1, 0x31, 0x25, 0x01, 0xd1, 0x18, 0x78, 0x81,
	0xf8, 0xae, 0x61, 0x4b, 0x59, 0xa1, 0xbe, 0x4a, 0x94, 0x12, 0xa3, 0x05, 0x4a, 0x26, 0x85, 0xbd, 0x5e, 0x59, 0xb2, 0xc2, 0x24, 0xec, 0xd6, 0x94, 0x6e, 0xc5,
	0x7a, 0xdf, 0x21, 0x21, 0xe4, 0x06, 0x67, 0x89, 0xe0, 0x76, 0x85, 0xa9, 0x00, 0x43, 0xfe, 0x72, 0x8c, 0x10, 0xe4, 0x96, 0x63, 0x1a, 0xe8, 0x84, 0xe1, 0x86,
	0xa2, 0xa5, 0x67, 0x31, 0x67, 0x44, 0xca, 0xec, 0xe8, 0xa1, 0x3e, 0x5f, 0x4e, 0x71, 0x5d, 0xd4, 0x34, 0xa9, 0x3d, 0xfa, 0x6a, 0xdb, 0xfb, 0x28, 0x2b, 0x70,
	0xcc, 0xf1, 0x3c, 0x7c, 0xf5, 0x39, 0xb5, 0xd0, 0xa2, 0x56, 0x22, 0x96, 0x7e, 0xc5, 0x0e, 0x66, 0x2d, 0xcd, 0x5c, 0x33, 0x43, 0x1c, 0xca, 0x17, 0x77, 0x46,
	0xb2, 0x41, 0x06, 0x8a, 0x7c, 0x7c, 0x66, 0x06, 0x18, 0x33, 0x21, 0x16, 0x8f, 0x5a, 0xb7, 0xdd, 0x10, 0xa1, 0xab, 0xe9, 0x66, 0xf7, 0x90, 0x22, 0x2c, 0xbe,
	0xdd, 0xad, 0xe1, 0x40, 0xe9, 0x21, 0x53, 0x97, 0x07, 0x97, 0x6b, 0xd6, 0x91, 0x11, 0x44, 0x4e, 0x9d, 0x1f, 0x57, 0x07, 0xed, 0xa2, 0xac, 0x77, 0xc0, 0x84,
	0xb7, 0xc5, 0x2b, 0xaa, 0x17, 0xd2, 0xdb, 0x2a, 0x15, 0x47, 0x2b, 0x69, 0xf1, 0xb4, 0xb5, 0x8f, 0x98, 0xcf, 0x26, 0x03, 0xf0, 0x4b, 0x1a, 0xba, 0x94, 0xc4,
	0x12, 0xe3, 0xd1, 0x38, 0x0c, 0x2e, 0x87, 0x33, 0x0f, 0xe1, 0xa6, 0xba, 0x75, 0xd0, 0xa4, 0x94, 0x80, 0x49, 0x67, 0xa8, 0x90, 0x31, 0x19, 0xaa, 0xf9, 0x78,
	0x0d, 0xdd, 0x64, 0xe3, 0xc7, 0x0e, 0x81, 0xa7, 0x6b, 0x44, 0x0c, 0xb5, 0xa0, 0x25, 0x8a, 0xa2, 0xdc, 0x5e, 0xbc, 0xcd, 0xb4, 0x87, 0x1b, 0x6c, 0x08, 0x38,
	0x63, 0xa8, 0xc1, 0xde, 0xe2, 0xa1, 0xa4, 0x19, 0x1e, 0x3c, 0x67, 0x3b, 0xf7, 0x7f, 0x67, 0xfb, 0x50, 0x9a, 0x06, 0x5c, 0xdd, 0xf2, 0x26, 0x2c, 0xb9, 0xd2,
	0xbd, 0x80, 0xd5, 0xfc, 0xc5, 0x54, 0x6c, 0xc1, 0xea, 0x76, 0x3e, 0xd4, 0xbb, 0x57, 0x65, 0x6a, 0xf8, 0x8e, 0x3e, 0x93, 0xe5, 0x03, 0xfc, 0xce, 0xf1, 0x1c,
	0xf3, 0x10, 0xae, 0x87, 0x78, 0x46, 0x02, 0x63, 0xc5, 0xc0, 0x41, 0xbd, 0xae, 0x46, 0x68, 0x0c, 0x92, 0x22, 0xa4, 0xc0, 0xce, 0xf3, 0xc4, 0xf7, 0x83, 0xa9,
	0x22, 0x78, 0x74, 0x7f, 0x2e, 0xc1, 0xc6, 0x3b, 0x72, 0x26, 0x4b, 0x45, 0xbd, 0x1b, 0x9f, 0x66, 0x61, 0x46, 0xbb, 0x0f, 0xf3, 0xc5, 0x65, 0x95, 0xbc, 0xae,
	0x8f, 0x37, 0xfd, 0xa3, 0x20, 0xb6, 0xe4, 0xa8, 0xff, 0x45, 0xa1, 0x01, 0xa1, 0x76, 0xb3, 0xad, 0x16, 0x07, 0x39, 0x58, 0x3b, 0x34, 0xe9, 0xe6, 0xc0, 0xee,
	0x7f, 0x65, 0x6f, 0x68, 0xf4, 0x45, 0xa4, 0x85, 0xa7, 0x50, 0x63, 0xce, 0x0b, 0x0d, 0xbd, 0xd1, 0x20, 0xc8, 0x41, 0x37, 0x05, 0x1f, 0x81, 0xf3, 0x7c, 0xe7,
	0x67, 0x15, 0xce, 0xad, 0x76, 0x95, 0x1a, 0x93, 0x4a, 0xab, 0xc4, 0xea, 0x30, 0x44, 0x13, 0x47, 0xec, 0x79, 0xa2, 0x41, 0x0c, 0xdd, 0x42, 0xdf, 0xbf, 0x02,
	0xef, 0x9e, 0x67, 0x7e, 0x1e, 0xb0, 0x2a, 0x7f, 0x97, 0xf3, 0x5a, 0xbc, 0x21, 0x8d, 0xf9, 0xc3, 0x30, 0x45, 0xfe, 0x72, 0x74, 0x04, 0x53, 0x99, 0xe7, 0xd1,
	0x2b, 0xb6, 0x3a, 0x9c, 0x84, 0x0e, 0x15, 0x5e, 0x75, 0x3b, 0xc9, 0x0e, 0x94, 0xe6, 0x48, 0x0e, 0x37, 0x07, 0xf8, 0xd9, 0x59, 0x4b, 0x04, 0x50};

#if 1
TEST(PACKET_PARSE, ETH_IP6_IP4_TCP_SSH)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data2, sizeof(data2));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data2 == 94);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 712);

	// LAYER_PROTO_IPV6
	const struct layer_internal *outer_ipv6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV6);
	const struct layer_internal *inner_ipv6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(outer_ipv6_record != nullptr);
	EXPECT_TRUE(inner_ipv6_record != nullptr);
	EXPECT_TRUE(outer_ipv6_record == inner_ipv6_record);
	EXPECT_TRUE(outer_ipv6_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(outer_ipv6_record->pld_len == 672);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record == inner_ipv4_record);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 54);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 652);

	// LAYER_PROTO_TCP
	const struct layer_internal *outer_tcp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_TCP);
	const struct layer_internal *inner_tcp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_TCP);

	EXPECT_TRUE(outer_tcp_record != nullptr);
	EXPECT_TRUE(inner_tcp_record != nullptr);
	EXPECT_TRUE(outer_tcp_record == inner_tcp_record);
	EXPECT_TRUE(outer_tcp_record->hdr_offset == 74);
	EXPECT_TRUE(outer_tcp_record->hdr_len == 20);
	EXPECT_TRUE(outer_tcp_record->pld_len == 632);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001::192:168:40:134-2001::192:168:40:133");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "1.1.1.1-2.2.2.2");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "1.1.1.1:57639-2.2.2.2:22");
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "1.1.1.1:57639-2.2.2.2:22");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "1.1.1.1:57639-2.2.2.2:22-6-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "1.1.1.1:57639-2.2.2.2:22-6-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:vlan:ethertype:ipv6:ip:gre:ppp:ip:udp:dns]
 ******************************************************************************
 *
 * Frame 1: 272 bytes on wire (2176 bits), 272 bytes captured (2176 bits)
 * Ethernet II, Src: Cisco_e6:82:c4 (00:19:06:e6:82:c4), Dst: 10:01:00:00:61:3d (10:01:00:00:61:3d)
 * 	Destination: 10:01:00:00:61:3d (10:01:00:00:61:3d)
 * 	Source: Cisco_e6:82:c4 (00:19:06:e6:82:c4)
 * 	Type: 802.1Q Virtual LAN (0x8100)
 * 802.1Q Virtual LAN, PRI: 0, DEI: 0, ID: 100
 * 	000. .... .... .... = Priority: Best Effort (default) (0)
 * 	...0 .... .... .... = DEI: Ineligible
 * 	.... 0000 0110 0100 = ID: 100
 * 	Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2607:fcd0:100:2300::b108:2a6b, Dst: 2402:f000:1:8e01::5555
 * 	0110 .... = Version: 6
 * 	.... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	.... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 * 	Payload Length: 214
 * 	Next Header: IPIP (4)
 * 	Hop Limit: 57
 * 	Source Address: 2607:fcd0:100:2300::b108:2a6b
 * 	Destination Address: 2402:f000:1:8e01::5555
 * Internet Protocol Version 4, Src: 192.52.166.154, Dst: 16.0.0.200
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 214
 * 	Identification: 0x842f (33839)
 * 	010. .... = Flags: 0x2, Don't fragment
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 64
 * 	Protocol: Generic Routing Encapsulation (47)
 * 	Header Checksum: 0x3e33 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 192.52.166.154
 * 	Destination Address: 16.0.0.200
 * Generic Routing Encapsulation (PPP)
 * 	Flags and Version: 0x3081
 * 	Protocol Type: PPP (0x880b)
 * 	Payload Length: 178
 * 	Call ID: 17
 * 	Sequence Number: 538640
 * 	Acknowledgment Number: 429725
 * Point-to-Point Protocol
 * 	Address: 0xff
 * 	Control: 0x03
 * 	Protocol: Internet Protocol version 4 (0x0021)
 * Internet Protocol Version 4, Src: 8.8.8.8, Dst: 172.16.44.3
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 174
 * 	Identification: 0x2f9c (12188)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 50
 * 	Protocol: UDP (17)
 * 	Header Checksum: 0x7080 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 8.8.8.8
 * 	Destination Address: 172.16.44.3
 * User Datagram Protocol, Src Port: 53, Dst Port: 9879
 * 	Source Port: 53
 * 	Destination Port: 9879
 * 	Length: 154
 * 	Checksum: 0x45d9 [unverified]
 * 	[Checksum Status: Unverified]
 * 	[Stream index: 0]
 * 	[Timestamps]
 * 	UDP payload (146 bytes)
 * Domain Name System (response)
 */

unsigned char data3[] = {
	0x10, 0x01, 0x00, 0x00, 0x61, 0x3d, 0x00, 0x19, 0x06, 0xe6, 0x82, 0xc4, 0x81, 0x00, 0x00, 0x64, 0x86, 0xdd, 0x60, 0x00, 0x00, 0x00, 0x00, 0xd6, 0x04, 0x39,
	0x26, 0x07, 0xfc, 0xd0, 0x01, 0x00, 0x23, 0x00, 0x00, 0x00, 0x00, 0x00, 0xb1, 0x08, 0x2a, 0x6b, 0x24, 0x02, 0xf0, 0x00, 0x00, 0x01, 0x8e, 0x01, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x55, 0x55, 0x45, 0x00, 0x00, 0xd6, 0x84, 0x2f, 0x40, 0x00, 0x40, 0x2f, 0x3e, 0x33, 0xc0, 0x34, 0xa6, 0x9a, 0x10, 0x00, 0x00, 0xc8,
	0x30, 0x81, 0x88, 0x0b, 0x00, 0xb2, 0x00, 0x11, 0x00, 0x08, 0x38, 0x10, 0x00, 0x06, 0x8e, 0x9d, 0xff, 0x03, 0x00, 0x21, 0x45, 0x00, 0x00, 0xae, 0x2f, 0x9c,
	0x00, 0x00, 0x32, 0x11, 0x70, 0x80, 0x08, 0x08, 0x08, 0x08, 0xac, 0x10, 0x2c, 0x03, 0x00, 0x35, 0x26, 0x97, 0x00, 0x9a, 0x45, 0xd9, 0xb4, 0xe2, 0x81, 0x83,
	0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x35, 0x78, 0x71, 0x74, 0x2d, 0x64, 0x65, 0x74, 0x65, 0x63, 0x74, 0x2d, 0x6d, 0x6f, 0x64, 0x65, 0x32, 0x2d,
	0x37, 0x38, 0x63, 0x30, 0x36, 0x64, 0x63, 0x37, 0x2d, 0x30, 0x34, 0x61, 0x37, 0x2d, 0x34, 0x38, 0x35, 0x33, 0x2d, 0x38, 0x34, 0x38, 0x33, 0x2d, 0x61, 0x35,
	0x36, 0x32, 0x38, 0x39, 0x37, 0x36, 0x65, 0x32, 0x33, 0x33, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00, 0x06, 0x00, 0x01, 0x00, 0x00, 0x02, 0xf0, 0x00, 0x40,
	0x01, 0x61, 0x0c, 0x72, 0x6f, 0x6f, 0x74, 0x2d, 0x73, 0x65, 0x72, 0x76, 0x65, 0x72, 0x73, 0x03, 0x6e, 0x65, 0x74, 0x00, 0x05, 0x6e, 0x73, 0x74, 0x6c, 0x64,
	0x0c, 0x76, 0x65, 0x72, 0x69, 0x73, 0x69, 0x67, 0x6e, 0x2d, 0x67, 0x72, 0x73, 0x03, 0x63, 0x6f, 0x6d, 0x00, 0x78, 0x0d, 0x09, 0x09, 0x00, 0x00, 0x07, 0x08,
	0x00, 0x00, 0x03, 0x84, 0x00, 0x09, 0x3a, 0x80, 0x00, 0x01, 0x51, 0x80};

#if 1
TEST(PACKET_PARSE, ETH_VLAN_IP6_IP4_GRE_PPP_IP4_UDP_DNS)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data3, sizeof(data3));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data3 == 126);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 258);

	// LAYER_PROTO_VLAN
	const struct layer_internal *outer_vlan_record = packet_get_outermost_layer(&handler, LAYER_PROTO_VLAN);
	const struct layer_internal *inner_vlan_record = packet_get_innermost_layer(&handler, LAYER_PROTO_VLAN);

	EXPECT_TRUE(outer_vlan_record != nullptr);
	EXPECT_TRUE(inner_vlan_record != nullptr);
	EXPECT_TRUE(outer_vlan_record == inner_vlan_record);
	EXPECT_TRUE(outer_vlan_record->hdr_offset == 14);
	EXPECT_TRUE(outer_vlan_record->hdr_len == 4);
	EXPECT_TRUE(outer_vlan_record->pld_len == 254);

	// LAYER_PROTO_IPV6
	const struct layer_internal *outer_ipv6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV6);
	const struct layer_internal *inner_ipv6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(outer_ipv6_record != nullptr);
	EXPECT_TRUE(inner_ipv6_record != nullptr);
	EXPECT_TRUE(outer_ipv6_record == inner_ipv6_record);
	EXPECT_TRUE(outer_ipv6_record->hdr_offset == 18);
	EXPECT_TRUE(outer_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(outer_ipv6_record->pld_len == 214);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 58);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 194);

	// LAYER_PROTO_GRE
	const struct layer_internal *outer_gre_record = packet_get_outermost_layer(&handler, LAYER_PROTO_GRE);
	const struct layer_internal *inner_ger_record = packet_get_innermost_layer(&handler, LAYER_PROTO_GRE);

	EXPECT_TRUE(outer_gre_record != nullptr);
	EXPECT_TRUE(inner_ger_record != nullptr);
	EXPECT_TRUE(outer_gre_record == inner_ger_record);
	EXPECT_TRUE(outer_gre_record->hdr_offset == 78);
	EXPECT_TRUE(outer_gre_record->hdr_len == 16);
	EXPECT_TRUE(outer_gre_record->pld_len == 178);

	// LAYER_PROTO_PPP
	const struct layer_internal *outer_ppp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_PPP);
	const struct layer_internal *inner_ppp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_PPP);

	EXPECT_TRUE(outer_ppp_record != nullptr);
	EXPECT_TRUE(inner_ppp_record != nullptr);
	EXPECT_TRUE(outer_ppp_record == inner_ppp_record);
	EXPECT_TRUE(outer_ppp_record->hdr_offset == 94);
	EXPECT_TRUE(outer_ppp_record->hdr_len == 4);
	EXPECT_TRUE(outer_ppp_record->pld_len == 174);

	// LAYER_PROTO_IPV4
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record->hdr_offset == 98);
	EXPECT_TRUE(inner_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(inner_ipv4_record->pld_len == 154);

	// LAYER_PROTO_UDP
	const struct layer_internal *outer_udp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_UDP);
	const struct layer_internal *inner_udp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(outer_udp_record != nullptr);
	EXPECT_TRUE(inner_udp_record != nullptr);
	EXPECT_TRUE(outer_udp_record == inner_udp_record);
	EXPECT_TRUE(outer_udp_record->hdr_offset == 118);
	EXPECT_TRUE(outer_udp_record->hdr_len == 8);
	EXPECT_TRUE(outer_udp_record->pld_len == 146);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2607:fcd0:100:2300::b108:2a6b-2402:f000:1:8e01::5555");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "8.8.8.8-172.16.44.3");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "8.8.8.8:53-172.16.44.3:9879");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "8.8.8.8:53-172.16.44.3:9879");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "8.8.8.8:53-172.16.44.3:9879-17-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "8.8.8.8:53-172.16.44.3:9879-17-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:ipv6:tcp]
 ******************************************************************************
 *
 * Frame 1: 106 bytes on wire (848 bits), 106 bytes captured (848 bits)
 * Ethernet II, Src: JuniperN_45:88:29 (2c:6b:f5:45:88:29), Dst: JuniperN_2a:a2:00 (5c:5e:ab:2a:a2:00)
 * 	Destination: JuniperN_2a:a2:00 (5c:5e:ab:2a:a2:00)
 * 	Source: JuniperN_45:88:29 (2c:6b:f5:45:88:29)
 * 	Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 210.77.88.163, Dst: 59.66.4.50
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 92
 * 	Identification: 0x0b4d (2893)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 59
 * 	Protocol: IPv6 (41)
 * 	Header Checksum: 0x09c8 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 210.77.88.163
 * 	Destination Address: 59.66.4.50
 * Internet Protocol Version 6, Src: 2001:da8:200:900e:200:5efe:d24d:58a3, Dst: 2600:140e:6::1702:1058
 * 	0110 .... = Version: 6
 * 	.... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	.... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 * 	Payload Length: 32
 * 	Next Header: TCP (6)
 * 	Hop Limit: 64
 * 	Source Address: 2001:da8:200:900e:200:5efe:d24d:58a3
 * 	Destination Address: 2600:140e:6::1702:1058
 * 	[Source ISATAP IPv4: 210.77.88.163]
 * Transmission Control Protocol, Src Port: 52556, Dst Port: 80, Seq: 0, Len: 0
 * 	Source Port: 52556
 * 	Destination Port: 80
 * 	[Stream index: 0]
 * 	[Conversation completeness: Complete, WITH_DATA (31)]
 * 	[TCP Segment Len: 0]
 * 	Sequence Number: 0    (relative sequence number)
 * 	Sequence Number (raw): 2172673142
 * 	[Next Sequence Number: 1    (relative sequence number)]
 * 	Acknowledgment Number: 0
 * 	Acknowledgment number (raw): 0
 * 	1000 .... = Header Length: 32 bytes (8)
 * 	Flags: 0x002 (SYN)
 * 	Window: 8192
 * 	[Calculated window size: 8192]
 * 	Checksum: 0xf757 [unverified]
 * 	[Checksum Status: Unverified]
 * 	Urgent Pointer: 0
 * 	Options: (12 bytes), Maximum segment size, No-Operation (NOP), Window scale, No-Operation (NOP), No-Operation (NOP), SACK permitted
 * 	[Timestamps]
 */

unsigned char data4[] = {
	0x5c, 0x5e, 0xab, 0x2a, 0xa2, 0x00, 0x2c, 0x6b, 0xf5, 0x45, 0x88, 0x29, 0x08, 0x00, 0x45, 0x00, 0x00, 0x5c, 0x0b, 0x4d, 0x00, 0x00, 0x3b, 0x29, 0x09, 0xc8,
	0xd2, 0x4d, 0x58, 0xa3, 0x3b, 0x42, 0x04, 0x32, 0x60, 0x00, 0x00, 0x00, 0x00, 0x20, 0x06, 0x40, 0x20, 0x01, 0x0d, 0xa8, 0x02, 0x00, 0x90, 0x0e, 0x02, 0x00,
	0x5e, 0xfe, 0xd2, 0x4d, 0x58, 0xa3, 0x26, 0x00, 0x14, 0x0e, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17, 0x02, 0x10, 0x58, 0xcd, 0x4c, 0x00, 0x50,
	0x81, 0x80, 0x5c, 0x76, 0x00, 0x00, 0x00, 0x00, 0x80, 0x02, 0x20, 0x00, 0xf7, 0x57, 0x00, 0x00, 0x02, 0x04, 0x04, 0xc4, 0x01, 0x03, 0x03, 0x08, 0x01, 0x01,
	0x04, 0x02};

#if 1
TEST(PACKET_PARSE, ETH_IP4_IP6_TCP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data4, sizeof(data4));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data4 == 106);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 92);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record == inner_ipv4_record);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 72);

	// LAYER_PROTO_IPV6
	const struct layer_internal *outer_ipv6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV6);
	const struct layer_internal *inner_ipv6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(outer_ipv6_record != nullptr);
	EXPECT_TRUE(inner_ipv6_record != nullptr);
	EXPECT_TRUE(outer_ipv6_record == inner_ipv6_record);
	EXPECT_TRUE(outer_ipv6_record->hdr_offset == 34);
	EXPECT_TRUE(outer_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(outer_ipv6_record->pld_len == 32);

	// LAYER_PROTO_TCP
	const struct layer_internal *outer_tcp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_TCP);
	const struct layer_internal *inner_tcp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_TCP);

	EXPECT_TRUE(outer_tcp_record != nullptr);
	EXPECT_TRUE(inner_tcp_record != nullptr);
	EXPECT_TRUE(outer_tcp_record == inner_tcp_record);
	EXPECT_TRUE(outer_tcp_record->hdr_offset == 74);
	EXPECT_TRUE(outer_tcp_record->hdr_len == 32);
	EXPECT_TRUE(outer_tcp_record->pld_len == 0);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "210.77.88.163-59.66.4.50");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001:da8:200:900e:200:5efe:d24d:58a3-2600:140e:6::1702:1058");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001:da8:200:900e:200:5efe:d24d:58a3:52556-2600:140e:6::1702:1058:80");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001:da8:200:900e:200:5efe:d24d:58a3:52556-2600:140e:6::1702:1058:80");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001:da8:200:900e:200:5efe:d24d:58a3:52556-2600:140e:6::1702:1058:80-6-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001:da8:200:900e:200:5efe:d24d:58a3:52556-2600:140e:6::1702:1058:80-6-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ipv6:ipv6:udp:data]
 ******************************************************************************
 *
 * Frame 1: 106 bytes on wire (848 bits), 106 bytes captured (848 bits)
 * Ethernet II, Src: 00:00:00_00:00:00 (00:00:00:00:00:00), Dst: Broadcast (ff:ff:ff:ff:ff:ff)
 *     Destination: Broadcast (ff:ff:ff:ff:ff:ff)
 *     Source: 00:00:00_00:00:00 (00:00:00:00:00:00)
 *     Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2001:4f8:4:7:2e0:81ff:fe52:ffff, Dst: 2001:4f8:4:7:2e0:81ff:fe52:9a6b
 *     0110 .... = Version: 6
 *     .... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *     .... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 *     Payload Length: 52
 *     Next Header: IPv6 (41)
 *     Hop Limit: 64
 *     Source Address: 2001:4f8:4:7:2e0:81ff:fe52:ffff
 *     Destination Address: 2001:4f8:4:7:2e0:81ff:fe52:9a6b
 *     [Source SLAAC MAC: TyanComp_52:ff:ff (00:e0:81:52:ff:ff)]
 *     [Destination SLAAC MAC: TyanComp_52:9a:6b (00:e0:81:52:9a:6b)]
 * Internet Protocol Version 6, Src: dead::beef, Dst: cafe::babe
 *     0110 .... = Version: 6
 *     .... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *     .... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 *     Payload Length: 12
 *     Next Header: UDP (17)
 *     Hop Limit: 64
 *     Source Address: dead::beef
 *     Destination Address: cafe::babe
 * User Datagram Protocol, Src Port: 30000, Dst Port: 13000
 *     Source Port: 30000
 *     Destination Port: 13000
 *     Length: 12
 *     Checksum: 0x83d2 [unverified]
 *     [Checksum Status: Unverified]
 *     [Stream index: 0]
 *     [Timestamps]
 *     UDP payload (4 bytes)
 * Data (4 bytes)
 */

unsigned char data5[] = {
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x86, 0xdd, 0x60, 0x00, 0x00, 0x00, 0x00, 0x34, 0x29, 0x40, 0x20, 0x01, 0x04, 0xf8,
	0x00, 0x04, 0x00, 0x07, 0x02, 0xe0, 0x81, 0xff, 0xfe, 0x52, 0xff, 0xff, 0x20, 0x01, 0x04, 0xf8, 0x00, 0x04, 0x00, 0x07, 0x02, 0xe0, 0x81, 0xff, 0xfe, 0x52,
	0x9a, 0x6b, 0x60, 0x00, 0x00, 0x00, 0x00, 0x0c, 0x11, 0x40, 0xde, 0xad, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xbe, 0xef,
	0xca, 0xfe, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xba, 0xbe, 0x75, 0x30, 0x32, 0xc8, 0x00, 0x0c, 0x83, 0xd2, 0x58, 0x58,
	0x58, 0x58};

#if 1
TEST(PACKET_PARSE, ETH_IP6_IP6_UDP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data5, sizeof(data5));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data5 == 102);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 92);

	// LAYER_PROTO_IPV6
	const struct layer_internal *outer_ipv6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(outer_ipv6_record != nullptr);
	EXPECT_TRUE(outer_ipv6_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(outer_ipv6_record->pld_len == 52);

	// LAYER_PROTO_IPV6
	const struct layer_internal *inner_ipv6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(inner_ipv6_record != nullptr);
	EXPECT_TRUE(inner_ipv6_record->hdr_offset == 54);
	EXPECT_TRUE(inner_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(inner_ipv6_record->pld_len == 12);

	// LAYER_PROTO_UDP
	const struct layer_internal *outer_udp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_UDP);
	const struct layer_internal *inner_udp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(outer_udp_record != nullptr);
	EXPECT_TRUE(inner_udp_record != nullptr);
	EXPECT_TRUE(outer_udp_record == inner_udp_record);
	EXPECT_TRUE(outer_udp_record->hdr_offset == 94);
	EXPECT_TRUE(outer_udp_record->hdr_len == 8);
	EXPECT_TRUE(outer_udp_record->pld_len == 4);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001:4f8:4:7:2e0:81ff:fe52:ffff-2001:4f8:4:7:2e0:81ff:fe52:9a6b");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "dead::beef-cafe::babe");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "dead::beef:30000-cafe::babe:13000");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "dead::beef:30000-cafe::babe:13000");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "dead::beef:30000-cafe::babe:13000-17-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "dead::beef:30000-cafe::babe:13000-17-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:mpls:ip:tcp]
 ******************************************************************************
 *
 * Frame 1: 70 bytes on wire (560 bits), 70 bytes captured (560 bits)
 * Ethernet II, Src: Hangzhou_d9:28:cc (00:23:89:d9:28:cc), Dst: HuaweiTe_7f:eb:f7 (d4:6a:a8:7f:eb:f7)
 * 	Destination: HuaweiTe_7f:eb:f7 (d4:6a:a8:7f:eb:f7)
 * 	Source: Hangzhou_d9:28:cc (00:23:89:d9:28:cc)
 * 	Type: MPLS label switched packet (0x8847)
 * MultiProtocol Label Switching Header, Label: 18, Exp: 6, S: 1, TTL: 254
 * 	0000 0000 0000 0001 0010 .... .... .... = MPLS Label: 18 (0x00012)
 * 	.... .... .... .... .... 110. .... .... = MPLS Experimental Bits: 6
 * 	.... .... .... .... .... ...1 .... .... = MPLS Bottom Of Label Stack: 1
 * 	.... .... .... .... .... .... 1111 1110 = MPLS TTL: 254
 * Internet Protocol Version 4, Src: 119.40.37.65, Dst: 123.125.29.250
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 52
 * 	Identification: 0x02a1 (673)
 * 	010. .... = Flags: 0x2, Don't fragment
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 126
 * 	Protocol: TCP (6)
 * 	Header Checksum: 0xc442 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 119.40.37.65
 * 	Destination Address: 123.125.29.250
 * Transmission Control Protocol, Src Port: 61853, Dst Port: 80, Seq: 0, Len: 0
 * 	Source Port: 61853
 * 	Destination Port: 80
 * 	[Stream index: 0]
 * 	[Conversation completeness: Complete, WITH_DATA (31)]
 * 	[TCP Segment Len: 0]
 * 	Sequence Number: 0    (relative sequence number)
 * 	Sequence Number (raw): 1710561749
 * 	[Next Sequence Number: 1    (relative sequence number)]
 * 	Acknowledgment Number: 0
 * 	Acknowledgment number (raw): 0
 * 	1000 .... = Header Length: 32 bytes (8)
 * 	Flags: 0x002 (SYN)
 * 	Window: 8192
 * 	[Calculated window size: 8192]
 * 	Checksum: 0xa777 [unverified]
 * 	[Checksum Status: Unverified]
 * 	Urgent Pointer: 0
 * 	Options: (12 bytes), Maximum segment size, No-Operation (NOP), Window scale, No-Operation (NOP), No-Operation (NOP), SACK permitted
 * 	[Timestamps]
 */

unsigned char data6[] = {
	0xd4, 0x6a, 0xa8, 0x7f, 0xeb, 0xf7, 0x00, 0x23, 0x89, 0xd9, 0x28, 0xcc, 0x88, 0x47, 0x00, 0x01, 0x2d, 0xfe, 0x45, 0x00, 0x00, 0x34, 0x02, 0xa1, 0x40, 0x00,
	0x7e, 0x06, 0xc4, 0x42, 0x77, 0x28, 0x25, 0x41, 0x7b, 0x7d, 0x1d, 0xfa, 0xf1, 0x9d, 0x00, 0x50, 0x65, 0xf5, 0x19, 0xd5, 0x00, 0x00, 0x00, 0x00, 0x80, 0x02,
	0x20, 0x00, 0xa7, 0x77, 0x00, 0x00, 0x02, 0x04, 0x05, 0xb4, 0x01, 0x03, 0x03, 0x08, 0x01, 0x01, 0x04, 0x02};

#if 1
TEST(PACKET_PARSE, ETH_MPLS_IP4_TCP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data6, sizeof(data6));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data6 == 70);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 56);

	// LAYER_PROTO_MPLS
	const struct layer_internal *outer_mpls_record = packet_get_outermost_layer(&handler, LAYER_PROTO_MPLS);
	const struct layer_internal *inner_mpls_record = packet_get_innermost_layer(&handler, LAYER_PROTO_MPLS);

	EXPECT_TRUE(outer_mpls_record != nullptr);
	EXPECT_TRUE(inner_mpls_record != nullptr);
	EXPECT_TRUE(outer_mpls_record == inner_mpls_record);
	EXPECT_TRUE(outer_mpls_record->hdr_offset == 14);
	EXPECT_TRUE(outer_mpls_record->hdr_len == 4);
	EXPECT_TRUE(outer_mpls_record->pld_len == 52);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record == inner_ipv4_record);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 18);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 32);

	// LAYER_PROTO_TCP
	const struct layer_internal *outer_tcp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_TCP);
	const struct layer_internal *inner_tcp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_TCP);

	EXPECT_TRUE(outer_tcp_record != nullptr);
	EXPECT_TRUE(inner_tcp_record != nullptr);
	EXPECT_TRUE(outer_tcp_record == inner_tcp_record);
	EXPECT_TRUE(outer_tcp_record->hdr_offset == 38);
	EXPECT_TRUE(outer_tcp_record->hdr_len == 32);
	EXPECT_TRUE(outer_tcp_record->pld_len == 0);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "119.40.37.65-123.125.29.250");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "119.40.37.65-123.125.29.250");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "119.40.37.65:61853-123.125.29.250:80");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "119.40.37.65:61853-123.125.29.250:80");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "119.40.37.65:61853-123.125.29.250:80-6-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "119.40.37.65:61853-123.125.29.250:80-6-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:mpls:ip:tcp]
 ******************************************************************************
 *
 * Frame 1: 66 bytes on wire (528 bits), 66 bytes captured (528 bits)
 * Ethernet II, Src: Cisco_05:28:38 (00:30:96:05:28:38), Dst: Cisco_e6:fc:39 (00:30:96:e6:fc:39)
 * 	Destination: Cisco_e6:fc:39 (00:30:96:e6:fc:39)
 * 	Source: Cisco_05:28:38 (00:30:96:05:28:38)
 * 	Type: MPLS label switched packet (0x8847)
 * MultiProtocol Label Switching Header, Label: 18, Exp: 5, S: 0, TTL: 255
 * 	0000 0000 0000 0001 0010 .... .... .... = MPLS Label: 18 (0x00012)
 * 	.... .... .... .... .... 101. .... .... = MPLS Experimental Bits: 5
 * 	.... .... .... .... .... ...0 .... .... = MPLS Bottom Of Label Stack: 0
 * 	.... .... .... .... .... .... 1111 1111 = MPLS TTL: 255
 * MultiProtocol Label Switching Header, Label: 16, Exp: 5, S: 1, TTL: 255
 * 	0000 0000 0000 0001 0000 .... .... .... = MPLS Label: 16 (0x00010)
 * 	.... .... .... .... .... 101. .... .... = MPLS Experimental Bits: 5
 * 	.... .... .... .... .... ...1 .... .... = MPLS Bottom Of Label Stack: 1
 * 	.... .... .... .... .... .... 1111 1111 = MPLS TTL: 255
 * Internet Protocol Version 4, Src: 10.31.0.1, Dst: 10.34.0.1
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0xb0 (DSCP: Unknown, ECN: Not-ECT)
 * 	Total Length: 44
 * 	Identification: 0x0000 (0)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 255
 * 	Protocol: TCP (6)
 * 	Header Checksum: 0xa6d9 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 10.31.0.1
 * 	Destination Address: 10.34.0.1
 * Transmission Control Protocol, Src Port: 11001, Dst Port: 23, Seq: 0, Len: 0
 * 	Source Port: 11001
 * 	Destination Port: 23
 * 	[Stream index: 0]
 * 	[Conversation completeness: Incomplete (29)]
 * 	[TCP Segment Len: 0]
 * 	Sequence Number: 0    (relative sequence number)
 * 	Sequence Number (raw): 3481568569
 * 	[Next Sequence Number: 1    (relative sequence number)]
 * 	Acknowledgment Number: 0
 * 	Acknowledgment number (raw): 0
 * 	0110 .... = Header Length: 24 bytes (6)
 * 	Flags: 0x002 (SYN)
 * 	Window: 4128
 * 	[Calculated window size: 4128]
 * 	Checksum: 0xf791 [unverified]
 * 	[Checksum Status: Unverified]
 * 	Urgent Pointer: 0
 * 	Options: (4 bytes), Maximum segment size
 * 	[Timestamps]
 */

unsigned char data7[] = {
	0x00, 0x30, 0x96, 0xe6, 0xfc, 0x39, 0x00, 0x30, 0x96, 0x05, 0x28, 0x38, 0x88, 0x47, 0x00, 0x01, 0x2a, 0xff, 0x00, 0x01, 0x0b, 0xff, 0x45, 0xb0, 0x00, 0x2c,
	0x00, 0x00, 0x00, 0x00, 0xff, 0x06, 0xa6, 0xd9, 0x0a, 0x1f, 0x00, 0x01, 0x0a, 0x22, 0x00, 0x01, 0x2a, 0xf9, 0x00, 0x17, 0xcf, 0x84, 0x85, 0x39, 0x00, 0x00,
	0x00, 0x00, 0x60, 0x02, 0x10, 0x20, 0xf7, 0x91, 0x00, 0x00, 0x02, 0x04, 0x02, 0x18};

#if 1
TEST(PACKET_PARSE, ETH_MPLS_MPLS_IP4_TCP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data7, sizeof(data7));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data7 == 66);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 52);

	// LAYER_PROTO_MPLS
	const struct layer_internal *outer_mpls_record = packet_get_outermost_layer(&handler, LAYER_PROTO_MPLS);

	EXPECT_TRUE(outer_mpls_record != nullptr);
	EXPECT_TRUE(outer_mpls_record->hdr_offset == 14);
	EXPECT_TRUE(outer_mpls_record->hdr_len == 4);
	EXPECT_TRUE(outer_mpls_record->pld_len == 48);

	// LAYER_PROTO_MPLS
	const struct layer_internal *inner_mpls_record = packet_get_innermost_layer(&handler, LAYER_PROTO_MPLS);

	EXPECT_TRUE(inner_mpls_record != nullptr);
	EXPECT_TRUE(inner_mpls_record->hdr_offset == 18);
	EXPECT_TRUE(inner_mpls_record->hdr_len == 4);
	EXPECT_TRUE(inner_mpls_record->pld_len == 44);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record == inner_ipv4_record);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 22);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 24);

	// LAYER_PROTO_TCP
	const struct layer_internal *outer_tcp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_TCP);
	const struct layer_internal *inner_tcp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_TCP);

	EXPECT_TRUE(outer_tcp_record != nullptr);
	EXPECT_TRUE(inner_tcp_record != nullptr);
	EXPECT_TRUE(outer_tcp_record == inner_tcp_record);
	EXPECT_TRUE(outer_tcp_record->hdr_offset == 42);
	EXPECT_TRUE(outer_tcp_record->hdr_len == 24);
	EXPECT_TRUE(outer_tcp_record->pld_len == 0);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.31.0.1-10.34.0.1");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.31.0.1-10.34.0.1");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.31.0.1:11001-10.34.0.1:23");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.31.0.1:11001-10.34.0.1:23");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.31.0.1:11001-10.34.0.1:23-6-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.31.0.1:11001-10.34.0.1:23-6-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:vlan:ethertype:pppoes:ppp:ip:tcp]
 ******************************************************************************
 *
 * Frame 55: 78 bytes on wire (624 bits), 78 bytes captured (624 bits)
 * Ethernet II, Src: 00:00:00_00:04:46 (00:00:00:00:04:46), Dst: 18:10:04:00:02:27 (18:10:04:00:02:27)
 * 	Destination: 18:10:04:00:02:27 (18:10:04:00:02:27)
 * 	Source: 00:00:00_00:04:46 (00:00:00:00:04:46)
 * 	Type: 802.1Q Virtual LAN (0x8100)
 * 802.1Q Virtual LAN, PRI: 3, DEI: 0, ID: 1476
 * 	011. .... .... .... = Priority: Critical Applications (3)
 * 	...0 .... .... .... = DEI: Ineligible
 * 	.... 0101 1100 0100 = ID: 1476
 * 	Type: PPPoE Session (0x8864)
 * PPP-over-Ethernet Session
 * 	0001 .... = Version: 1
 * 	.... 0001 = Type: 1
 * 	Code: Session Data (0x00)
 * 	Session ID: 0xb4bc
 * 	Payload Length: 54
 * Point-to-Point Protocol
 * 	Protocol: Internet Protocol version 4 (0x0021)
 * Internet Protocol Version 4, Src: 100.65.55.0, Dst: 91.185.14.33
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 52
 * 	Identification: 0x4ba7 (19367)
 * 	010. .... = Flags: 0x2, Don't fragment
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 63
 * 	Protocol: TCP (6)
 * 	Header Checksum: 0xeb01 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 100.65.55.0
 * 	Destination Address: 91.185.14.33
 * Transmission Control Protocol, Src Port: 34532, Dst Port: 443, Seq: 491, Ack: 54523, Len: 0
 * 	Source Port: 34532
 * 	Destination Port: 443
 * 	[Stream index: 0]
 * 	[Conversation completeness: Incomplete (12)]
 * 	[TCP Segment Len: 0]
 * 	Sequence Number: 491    (relative sequence number)
 * 	Sequence Number (raw): 3064322674
 * 	[Next Sequence Number: 491    (relative sequence number)]
 * 	Acknowledgment Number: 54523    (relative ack number)
 * 	Acknowledgment number (raw): 2083649568
 * 	1000 .... = Header Length: 32 bytes (8)
 * 	Flags: 0x010 (ACK)
 * 	Window: 4032
 * 	[Calculated window size: 4032]
 * 	[Window size scaling factor: -1 (unknown)]
 * 	Checksum: 0xc361 [unverified]
 * 	[Checksum Status: Unverified]
 * 	Urgent Pointer: 0
 * 	Options: (12 bytes), No-Operation (NOP), No-Operation (NOP), Timestamps
 * 	[Timestamps]
 * 	[SEQ/ACK analysis]
 */

unsigned char data8[] = {
	0x18, 0x10, 0x04, 0x00, 0x02, 0x27, 0x00, 0x00, 0x00, 0x00, 0x04, 0x46, 0x81, 0x00, 0x65, 0xc4, 0x88, 0x64, 0x11, 0x00, 0xb4, 0xbc, 0x00, 0x36, 0x00, 0x21,
	0x45, 0x00, 0x00, 0x34, 0x4b, 0xa7, 0x40, 0x00, 0x3f, 0x06, 0xeb, 0x01, 0x64, 0x41, 0x37, 0x00, 0x5b, 0xb9, 0x0e, 0x21, 0x86, 0xe4, 0x01, 0xbb, 0xb6, 0xa5,
	0xda, 0x72, 0x7c, 0x31, 0xf8, 0x20, 0x80, 0x10, 0x0f, 0xc0, 0xc3, 0x61, 0x00, 0x00, 0x01, 0x01, 0x08, 0x0a, 0x00, 0x6f, 0xab, 0xdf, 0x9c, 0x61, 0xc7, 0xc5};

#if 1
TEST(PACKET_PARSE, ETH_VLAN_PPPOE_IP4_TCP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data8, sizeof(data8));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data8 == 78);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 64);

	// LAYER_PROTO_VLAN
	const struct layer_internal *outer_vlan_record = packet_get_outermost_layer(&handler, LAYER_PROTO_VLAN);
	const struct layer_internal *inner_vlan_record = packet_get_innermost_layer(&handler, LAYER_PROTO_VLAN);

	EXPECT_TRUE(outer_vlan_record != nullptr);
	EXPECT_TRUE(inner_vlan_record != nullptr);
	EXPECT_TRUE(outer_vlan_record == inner_vlan_record);
	EXPECT_TRUE(outer_vlan_record->hdr_offset == 14);
	EXPECT_TRUE(outer_vlan_record->hdr_len == 4);
	EXPECT_TRUE(outer_vlan_record->pld_len == 60);

	// LAYER_PROTO_PPPOE
	const struct layer_internal *outer_pppoe_record = packet_get_outermost_layer(&handler, LAYER_PROTO_PPPOE);
	const struct layer_internal *inner_pppoe_record = packet_get_innermost_layer(&handler, LAYER_PROTO_PPPOE);

	EXPECT_TRUE(outer_pppoe_record != nullptr);
	EXPECT_TRUE(inner_pppoe_record != nullptr);
	EXPECT_TRUE(outer_pppoe_record == inner_pppoe_record);
	EXPECT_TRUE(outer_pppoe_record->hdr_offset == 18);
	EXPECT_TRUE(outer_pppoe_record->hdr_len == 6);
	EXPECT_TRUE(outer_pppoe_record->pld_len == 54);

	// LAYER_PROTO_PPP
	const struct layer_internal *outer_ppp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_PPP);
	const struct layer_internal *inner_ppp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_PPP);

	EXPECT_TRUE(outer_ppp_record != nullptr);
	EXPECT_TRUE(inner_ppp_record != nullptr);
	EXPECT_TRUE(outer_ppp_record == inner_ppp_record);
	EXPECT_TRUE(outer_ppp_record->hdr_offset == 24);
	EXPECT_TRUE(outer_ppp_record->hdr_len == 2);
	EXPECT_TRUE(outer_ppp_record->pld_len == 52);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record == inner_ipv4_record);

	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 26);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 32);

	// LAYER_PROTO_TCP
	const struct layer_internal *outer_tcp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_TCP);
	const struct layer_internal *inner_tcp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_TCP);

	EXPECT_TRUE(outer_tcp_record != nullptr);
	EXPECT_TRUE(inner_tcp_record != nullptr);
	EXPECT_TRUE(outer_tcp_record == inner_tcp_record);
	EXPECT_TRUE(outer_tcp_record->hdr_offset == 46);
	EXPECT_TRUE(outer_tcp_record->hdr_len == 32);
	EXPECT_TRUE(outer_tcp_record->pld_len == 0);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "100.65.55.0-91.185.14.33");
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "100.65.55.0-91.185.14.33");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "100.65.55.0:34532-91.185.14.33:443");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "100.65.55.0:34532-91.185.14.33:443");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "100.65.55.0:34532-91.185.14.33:443-6-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "100.65.55.0:34532-91.185.14.33:443-6-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ipv6:udp:gtp:ipv6:tcp:ja3:tls]
 ******************************************************************************
 *
 * Frame 1: 1442 bytes on wire (11536 bits), 1442 bytes captured (11536 bits)
 * Ethernet II, Src: zte_0e:f5:40 (74:4a:a4:0e:f5:40), Dst: HuaweiTe_40:e9:c2 (ac:b3:b5:40:e9:c2)
 * 	Destination: HuaweiTe_40:e9:c2 (ac:b3:b5:40:e9:c2)
 * 	Source: zte_0e:f5:40 (74:4a:a4:0e:f5:40)
 * 	Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2409:8034:4040:5300::105, Dst: 2409:8034:4025::60:61
 * 	0110 .... = Version: 6
 * 	.... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	.... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 * 	Payload Length: 1388
 * 	Next Header: UDP (17)
 * 	Hop Limit: 127
 * 	Source Address: 2409:8034:4040:5300::105
 * 	Destination Address: 2409:8034:4025::60:61
 * User Datagram Protocol, Src Port: 2152, Dst Port: 2152
 * 	Source Port: 2152
 * 	Destination Port: 2152
 * 	Length: 1388
 * 	Checksum: 0xeb00 [unverified]
 * 	[Checksum Status: Unverified]
 * 	[Stream index: 0]
 * 	[Timestamps]
 * 	UDP payload (1380 bytes)
 * GPRS Tunneling Protocol
 * 	Flags: 0x30
 * 	Message Type: T-PDU (0xff)
 * 	Length: 1372
 * 	TEID: 0x024c3cbd (38550717)
 * Internet Protocol Version 6, Src: 2409:8c34:4400:700:0:4:0:3, Dst: 2409:8934:5082:2100:ecad:e0e4:530a:c269
 * 	0110 .... = Version: 6
 * 	.... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	.... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 * 	Payload Length: 1332
 * 	Next Header: TCP (6)
 * 	Hop Limit: 56
 * 	Source Address: 2409:8c34:4400:700:0:4:0:3
 * 	Destination Address: 2409:8934:5082:2100:ecad:e0e4:530a:c269
 * Transmission Control Protocol, Src Port: 443, Dst Port: 46582, Seq: 1, Ack: 1, Len: 1312
 * 	Source Port: 443
 * 	Destination Port: 46582
 * 	[Stream index: 0]
 * 	[Conversation completeness: Incomplete (8)]
 * 	[TCP Segment Len: 1312]
 * 	Sequence Number: 1    (relative sequence number)
 * 	Sequence Number (raw): 2198097831
 * 	[Next Sequence Number: 1313    (relative sequence number)]
 * 	Acknowledgment Number: 1    (relative ack number)
 * 	Acknowledgment number (raw): 2264498872
 * 	0101 .... = Header Length: 20 bytes (5)
 * 	Flags: 0x010 (ACK)
 * 	Window: 529
 * 	[Calculated window size: 529]
 * 	[Window size scaling factor: -1 (unknown)]
 * 	Checksum: 0x2c4b [unverified]
 * 	[Checksum Status: Unverified]
 * 	Urgent Pointer: 0
 * 	[Timestamps]
 * 	[SEQ/ACK analysis]
 * 	TCP payload (1312 bytes)
 * Transport Layer Security
 */

unsigned char data9[] = {
	0xac, 0xb3, 0xb5, 0x40, 0xe9, 0xc2, 0x74, 0x4a, 0xa4, 0x0e, 0xf5, 0x40, 0x86, 0xdd, 0x60, 0x00, 0x00, 0x00, 0x05, 0x6c, 0x11, 0x7f, 0x24, 0x09, 0x80, 0x34,
	0x40, 0x40, 0x53, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x05, 0x24, 0x09, 0x80, 0x34, 0x40, 0x25, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x60,
	0x00, 0x61, 0x08, 0x68, 0x08, 0x68, 0x05, 0x6c, 0xeb, 0x00, 0x30, 0xff, 0x05, 0x5c, 0x02, 0x4c, 0x3c, 0xbd, 0x60, 0x00, 0x00, 0x00, 0x05, 0x34, 0x06, 0x38,
	0x24, 0x09, 0x8c, 0x34, 0x44, 0x00, 0x07, 0x00, 0x00, 0x00, 0x00, 0x04, 0x00, 0x00, 0x00, 0x03, 0x24, 0x09, 0x89, 0x34, 0x50, 0x82, 0x21, 0x00, 0xec, 0xad,
	0xe0, 0xe4, 0x53, 0x0a, 0xc2, 0x69, 0x01, 0xbb, 0xb5, 0xf6, 0x83, 0x04, 0x4f, 0xa7, 0x86, 0xf9, 0x82, 0xb8, 0x50, 0x10, 0x02, 0x11, 0x2c, 0x4b, 0x00, 0x00,
	0x17, 0x03, 0x03, 0x3c, 0x8c, 0x87, 0xa0, 0x99, 0x23, 0x5b, 0x53, 0x4a, 0x12, 0x1b, 0xf8, 0xba, 0xe8, 0x83, 0xc2, 0x95, 0xda, 0xb8, 0xea, 0x5b, 0xdc, 0x84,
	0x61, 0xa9, 0x86, 0x7e, 0x43, 0xc7, 0x31, 0x44, 0x6e, 0x11, 0xc1, 0x30, 0x21, 0x03, 0xb4, 0x21, 0x4a, 0xee, 0xc9, 0x2e, 0x14, 0xd2, 0x98, 0x63, 0x12, 0xfe,
	0x79, 0x58, 0xb3, 0x18, 0xa6, 0x8d, 0x0c, 0x62, 0x67, 0x51, 0xef, 0x02, 0x5a, 0xa8, 0xb3, 0x82, 0x1f, 0xe4, 0x51, 0xba, 0xde, 0xee, 0x83, 0x9c, 0x4e, 0xac,
	0x4d, 0xa2, 0xb7, 0x6a, 0x82, 0xe7, 0xbb, 0x00, 0xf7, 0x5a, 0xe7, 0x02, 0x71, 0x7e, 0x7d, 0x6f, 0xf2, 0xe5, 0x47, 0xd0, 0xba, 0x3c, 0x51, 0x09, 0x95, 0xcd,
	0xf6, 0xc9, 0x8b, 0x6f, 0xb0, 0x39, 0x11, 0x0d, 0xe9, 0x0d, 0x4d, 0x29, 0xd4, 0xcb, 0x87, 0xba, 0x11, 0xfa, 0x0d, 0x0b, 0x82, 0x95, 0xa5, 0x84, 0x94, 0x48,
	0xa2, 0xee, 0xa4, 0xb7, 0xb6, 0x76, 0x13, 0x4d, 0x18, 0x42, 0x91, 0x77, 0xad, 0x82, 0x38, 0xee, 0x34, 0x1c, 0xb7, 0xf6, 0x39, 0xdc, 0xa4, 0x23, 0xa1, 0x7c,
	0xa5, 0x0b, 0x7e, 0x4c, 0x8b, 0x81, 0x31, 0x48, 0xea, 0xf4, 0x18, 0x37, 0x09, 0x0a, 0x53, 0x13, 0x05, 0x90, 0x26, 0x10, 0x69, 0xb2, 0xa3, 0x36, 0xbc, 0xa5,
	0x83, 0xd8, 0x16, 0x77, 0x98, 0xc8, 0x21, 0x38, 0xd9, 0x88, 0x0c, 0xa7, 0x16, 0x97, 0x4e, 0x20, 0x6d, 0x68, 0xda, 0x1b, 0x3b, 0x4a, 0x62, 0xe0, 0x36, 0x0d,
	0xbf, 0x30, 0x71, 0xb1, 0xe9, 0xbe, 0x47, 0x77, 0x99, 0xb9, 0xe6, 0x26, 0xab, 0x81, 0x2e, 0x46, 0xf1, 0x1b, 0x1e, 0xfb, 0xd7, 0x81, 0x60, 0x21, 0x4a, 0x71,
	0x85, 0xf7, 0x9c, 0x9c, 0xd4, 0x1c, 0x52, 0xc4, 0x3d, 0x8d, 0x72, 0xf6, 0x7c, 0xd3, 0x58, 0x79, 0x0d, 0x78, 0xd7, 0x7c, 0x29, 0x2b, 0xc3, 0x96, 0x1d, 0xc7,
	0x96, 0x50, 0x42, 0xd7, 0xda, 0xeb, 0x29, 0x8e, 0x2a, 0x72, 0x23, 0x57, 0x0f, 0x6f, 0x37, 0x35, 0xb2, 0x42, 0x76, 0x78, 0xbf, 0xbf, 0x8c, 0x3f, 0x31, 0xa2,
	0x51, 0xec, 0x9e, 0x0d, 0xfd, 0xf2, 0xaf, 0x71, 0xa0, 0x4f, 0xa9, 0xf6, 0x19, 0xcf, 0x3e, 0x4b, 0xc8, 0xaa, 0x38, 0x06, 0xa1, 0x15, 0xde, 0xde, 0xef, 0x9b,
	0x25, 0xa3, 0xcc, 0x47, 0xca, 0x29, 0x30, 0x65, 0x5f, 0xc1, 0x8b, 0x12, 0x63, 0x79, 0xcd, 0x57, 0x4d, 0x99, 0xc0, 0xcd, 0xbe, 0x62, 0xcb, 0xc3, 0xf2, 0x6b,
	0x0b, 0x40, 0xc5, 0xee, 0x79, 0x0a, 0xa4, 0x75, 0x56, 0xe7, 0xe7, 0xf2, 0xfd, 0xe0, 0x72, 0x78, 0x04, 0xa2, 0x50, 0x31, 0x09, 0x8b, 0x57, 0xc3, 0x85, 0x4e,
	0xc4, 0xae, 0xde, 0x8a, 0xfa, 0xf6, 0x31, 0x06, 0xd2, 0x07, 0x25, 0x40, 0xce, 0x0d, 0xfd, 0x26, 0x98, 0x41, 0xa3, 0xa9, 0xa2, 0x8d, 0x8b, 0x7f, 0x6d, 0x63,
	0x87, 0x7e, 0x75, 0x2f, 0x78, 0xc9, 0xd5, 0x04, 0xb2, 0x4f, 0xc9, 0x94, 0xa7, 0x7f, 0xbc, 0x75, 0x7b, 0xb6, 0xfb, 0x2c, 0x46, 0xf6, 0xde, 0x36, 0x31, 0x2a,
	0x32, 0x1d, 0x7f, 0x30, 0x9e, 0x4a, 0x84, 0x69, 0x66, 0xac, 0xef, 0xbe, 0xb3, 0x83, 0x8c, 0xb8, 0x30, 0xd2, 0x3f, 0xcf, 0xb5, 0xbb, 0x65, 0xaa, 0xe7, 0x6b,
	0x74, 0x48, 0x2c, 0xb2, 0x72, 0x2b, 0x78, 0xaf, 0xd0, 0x71, 0x04, 0xa9, 0xb4, 0x65, 0xd9, 0xfc, 0x74, 0x23, 0xff, 0x89, 0xc1, 0x16, 0x23, 0xac, 0x59, 0x16,
	0x89, 0x41, 0xc3, 0xdb, 0xdb, 0x5b, 0x9a, 0x3d, 0x08, 0xc4, 0x12, 0x28, 0xf8, 0x10, 0xa5, 0xad, 0xc6, 0x81, 0xc0, 0x61, 0x48, 0xba, 0x9d, 0xef, 0xc7, 0xf8,
	0xad, 0x9a, 0xbd, 0x87, 0xfa, 0x7f, 0xa2, 0x4e, 0x4d, 0xe0, 0x19, 0xd5, 0x47, 0xc7, 0xd0, 0xfb, 0x00, 0x7b, 0xbf, 0x17, 0x80, 0xfe, 0xf5, 0x27, 0xec, 0x94,
	0x44, 0x3d, 0x4a, 0x34, 0x49, 0x60, 0xb4, 0x8d, 0x71, 0x6d, 0x9c, 0xf4, 0x4c, 0x33, 0xa9, 0x49, 0x58, 0x58, 0x6f, 0xe1, 0xd1, 0x7d, 0x36, 0x51, 0xf4, 0xd8,
	0x0d, 0x0b, 0xfc, 0xeb, 0xae, 0x58, 0x06, 0x08, 0xbf, 0x67, 0x07, 0x28, 0x7e, 0x68, 0x65, 0x79, 0x86, 0xfb, 0x43, 0x0f, 0x0a, 0xef, 0xd0, 0x97, 0x33, 0x10,
	0x7a, 0x20, 0xe8, 0x22, 0xe5, 0xdc, 0x0c, 0xa2, 0xa5, 0x50, 0x1b, 0x08, 0x15, 0xc2, 0xec, 0xd2, 0x06, 0x25, 0xd0, 0x3b, 0xfd, 0xe3, 0xa2, 0x6f, 0x41, 0x15,
	0x6d, 0x9f, 0x5f, 0xc4, 0x07, 0x5c, 0x99, 0x63, 0xd9, 0xd7, 0xdc, 0x90, 0xc9, 0x8f, 0x3a, 0x4b, 0x6a, 0x84, 0xe8, 0x3c, 0xc7, 0x71, 0x50, 0x71, 0x86, 0x71,
	0x7d, 0x54, 0x84, 0x7b, 0xb7, 0xca, 0xd5, 0x42, 0xaf, 0x88, 0xa5, 0xae, 0xa4, 0x9c, 0xfd, 0x71, 0x71, 0x0f, 0x67, 0xaa, 0x1b, 0x61, 0xd7, 0xf4, 0x50, 0x21,
	0x9d, 0x80, 0x6e, 0x54, 0xcd, 0xb6, 0xb9, 0x02, 0x3e, 0x59, 0x50, 0xff, 0xf2, 0xda, 0x21, 0x5c, 0x50, 0x6d, 0x64, 0x8c, 0x33, 0x75, 0x2a, 0xa4, 0x56, 0xb3,
	0xa8, 0xdb, 0xba, 0xbe, 0x52, 0xd4, 0xe5, 0x29, 0x68, 0xe2, 0x6b, 0x94, 0x6b, 0xb3, 0x90, 0x63, 0x91, 0x1a, 0x95, 0xb5, 0xd7, 0x10, 0x1b, 0xd9, 0x93, 0x4f,
	0x33, 0xb6, 0x6a, 0x4e, 0xcd, 0x40, 0x9d, 0x47, 0x76, 0x3e, 0x4b, 0xc7, 0x2f, 0x16, 0x96, 0x64, 0x9d, 0x4e, 0x8c, 0xfb, 0x0f, 0xd2, 0xec, 0x6c, 0xba, 0xf2,
	0x9c, 0xca, 0xd2, 0x3e, 0x64, 0x37, 0x32, 0x20, 0xd7, 0x4c, 0xb0, 0xe7, 0xd3, 0x75, 0x51, 0x3a, 0x94, 0xc1, 0xdf, 0x1c, 0xb3, 0x10, 0xd5, 0x1e, 0xcf, 0x7c,
	0xb7, 0xab, 0x4a, 0x93, 0xf0, 0x78, 0x58, 0x28, 0x63, 0x10, 0xee, 0xb0, 0xd6, 0x14, 0x81, 0x47, 0xeb, 0x2e, 0xc8, 0x6e, 0x33, 0x7e, 0xf3, 0x2d, 0xc8, 0xdb,
	0x29, 0x0c, 0x80, 0xe4, 0x2f, 0x10, 0x07, 0x8e, 0x08, 0x86, 0x97, 0x1b, 0x39, 0x98, 0x39, 0x06, 0xb3, 0x85, 0x53, 0xb7, 0xbb, 0x65, 0x65, 0x85, 0x0e, 0x0a,
	0x7d, 0x29, 0x3d, 0x3f, 0x52, 0xc2, 0x7b, 0x2b, 0x30, 0x94, 0x99, 0x6a, 0x4b, 0xad, 0xe9, 0xec, 0xcb, 0xcd, 0xae, 0x97, 0x45, 0x54, 0xd5, 0x00, 0x5e, 0xd8,
	0xac, 0xeb, 0x99, 0xdc, 0x58, 0x0b, 0x01, 0xeb, 0x32, 0x22, 0xc4, 0xec, 0x4f, 0xd2, 0x15, 0x03, 0x30, 0x88, 0xc7, 0x28, 0xaf, 0x78, 0xf5, 0x38, 0x84, 0x3b,
	0x3b, 0xe9, 0x29, 0x71, 0x50, 0xa3, 0x07, 0x49, 0x3b, 0xc6, 0x97, 0xc6, 0xf9, 0x53, 0x95, 0x51, 0x65, 0x7e, 0xd7, 0xd4, 0xe8, 0x76, 0x6a, 0x6d, 0x37, 0x6b,
	0xa5, 0x59, 0xaa, 0x14, 0x18, 0x8c, 0x8d, 0x65, 0x78, 0x67, 0xfb, 0x60, 0x56, 0xab, 0x04, 0xa0, 0xc2, 0x93, 0x46, 0xf1, 0x2b, 0x0d, 0x3b, 0x38, 0x62, 0x62,
	0x5e, 0xc8, 0x30, 0xf9, 0x45, 0x28, 0x6f, 0xa1, 0xb1, 0x88, 0xf1, 0x2b, 0x3b, 0xf8, 0xae, 0x91, 0x52, 0xc3, 0x72, 0x86, 0xe4, 0xec, 0xc3, 0x54, 0x86, 0xbf,
	0x8f, 0x33, 0xb1, 0x0f, 0x42, 0xc5, 0x9c, 0xb8, 0xc2, 0x67, 0x8b, 0xac, 0x78, 0xd7, 0x63, 0xab, 0x05, 0xc6, 0x6c, 0x37, 0xa1, 0x28, 0xef, 0x95, 0xc9, 0xf5,
	0x12, 0x38, 0x54, 0x34, 0x2e, 0x03, 0x6a, 0xaa, 0xa9, 0x97, 0x72, 0x22, 0x9f, 0x20, 0xec, 0x9e, 0x29, 0x09, 0xd8, 0x38, 0xd1, 0x86, 0x82, 0x99, 0xbd, 0x2a,
	0x03, 0xe9, 0x3d, 0xbd, 0xea, 0xc5, 0x8b, 0xb0, 0x4c, 0x8b, 0x7e, 0x78, 0x08, 0xef, 0x39, 0xa8, 0xb4, 0x47, 0xce, 0x44, 0xc3, 0x3f, 0x52, 0xe4, 0xbd, 0x9e,
	0xf6, 0xed, 0x6f, 0x6c, 0x05, 0x19, 0xa6, 0x0a, 0x1e, 0x48, 0xe3, 0x9b, 0x91, 0x61, 0xef, 0xf5, 0x91, 0x39, 0x70, 0x44, 0x1c, 0x08, 0x2e, 0x2c, 0x6c, 0x27,
	0xb9, 0x0e, 0xcc, 0x74, 0x69, 0xa5, 0xf8, 0x19, 0xd6, 0xbf, 0x57, 0x6c, 0x9a, 0x91, 0x74, 0xfd, 0xc2, 0x31, 0x32, 0x12, 0x06, 0xa3, 0x69, 0x71, 0xda, 0x40,
	0xa1, 0xf3, 0xb5, 0x9a, 0x43, 0xcc, 0xb4, 0x3c, 0x16, 0x40, 0x65, 0x2b, 0x02, 0xac, 0x5c, 0xae, 0xd6, 0x34, 0x34, 0xe3, 0x69, 0x76, 0x2c, 0xa8, 0xdd, 0x04,
	0x92, 0xa6, 0x7a, 0xc0, 0x87, 0x70, 0x8b, 0x85, 0xba, 0x5d, 0xbb, 0x62, 0x70, 0xcc, 0x1f, 0x21, 0x2c, 0x7e, 0xc3, 0x77, 0xcf, 0x23, 0x22, 0xf4, 0x16, 0x8e,
	0xf1, 0x3d, 0xdc, 0x33, 0x99, 0x5e, 0xaa, 0xa2, 0x50, 0x68, 0xde, 0x03, 0x44, 0xbb, 0xc7, 0x16, 0x2a, 0xf2, 0x08, 0xeb, 0x3d, 0x12, 0x6d, 0xcb, 0x2a, 0xaf,
	0xb4, 0x79, 0xdb, 0x74, 0x5e, 0x54, 0x89, 0x73, 0x0c, 0x48, 0x9c, 0x03, 0x33, 0xd2, 0x92, 0x22, 0xdb, 0x3a, 0xa0, 0x8c, 0xe2, 0x30, 0x6f, 0x39, 0xe4, 0xa9,
	0x24, 0x04, 0xbb, 0x85, 0x7d, 0x62, 0xc5, 0xa9, 0x98, 0x92, 0xef, 0xc6, 0xc8, 0xd1, 0x81, 0xad, 0x95, 0x40, 0x27, 0x09, 0xc7, 0x43, 0xcd, 0xb6, 0x94, 0xfc,
	0x1c, 0x7d, 0x1c, 0xd3, 0x47, 0xfe, 0x62, 0x9c, 0xfa, 0xeb, 0xfc, 0x02, 0x2e, 0x48, 0x62, 0xcf, 0x63, 0xdb, 0x63, 0xd9, 0x21, 0x86, 0xe8, 0x96, 0x54, 0xeb,
	0x6a, 0xa8, 0x78, 0x3c, 0x5b, 0xb6, 0xde, 0xa9, 0x04, 0x48, 0x63, 0xb2, 0x10, 0x02, 0x6a, 0x7f, 0x6d, 0xc8, 0x04, 0xdd, 0x99, 0x25, 0x08, 0xff, 0x80, 0x11,
	0x53, 0xfb, 0x7a, 0x07, 0x39, 0xd9, 0x97, 0xca, 0xf0, 0xa7, 0x46, 0x9c, 0xc2, 0xae, 0x2e, 0x05, 0x62, 0xa0, 0xd5, 0x5d, 0x17, 0x0e, 0x5c, 0x7e, 0x9a, 0xb2,
	0xb7, 0x9d, 0xd4, 0x4f, 0xe3, 0xac, 0x64, 0xdb, 0x6f, 0x1d, 0xdf, 0xd8, 0x41, 0xd7, 0xd9, 0x50, 0x55, 0x30, 0xeb, 0x4b, 0x19, 0xce, 0x78, 0x1f, 0xa8, 0x1e,
	0x87, 0x9c, 0x8f, 0x93, 0x97, 0xd4, 0xa2, 0x28, 0x2c, 0x79, 0x22, 0xc8};

#if 1
TEST(PACKET_PARSE, ETH_IP6_UDP_GTP_IP6_TCP_TLS)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data9, sizeof(data9));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data9 == 130);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 1428);

	// LAYER_PROTO_IPV6
	const struct layer_internal *outer_ipv6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(outer_ipv6_record != nullptr);
	EXPECT_TRUE(outer_ipv6_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(outer_ipv6_record->pld_len == 1388);

	// LAYER_PROTO_UDP
	const struct layer_internal *outer_udp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_UDP);
	const struct layer_internal *inner_udp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(outer_udp_record != nullptr);
	EXPECT_TRUE(inner_udp_record != nullptr);
	EXPECT_TRUE(outer_udp_record == inner_udp_record);
	EXPECT_TRUE(outer_udp_record->hdr_offset == 54);
	EXPECT_TRUE(outer_udp_record->hdr_len == 8);
	EXPECT_TRUE(outer_udp_record->pld_len == 1380);

	// LAYER_PROTO_GTP_U
	const struct layer_internal *outer_gtp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_GTP_U);
	const struct layer_internal *inner_gtp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_GTP_U);

	EXPECT_TRUE(outer_gtp_record != nullptr);
	EXPECT_TRUE(inner_gtp_record != nullptr);
	EXPECT_TRUE(outer_gtp_record == inner_gtp_record);
	EXPECT_TRUE(outer_gtp_record->hdr_offset == 62);
	EXPECT_TRUE(outer_gtp_record->hdr_len == 8);
	EXPECT_TRUE(outer_gtp_record->pld_len == 1372);

	// LAYER_PROTO_IPV6
	const struct layer_internal *inner_ipv6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(inner_ipv6_record != nullptr);
	EXPECT_TRUE(inner_ipv6_record->hdr_offset == 70);
	EXPECT_TRUE(inner_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(inner_ipv6_record->pld_len == 1332);

	// LAYER_PROTO_TCP
	const struct layer_internal *outer_tcp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_TCP);
	const struct layer_internal *inner_tcp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_TCP);

	EXPECT_TRUE(outer_tcp_record != nullptr);
	EXPECT_TRUE(inner_tcp_record != nullptr);
	EXPECT_TRUE(outer_tcp_record == inner_tcp_record);
	EXPECT_TRUE(outer_tcp_record->hdr_offset == 110);
	EXPECT_TRUE(outer_tcp_record->hdr_len == 20);
	EXPECT_TRUE(outer_tcp_record->pld_len == 1312);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8034:4040:5300::105-2409:8034:4025::60:61");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8c34:4400:700:0:4:0:3-2409:8934:5082:2100:ecad:e0e4:530a:c269");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8034:4040:5300::105:2152-2409:8034:4025::60:61:2152");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8c34:4400:700:0:4:0:3:443-2409:8934:5082:2100:ecad:e0e4:530a:c269:46582");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8034:4040:5300::105:2152-2409:8034:4025::60:61:2152-17-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8c34:4400:700:0:4:0:3:443-2409:8934:5082:2100:ecad:e0e4:530a:c269:46582-6-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ipv6:udp:gtp:ip:tcp:ja3:tls]
 ******************************************************************************
 *
 * Frame 1: 1470 bytes on wire (11760 bits), 1470 bytes captured (11760 bits)
 * Ethernet II, Src: HuaweiTe_62:ee:70 (60:d7:55:62:ee:70), Dst: zte_0e:f5:1c (74:4a:a4:0e:f5:1c)
 * 	Destination: zte_0e:f5:1c (74:4a:a4:0e:f5:1c)
 * 	Source: HuaweiTe_62:ee:70 (60:d7:55:62:ee:70)
 * 	Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2409:8034:4025::50:a31, Dst: 2409:8034:4040:5301::204
 * 	0110 .... = Version: 6
 * 	.... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	.... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 * 	Payload Length: 1416
 * 	Next Header: UDP (17)
 * 	Hop Limit: 252
 * 	Source Address: 2409:8034:4025::50:a31
 * 	Destination Address: 2409:8034:4040:5301::204
 * User Datagram Protocol, Src Port: 2152, Dst Port: 2152
 * 	Source Port: 2152
 * 	Destination Port: 2152
 * 	Length: 1416
 * 	Checksum: 0xc8df [unverified]
 * 	[Checksum Status: Unverified]
 * 	[Stream index: 0]
 * 	[Timestamps]
 * 	UDP payload (1408 bytes)
 * GPRS Tunneling Protocol
 * 	Flags: 0x30
 * 	Message Type: T-PDU (0xff)
 * 	Length: 1400
 * 	TEID: 0x6c2a4753 (1814710099)
 * Internet Protocol Version 4, Src: 10.49.115.138, Dst: 121.196.250.66
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 1400
 * 	Identification: 0x0003 (3)
 * 	010. .... = Flags: 0x2, Don't fragment
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 64
 * 	Protocol: TCP (6)
 * 	Header Checksum: 0x43bb [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 10.49.115.138
 * 	Destination Address: 121.196.250.66
 * Transmission Control Protocol, Src Port: 50081, Dst Port: 443, Seq: 1, Ack: 1, Len: 1348
 * 	Source Port: 50081
 * 	Destination Port: 443
 * 	[Stream index: 0]
 * 	[Conversation completeness: Incomplete (8)]
 * 	[TCP Segment Len: 1348]
 * 	Sequence Number: 1    (relative sequence number)
 * 	Sequence Number (raw): 1522577104
 * 	[Next Sequence Number: 1349    (relative sequence number)]
 * 	Acknowledgment Number: 1    (relative ack number)
 * 	Acknowledgment number (raw): 3419365570
 * 	1000 .... = Header Length: 32 bytes (8)
 * 	Flags: 0x010 (ACK)
 * 	Window: 2038
 * 	[Calculated window size: 2038]
 * 	[Window size scaling factor: -1 (unknown)]
 * 	Checksum: 0xd3c2 [unverified]
 * 	[Checksum Status: Unverified]
 * 	Urgent Pointer: 0
 * 	Options: (12 bytes), No-Operation (NOP), No-Operation (NOP), Timestamps
 * 	[Timestamps]
 * 	[SEQ/ACK analysis]
 * 	TCP payload (1348 bytes)
 * Transport Layer Security
 */

unsigned char data10[] = {
	0x74, 0x4a, 0xa4, 0x0e, 0xf5, 0x1c, 0x60, 0xd7, 0x55, 0x62, 0xee, 0x70, 0x86, 0xdd, 0x60, 0x00, 0x00, 0x00, 0x05, 0x88, 0x11, 0xfc, 0x24, 0x09, 0x80, 0x34,
	0x40, 0x25, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x50, 0x0a, 0x31, 0x24, 0x09, 0x80, 0x34, 0x40, 0x40, 0x53, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x02, 0x04, 0x08, 0x68, 0x08, 0x68, 0x05, 0x88, 0xc8, 0xdf, 0x30, 0xff, 0x05, 0x78, 0x6c, 0x2a, 0x47, 0x53, 0x45, 0x00, 0x05, 0x78, 0x00, 0x03, 0x40, 0x00,
	0x40, 0x06, 0x43, 0xbb, 0x0a, 0x31, 0x73, 0x8a, 0x79, 0xc4, 0xfa, 0x42, 0xc3, 0xa1, 0x01, 0xbb, 0x5a, 0xc0, 0xae, 0xd0, 0xcb, 0xcf, 0x60, 0xc2, 0x80, 0x10,
	0x07, 0xf6, 0xd3, 0xc2, 0x00, 0x00, 0x01, 0x01, 0x08, 0x0a, 0x85, 0x14, 0x0e, 0xb0, 0xcc, 0x45, 0xf8, 0x5f, 0xef, 0x49, 0x45, 0xa0, 0xbe, 0x21, 0xd6, 0x46,
	0x9f, 0xb5, 0x17, 0xb2, 0xfe, 0x61, 0x2d, 0xed, 0x4f, 0x0c, 0x1e, 0xb5, 0xda, 0x91, 0x40, 0x87, 0xab, 0x02, 0x0d, 0x01, 0xc8, 0xf1, 0x24, 0x05, 0x8a, 0x9d,
	0x8d, 0xfc, 0xbb, 0x82, 0x24, 0xf5, 0x7d, 0x2d, 0x10, 0x66, 0x30, 0x2a, 0xaa, 0x4a, 0x51, 0x8d, 0xe9, 0x9a, 0x65, 0xcf, 0x89, 0x0c, 0x9e, 0x0d, 0x82, 0xda,
	0x5e, 0xd3, 0x98, 0xe3, 0x23, 0xf7, 0x5a, 0xd4, 0x88, 0x94, 0xd2, 0xdf, 0xbe, 0x44, 0x20, 0x2b, 0x21, 0x2d, 0x38, 0xca, 0x29, 0x5e, 0xa3, 0xb7, 0xbb, 0x34,
	0x20, 0x42, 0x02, 0x71, 0x04, 0xda, 0xd2, 0xeb, 0xb8, 0x81, 0xa3, 0x48, 0xc8, 0x54, 0xad, 0x42, 0x35, 0xc4, 0x4f, 0x6b, 0x15, 0x50, 0x22, 0x3e, 0x26, 0xb3,
	0xfc, 0x30, 0x49, 0x71, 0x6f, 0x41, 0x66, 0xa2, 0x2e, 0xe9, 0xd3, 0x1a, 0x69, 0xa8, 0x87, 0x71, 0x65, 0xa2, 0xc7, 0xc7, 0x2b, 0x25, 0x1d, 0x3f, 0xfb, 0xe6,
	0x05, 0xe1, 0x09, 0xb9, 0x76, 0x1d, 0xb9, 0xf9, 0xaf, 0xb4, 0x79, 0xa1, 0x35, 0x05, 0x59, 0x88, 0xa0, 0x07, 0xb5, 0x2d, 0x02, 0x11, 0x0a, 0x89, 0xf1, 0x67,
	0xdb, 0xe5, 0x5c, 0x5c, 0xaa, 0x0e, 0x21, 0xa6, 0xa4, 0x1a, 0x9f, 0x9e, 0xc8, 0x2a, 0x36, 0x6f, 0xcc, 0xa3, 0x13, 0x78, 0xf1, 0xbe, 0x34, 0xa0, 0x35, 0xef,
	0x1f, 0xf4, 0x79, 0xcb, 0x37, 0x3e, 0x77, 0x14, 0xfb, 0x2e, 0x21, 0x4f, 0x6b, 0xe5, 0xe9, 0x3a, 0x90, 0x76, 0xa8, 0x55, 0x09, 0xb6, 0x68, 0xbf, 0x66, 0xae,
	0xf1, 0x55, 0xc0, 0x76, 0x8f, 0x16, 0x86, 0x49, 0x9a, 0x88, 0x01, 0xdb, 0x78, 0x1f, 0xde, 0xc2, 0x33, 0x92, 0xe3, 0x22, 0xc6, 0x8c, 0x20, 0x17, 0xa0, 0xb2,
	0x79, 0xf4, 0x60, 0x8e, 0x98, 0x53, 0xcd, 0x8f, 0xb2, 0x8f, 0x80, 0xda, 0x9f, 0xf6, 0x00, 0x0c, 0xf8, 0x6b, 0xdf, 0x7d, 0x93, 0x48, 0x5a, 0x23, 0x35, 0x0e,
	0x1b, 0xf7, 0x50, 0x87, 0x93, 0x29, 0xaa, 0xa1, 0xb8, 0x98, 0x9f, 0x89, 0xb2, 0x0a, 0x02, 0x27, 0x95, 0x01, 0x84, 0x5a, 0x09, 0xb8, 0xff, 0x23, 0x02, 0x89,
	0xef, 0x1b, 0x64, 0xb2, 0x38, 0x81, 0xc4, 0x36, 0xe3, 0xda, 0xb5, 0x3b, 0x80, 0x45, 0x52, 0x96, 0xab, 0x0e, 0xdb, 0xb6, 0x9c, 0xcb, 0xc4, 0xe5, 0xb9, 0x72,
	0x67, 0x57, 0x4b, 0xb9, 0x55, 0xcb, 0x6b, 0xc4, 0xec, 0x46, 0x4d, 0xa3, 0xe0, 0xda, 0xba, 0x70, 0x3d, 0xa6, 0xa7, 0x3f, 0x58, 0xd2, 0x9f, 0xb0, 0x11, 0x66,
	0xaf, 0x73, 0x09, 0x60, 0x6e, 0xe0, 0x71, 0xa5, 0x65, 0x41, 0x28, 0x3e, 0x70, 0x1d, 0x25, 0x77, 0x6a, 0x4e, 0xed, 0xb9, 0x27, 0x6c, 0xf0, 0xba, 0x54, 0x8d,
	0x77, 0xfb, 0xb6, 0x4e, 0xe2, 0xab, 0x8f, 0xe3, 0xd4, 0x02, 0x65, 0x0a, 0x49, 0xf3, 0xf9, 0xc7, 0x09, 0x76, 0x81, 0xf4, 0xf8, 0x3e, 0x1f, 0x74, 0x30, 0xaf,
	0x3b, 0x9e, 0x97, 0x00, 0xde, 0xd8, 0x9a, 0xaf, 0xcc, 0x72, 0xeb, 0x0a, 0xe7, 0xab, 0xc1, 0x53, 0x62, 0x3f, 0x08, 0xba, 0x43, 0x06, 0x13, 0x0a, 0x3b, 0x5c,
	0xb4, 0xe0, 0xc8, 0xa6, 0x41, 0x45, 0xaa, 0x1a, 0xc9, 0x88, 0x86, 0x31, 0x25, 0x02, 0x4a, 0x76, 0x66, 0xb6, 0x6d, 0xff, 0x50, 0x1d, 0x3c, 0xf3, 0x2d, 0xfe,
	0x7b, 0xb2, 0x75, 0x5d, 0x9a, 0x9a, 0xe5, 0x39, 0x31, 0x4f, 0x7b, 0xa5, 0x6f, 0x94, 0xed, 0x31, 0xd4, 0x61, 0xc7, 0x44, 0x1d, 0x37, 0x19, 0x76, 0x04, 0x0e,
	0xbd, 0xc4, 0x9e, 0xe3, 0xdf, 0x94, 0x49, 0x32, 0x65, 0xd0, 0x37, 0x64, 0xb5, 0x2a, 0x61, 0x2d, 0x05, 0xc5, 0xe5, 0x79, 0x3e, 0xcf, 0x5f, 0x77, 0x0a, 0x7c,
	0x29, 0x34, 0x1a, 0x45, 0x7e, 0x11, 0x68, 0xb4, 0x3a, 0xf6, 0x5b, 0x23, 0xe4, 0x32, 0xa4, 0x11, 0x1a, 0xba, 0xd6, 0x4a, 0x45, 0x42, 0x29, 0xac, 0xb0, 0x17,
	0x05, 0x1b, 0xee, 0xf6, 0x52, 0x6d, 0x8b, 0xb4, 0x3b, 0x63, 0xe2, 0xca, 0xbf, 0x7e, 0xd3, 0xf7, 0x96, 0x75, 0x67, 0x9d, 0x27, 0x15, 0x39, 0xde, 0x5f, 0x66,
	0x74, 0x7c, 0x46, 0x01, 0x48, 0xf7, 0x99, 0x33, 0x7d, 0xc6, 0x81, 0xc4, 0x82, 0x09, 0x00, 0x20, 0x3f, 0x5c, 0xe4, 0x51, 0x88, 0x5b, 0xac, 0x31, 0x17, 0x04,
	0xa4, 0xac, 0xbf, 0x3d, 0xff, 0xad, 0x51, 0x07, 0x0b, 0xc7, 0x26, 0xa7, 0x9f, 0x83, 0x17, 0xd8, 0x2f, 0x6a, 0x47, 0x96, 0x14, 0x47, 0x68, 0xd4, 0xc0, 0xc0,
	0x3b, 0x87, 0x51, 0x30, 0xe9, 0xfa, 0x21, 0x46, 0x80, 0x1a, 0x5a, 0xef, 0x78, 0xd0, 0x3a, 0xac, 0x73, 0x1e, 0x39, 0xba, 0x82, 0x43, 0x5d, 0xef, 0x15, 0x2c,
	0x9a, 0xe5, 0xeb, 0x6a, 0xe7, 0x24, 0x12, 0xe6, 0x2a, 0xd2, 0x09, 0xc2, 0x85, 0x69, 0x9d, 0x73, 0x16, 0xb0, 0xad, 0x51, 0xf8, 0x3d, 0x94, 0x6b, 0xb7, 0xb3,
	0x7f, 0xb4, 0x9e, 0xc1, 0xdc, 0x31, 0x27, 0xa1, 0x2d, 0xfe, 0x30, 0x15, 0x04, 0x20, 0x82, 0xdc, 0xbd, 0x8b, 0xc5, 0xb4, 0xcf, 0x91, 0x85, 0xae, 0x21, 0x5e,
	0x00, 0x10, 0x04, 0x62, 0x8a, 0xe2, 0x66, 0x74, 0xf8, 0x8d, 0x8b, 0x52, 0x17, 0xd9, 0x1a, 0xbd, 0x06, 0x2d, 0x07, 0x6a, 0xf5, 0x8b, 0xdf, 0x85, 0x2e, 0x36,
	0xec, 0x15, 0x6f, 0x7e, 0xd2, 0x04, 0x43, 0x6a, 0xd7, 0x60, 0xf5, 0x53, 0x0d, 0x2e, 0x2d, 0xf5, 0x52, 0x4c, 0xcc, 0xe5, 0xf4, 0x47, 0xdd, 0x34, 0xda, 0xc1,
	0xfc, 0x60, 0x00, 0xaa, 0x68, 0x01, 0x5c, 0x82, 0x4b, 0xf9, 0x57, 0x54, 0x9d, 0xd5, 0x8b, 0xb6, 0x42, 0x77, 0xd4, 0x47, 0x70, 0x23, 0x4c, 0xad, 0xc5, 0x00,
	0x73, 0x9b, 0xbb, 0x65, 0xa7, 0x46, 0x74, 0xcd, 0x2e, 0x61, 0x0f, 0xac, 0xeb, 0x53, 0x5a, 0x87, 0x70, 0xfc, 0x5d, 0x2e, 0xa1, 0xe3, 0x9a, 0x87, 0x01, 0x0f,
	0x2e, 0xef, 0x10, 0xe2, 0x82, 0xd8, 0x12, 0xe7, 0xb8, 0x94, 0xa4, 0xdd, 0x5f, 0xea, 0x21, 0x63, 0x26, 0x43, 0xec, 0xc3, 0x54, 0x76, 0xb1, 0xb2, 0x1c, 0x03,
	0x4c, 0x5c, 0x22, 0xb5, 0x00, 0x7d, 0x77, 0x3a, 0xb6, 0xbf, 0x50, 0xbd, 0xfd, 0x0a, 0x31, 0x2c, 0xdc, 0xab, 0xe2, 0xc0, 0x0b, 0xb6, 0x66, 0xad, 0x9c, 0xca,
	0x94, 0xed, 0xd8, 0x77, 0x1b, 0xf1, 0x94, 0xdd, 0x65, 0x61, 0xda, 0x7b, 0x04, 0x3c, 0x93, 0xcf, 0x96, 0x74, 0x35, 0x8e, 0x41, 0xe1, 0xa4, 0xbc, 0xf2, 0x4f,
	0xe9, 0xb8, 0x16, 0x55, 0x05, 0x5a, 0xac, 0x10, 0xd3, 0xdf, 0xea, 0x6a, 0xf8, 0xe0, 0xf3, 0xdf, 0x66, 0x00, 0xab, 0x3d, 0xb9, 0x44, 0x65, 0x34, 0x49, 0x89,
	0xf2, 0x1d, 0x09, 0xc9, 0xfc, 0xa5, 0x84, 0xa1, 0x03, 0x5b, 0x7a, 0x5c, 0x7e, 0x21, 0xe9, 0xb4, 0x3a, 0x4c, 0x2b, 0x94, 0x64, 0x1d, 0x9b, 0xa5, 0xbf, 0x7e,
	0x1c, 0x97, 0x7e, 0x3d, 0xbe, 0x84, 0xfc, 0xab, 0x6d, 0x2a, 0x50, 0x23, 0x9e, 0x11, 0x3f, 0xe2, 0xa0, 0x68, 0xe7, 0xd5, 0xba, 0x5e, 0x24, 0x8c, 0x4c, 0x46,
	0xe6, 0x5b, 0x10, 0xc3, 0x82, 0x32, 0x17, 0x32, 0xdc, 0xec, 0xaa, 0x1e, 0x73, 0xe5, 0x7d, 0xb8, 0x1c, 0x6c, 0x4c, 0x9f, 0x60, 0x7b, 0x66, 0x4c, 0x90, 0x69,
	0xc4, 0x23, 0x66, 0x67, 0xce, 0x6d, 0x24, 0x1d, 0xcc, 0x8e, 0x78, 0xa1, 0xa7, 0xde, 0x87, 0x81, 0xac, 0x62, 0x54, 0xbc, 0x47, 0x82, 0x3c, 0xad, 0x92, 0x29,
	0xd9, 0xc0, 0xed, 0x0c, 0x11, 0x0e, 0xc5, 0x75, 0xa4, 0xbd, 0xbf, 0xcb, 0x3a, 0xaf, 0x2b, 0x9f, 0xbe, 0xbb, 0xbc, 0x31, 0x07, 0xa7, 0xbe, 0x6c, 0xa9, 0x4e,
	0xff, 0x35, 0x80, 0x2f, 0x09, 0x77, 0xe0, 0xc0, 0xdc, 0x9c, 0xc6, 0xa6, 0x63, 0xab, 0x47, 0x74, 0x5f, 0x5c, 0xae, 0x75, 0xbf, 0x42, 0x67, 0x55, 0x89, 0xcf,
	0xd3, 0x65, 0x8d, 0x5b, 0x6f, 0x5c, 0xf9, 0xd1, 0x78, 0xa2, 0xfd, 0x4f, 0x54, 0x6a, 0x71, 0x0c, 0x58, 0x13, 0xb0, 0x48, 0x0a, 0x7b, 0xcc, 0x84, 0x61, 0xa7,
	0x7d, 0x39, 0xa2, 0xd1, 0xc0, 0xdb, 0x8e, 0x97, 0x20, 0x86, 0x97, 0x20, 0xda, 0xca, 0x56, 0x78, 0x61, 0xc2, 0x2f, 0x36, 0xdb, 0x95, 0xae, 0x7e, 0x8d, 0x97,
	0xcb, 0x45, 0x6a, 0x6d, 0x27, 0xaa, 0xab, 0x4e, 0x88, 0x23, 0xb6, 0x6a, 0x8a, 0xca, 0x71, 0xca, 0x39, 0xa2, 0x98, 0x0d, 0x53, 0xa9, 0x38, 0xd5, 0x9c, 0x5d,
	0x0e, 0x5e, 0xc9, 0xeb, 0x21, 0xab, 0x00, 0xca, 0xff, 0x92, 0x20, 0x9d, 0x65, 0x9d, 0x8d, 0x49, 0x46, 0xbe, 0x51, 0x97, 0xc1, 0x61, 0x02, 0x9e, 0xa8, 0xb9,
	0x2c, 0x27, 0x7d, 0x73, 0xf9, 0x12, 0x16, 0x45, 0x25, 0xbb, 0xb0, 0x51, 0x14, 0x18, 0x07, 0xab, 0xc7, 0x06, 0xc0, 0xe9, 0x1c, 0xf8, 0x6d, 0xe1, 0x80, 0x21,
	0x21, 0x68, 0x24, 0xf7, 0x28, 0xb9, 0x07, 0xd4, 0xd7, 0xdf, 0x3e, 0xff, 0xbc, 0xe3, 0xbc, 0x6e, 0x42, 0x76, 0x63, 0xbc, 0x82, 0x0a, 0xf5, 0x99, 0x65, 0x17,
	0xd2, 0x38, 0xa9, 0xa8, 0x31, 0xce, 0x1f, 0xf7, 0xef, 0x8d, 0x94, 0xae, 0x99, 0x50, 0x30, 0x12, 0xbd, 0x4b, 0x65, 0x56, 0x59, 0xfb, 0x33, 0x7b, 0x99, 0xc7,
	0xe5, 0x80, 0xe6, 0x92, 0x0e, 0x44, 0x1d, 0x17, 0xc2, 0xd0, 0x78, 0x76, 0x9d, 0x5b, 0x7d, 0x3c, 0xb4, 0xf8, 0xcb, 0x2f, 0x83, 0x23, 0x35, 0x49, 0xc0, 0x78,
	0x2d, 0x44, 0x05, 0x64, 0x0f, 0xaa, 0x84, 0x9d, 0x3f, 0xac, 0xef, 0x5b, 0x46, 0x44, 0xb8, 0x15, 0xbe, 0x4f, 0xe7, 0x25, 0xb7, 0xa0, 0xc8, 0x0f, 0x70, 0x1a,
	0xca, 0x7f, 0xce, 0x79, 0x7b, 0xf5, 0x7e, 0x21, 0x35, 0xc7, 0x0e, 0x99, 0xdc, 0x76, 0xe0, 0x36, 0x09, 0x6e, 0x6d, 0x5f, 0x98, 0x5e, 0xb8, 0xa4, 0x88, 0xea,
	0x0b, 0x4b, 0x21, 0xa2, 0x52, 0x86, 0x95, 0x4e, 0x18, 0xac, 0xa2, 0xaf, 0x29, 0x5b, 0xe7, 0x05, 0xa1, 0xc8, 0xe1, 0x80, 0xfa, 0xb6, 0x5a, 0xed, 0x94, 0x32,
	0x4f, 0xe9, 0xf5, 0xf0, 0x61, 0x5d, 0x7f, 0xc4, 0xc4, 0xd1, 0x05, 0x54, 0x13, 0xdb};

#if 1
TEST(PACKET_PARSE, ETH_IP6_UDP_GTP_IP4_TCP_TLS)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data10, sizeof(data10));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data10 == 122);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 1456);

	// LAYER_PROTO_IPV6
	const struct layer_internal *outer_ipv6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV6);
	const struct layer_internal *inner_ipv6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(outer_ipv6_record != nullptr);
	EXPECT_TRUE(inner_ipv6_record != nullptr);
	EXPECT_TRUE(outer_ipv6_record == inner_ipv6_record);
	EXPECT_TRUE(outer_ipv6_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(outer_ipv6_record->pld_len == 1416);

	// LAYER_PROTO_UDP
	const struct layer_internal *outer_udp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_UDP);
	const struct layer_internal *inner_udp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(outer_udp_record != nullptr);
	EXPECT_TRUE(inner_udp_record != nullptr);
	EXPECT_TRUE(outer_udp_record == inner_udp_record);
	EXPECT_TRUE(outer_udp_record->hdr_offset == 54);
	EXPECT_TRUE(outer_udp_record->hdr_len == 8);
	EXPECT_TRUE(outer_udp_record->pld_len == 1408);

	// LAYER_PROTO_GTP_U
	const struct layer_internal *outer_gtp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_GTP_U);
	const struct layer_internal *inner_gtp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_GTP_U);

	EXPECT_TRUE(outer_gtp_record != nullptr);
	EXPECT_TRUE(inner_gtp_record != nullptr);
	EXPECT_TRUE(outer_gtp_record == inner_gtp_record);
	EXPECT_TRUE(outer_gtp_record->hdr_offset == 62);
	EXPECT_TRUE(outer_gtp_record->hdr_len == 8);
	EXPECT_TRUE(outer_gtp_record->pld_len == 1400);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record == inner_ipv4_record);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 70);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 1380);

	// LAYER_PROTO_TCP
	const struct layer_internal *outer_tcp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_TCP);
	const struct layer_internal *inner_tcp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_TCP);

	EXPECT_TRUE(outer_tcp_record != nullptr);
	EXPECT_TRUE(inner_tcp_record != nullptr);
	EXPECT_TRUE(outer_tcp_record == inner_tcp_record);
	EXPECT_TRUE(outer_tcp_record->hdr_offset == 90);
	EXPECT_TRUE(outer_tcp_record->hdr_len == 32);
	EXPECT_TRUE(outer_tcp_record->pld_len == 1348);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8034:4025::50:a31-2409:8034:4040:5301::204");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.49.115.138-121.196.250.66");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8034:4025::50:a31:2152-2409:8034:4040:5301::204:2152");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.49.115.138:50081-121.196.250.66:443");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2409:8034:4025::50:a31:2152-2409:8034:4040:5301::204:2152-17-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.49.115.138:50081-121.196.250.66:443-6-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:udp:vxlan:eth:ethertype:ip:udp:dns]
 ******************************************************************************
 *
 * Frame 1: 124 bytes on wire (992 bits), 124 bytes captured (992 bits)
 * Ethernet II, Src: zte_6c:fa:43 (00:1e:73:6c:fa:43), Dst: Shanghai_0d:0a (e4:95:6e:20:0d:0a)
 * 	Destination: Shanghai_0d:0a (e4:95:6e:20:0d:0a)
 * 	Source: zte_6c:fa:43 (00:1e:73:6c:fa:43)
 * 	Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 10.1.1.1, Dst: 192.168.1.10
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 110
 * 	Identification: 0x0000 (0)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 254
 * 	Protocol: UDP (17)
 * 	Header Checksum: 0xefca [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 10.1.1.1
 * 	Destination Address: 192.168.1.10
 * User Datagram Protocol, Src Port: 50709, Dst Port: 4789
 * 	Source Port: 50709
 * 	Destination Port: 4789
 * 	Length: 90
 * 	Checksum: 0x0000 [zero-value ignored]
 * 	[Stream index: 0]
 * 	[Timestamps]
 * 	UDP payload (82 bytes)
 * Virtual eXtensible Local Area Network
 * 	Flags: 0x0800, VXLAN Network ID (VNI)
 * 	Group Policy ID: 0
 * 	VXLAN Network Identifier (VNI): 458755
 * 	Reserved: 0
 * Ethernet II, Src: WistronI_18:18:41 (3c:97:0e:18:18:41), Dst: DawningI_13:70:7a (e8:61:1f:13:70:7a)
 * 	Destination: DawningI_13:70:7a (e8:61:1f:13:70:7a)
 * 	Source: WistronI_18:18:41 (3c:97:0e:18:18:41)
 * 	Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 192.168.11.193, Dst: 114.114.114.114
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 60
 * 	Identification: 0x0cb6 (3254)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 64
 * 	Protocol: UDP (17)
 * 	Header Checksum: 0xbcad [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 192.168.11.193
 * 	Destination Address: 114.114.114.114
 * User Datagram Protocol, Src Port: 65290, Dst Port: 53
 * 	Source Port: 65290
 * 	Destination Port: 53
 * 	Length: 40
 * 	Checksum: 0x39e4 [unverified]
 * 	[Checksum Status: Unverified]
 * 	[Stream index: 1]
 * 	[Timestamps]
 * 	UDP payload (32 bytes)
 * Domain Name System (query)
 */

unsigned char data11[] = {
	0xe4, 0x95, 0x6e, 0x20, 0x0d, 0x0a, 0x00, 0x1e, 0x73, 0x6c, 0xfa, 0x43, 0x08, 0x00, 0x45, 0x00, 0x00, 0x6e, 0x00, 0x00, 0x00, 0x00, 0xfe, 0x11, 0xef, 0xca,
	0x0a, 0x01, 0x01, 0x01, 0xc0, 0xa8, 0x01, 0x0a, 0xc6, 0x15, 0x12, 0xb5, 0x00, 0x5a, 0x00, 0x00, 0x08, 0x00, 0x00, 0x00, 0x07, 0x00, 0x03, 0x00, 0xe8, 0x61,
	0x1f, 0x13, 0x70, 0x7a, 0x3c, 0x97, 0x0e, 0x18, 0x18, 0x41, 0x08, 0x00, 0x45, 0x00, 0x00, 0x3c, 0x0c, 0xb6, 0x00, 0x00, 0x40, 0x11, 0xbc, 0xad, 0xc0, 0xa8,
	0x0b, 0xc1, 0x72, 0x72, 0x72, 0x72, 0xff, 0x0a, 0x00, 0x35, 0x00, 0x28, 0x39, 0xe4, 0x86, 0x84, 0x01, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x03, 0x77, 0x77, 0x77, 0x06, 0x67, 0x6f, 0x6f, 0x67, 0x6c, 0x65, 0x03, 0x63, 0x6f, 0x6d, 0x00, 0x00, 0x01, 0x00, 0x01};

#if 1
TEST(PACKET_PARSE, ETH_IP4_UDP_VXLAN_ETH_IP4_UDP_DNS)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data11, sizeof(data11));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data11 == 92);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 110);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 90);

	// LAYER_PROTO_UDP
	const struct layer_internal *outer_udp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(outer_udp_record != nullptr);
	EXPECT_TRUE(outer_udp_record->hdr_offset == 34);
	EXPECT_TRUE(outer_udp_record->hdr_len == 8);
	EXPECT_TRUE(outer_udp_record->pld_len == 82);

	// LAYER_PROTO_VXLAN
	const struct layer_internal *outer_g_vlan_record = packet_get_outermost_layer(&handler, LAYER_PROTO_VXLAN);
	const struct layer_internal *inner_g_vlan_record = packet_get_innermost_layer(&handler, LAYER_PROTO_VXLAN);

	EXPECT_TRUE(outer_g_vlan_record != nullptr);
	EXPECT_TRUE(inner_g_vlan_record != nullptr);
	EXPECT_TRUE(outer_g_vlan_record == inner_g_vlan_record);

	EXPECT_TRUE(outer_g_vlan_record->hdr_offset == 42);
	EXPECT_TRUE(outer_g_vlan_record->hdr_len == 8);
	EXPECT_TRUE(outer_g_vlan_record->pld_len == 74);

	// LAYER_PROTO_ETHER
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record->hdr_offset == 50);
	EXPECT_TRUE(inner_eth_record->hdr_len == 14);
	EXPECT_TRUE(inner_eth_record->pld_len == 60);

	// LAYER_PROTO_IPV4
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record->hdr_offset == 64);
	EXPECT_TRUE(inner_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(inner_ipv4_record->pld_len == 40);

	// LAYER_PROTO_UDP
	const struct layer_internal *inner_udp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(inner_udp_record != nullptr);
	EXPECT_TRUE(inner_udp_record->hdr_offset == 84);
	EXPECT_TRUE(inner_udp_record->hdr_len == 8);
	EXPECT_TRUE(inner_udp_record->pld_len == 32);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.1.1.1-192.168.1.10");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "192.168.11.193-114.114.114.114");

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.1.1.1:50709-192.168.1.10:4789");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "192.168.11.193:65290-114.114.114.114:53");

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&outer_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.1.1.1:50709-192.168.1.10:4789-17-0");
	memset(buffer, 0, sizeof(buffer));
	tuple6_to_str(&inner_tuple6, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "192.168.11.193:65290-114.114.114.114:53-17-0");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:mpls:pwethheuristic:pwethcw:eth:ethertype:arp]
 ******************************************************************************
 *
 * Frame 1: 90 bytes on wire (720 bits), 90 bytes captured (720 bits)
 * Ethernet II, Src: cc:01:0d:5c:00:10 (cc:01:0d:5c:00:10), Dst: cc:00:0d:5c:00:10 (cc:00:0d:5c:00:10)
 * 	Destination: cc:00:0d:5c:00:10 (cc:00:0d:5c:00:10)
 * 	Source: cc:01:0d:5c:00:10 (cc:01:0d:5c:00:10)
 * 	Type: MPLS label switched packet (0x8847)
 * MultiProtocol Label Switching Header, Label: 19, Exp: 0, S: 0, TTL: 254
 * 	0000 0000 0000 0001 0011 .... .... .... = MPLS Label: 19 (0x00013)
 * 	.... .... .... .... .... 000. .... .... = MPLS Experimental Bits: 0
 * 	.... .... .... .... .... ...0 .... .... = MPLS Bottom Of Label Stack: 0
 * 	.... .... .... .... .... .... 1111 1110 = MPLS TTL: 254
 * MultiProtocol Label Switching Header, Label: 16, Exp: 0, S: 1, TTL: 255
 * 	0000 0000 0000 0001 0000 .... .... .... = MPLS Label: 16 (0x00010)
 * 	.... .... .... .... .... 000. .... .... = MPLS Experimental Bits: 0
 * 	.... .... .... .... .... ...1 .... .... = MPLS Bottom Of Label Stack: 1
 * 	.... .... .... .... .... .... 1111 1111 = MPLS TTL: 255
 * PW Ethernet Control Word
 * 	Sequence Number: 0
 * Ethernet II, Src: Private_66:68:00 (00:50:79:66:68:00), Dst: Broadcast (ff:ff:ff:ff:ff:ff)
 * 	Destination: Broadcast (ff:ff:ff:ff:ff:ff)
 * 	Source: Private_66:68:00 (00:50:79:66:68:00)
 * 	Type: ARP (0x0806)
 * 	Trailer: 00000000000000000000000000000000000000000000
 * Address Resolution Protocol (request)
 */

unsigned char data12[] = {
	0xcc, 0x00, 0x0d, 0x5c, 0x00, 0x10, 0xcc, 0x01, 0x0d, 0x5c, 0x00, 0x10, 0x88, 0x47, 0x00, 0x01, 0x30, 0xfe, 0x00, 0x01, 0x01, 0xff, 0x00, 0x00, 0x00, 0x00,
	0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x00, 0x50, 0x79, 0x66, 0x68, 0x00, 0x08, 0x06, 0x00, 0x01, 0x08, 0x00, 0x06, 0x04, 0x00, 0x01, 0x00, 0x50, 0x79, 0x66,
	0x68, 0x00, 0xc0, 0xa8, 0x00, 0x0a, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xc0, 0xa8, 0x00, 0x14, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

#if 1
TEST(PACKET_PARSE, ETH_MPLS_MPLS_PWETHCW_ETH_ARP)
{
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data12, sizeof(data12));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data12 == 40);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 76);

	// LAYER_PROTO_MPLS
	const struct layer_internal *outer_mpls_record = packet_get_outermost_layer(&handler, LAYER_PROTO_MPLS);

	EXPECT_TRUE(outer_mpls_record != nullptr);
	EXPECT_TRUE(outer_mpls_record->hdr_offset == 14);
	EXPECT_TRUE(outer_mpls_record->hdr_len == 4);
	EXPECT_TRUE(outer_mpls_record->pld_len == 72);

	// LAYER_PROTO_MPLS
	const struct layer_internal *inner_mpls_record = packet_get_innermost_layer(&handler, LAYER_PROTO_MPLS);

	EXPECT_TRUE(inner_mpls_record != nullptr);
	EXPECT_TRUE(inner_mpls_record->hdr_offset == 18);
	EXPECT_TRUE(inner_mpls_record->hdr_len == 4);
	EXPECT_TRUE(inner_mpls_record->pld_len == 68);

	// LAYER_PROTO_PWETHCW
	const struct layer_internal *inner_pweth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_PWETH);

	EXPECT_TRUE(inner_pweth_record != nullptr);
	EXPECT_TRUE(inner_pweth_record->hdr_offset == 22);
	EXPECT_TRUE(inner_pweth_record->hdr_len == 4);
	EXPECT_TRUE(inner_pweth_record->pld_len == 64);

	// LAYER_PROTO_ETHER
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record->hdr_offset == 26);
	EXPECT_TRUE(inner_eth_record->hdr_len == 14);
	EXPECT_TRUE(inner_eth_record->pld_len == 50);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == -1);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == -1);

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == -1);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == -1);

	/******************************************************
	 * packet_get_outermost/innermost_tuple6
	 ******************************************************/

	struct tuple6 outer_tuple6;
	struct tuple6 inner_tuple6;
	EXPECT_TRUE(packet_get_outermost_tuple6(&handler, &outer_tuple6) == -1);
	EXPECT_TRUE(packet_get_innermost_tuple6(&handler, &inner_tuple6) == -1);
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:icmp:data]
 ******************************************************************************
 *
 * Frame 1: 98 bytes on wire (784 bits), 98 bytes captured (784 bits)
 * Ethernet II, Src: EvocIntellig_36:51:46 (00:22:46:36:51:46), Dst: EvocIntellig_36:51:3c (00:22:46:36:51:3c)
 *     Destination: EvocIntellig_36:51:3c (00:22:46:36:51:3c)
 *     Source: EvocIntellig_36:51:46 (00:22:46:36:51:46)
 *     Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 192.168.40.138, Dst: 192.168.40.134
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 84
 *     Identification: 0x22f6 (8950)
 *     010. .... = Flags: 0x2, Don't fragment
 *         0... .... = Reserved bit: Not set
 *         .1.. .... = Don't fragment: Set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 64
 *     Protocol: ICMP (1)
 *     Header Checksum: 0x4552 [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0x4552]
 *     Source Address: 192.168.40.138
 *     Destination Address: 192.168.40.134
 * Internet Control Message Protocol
 *     Type: 8 (Echo (ping) request)
 *     Code: 0
 *     Checksum: 0xab05 [correct]
 *     [Checksum Status: Good]
 *     Identifier (BE): 24363 (0x5f2b)
 *     Identifier (LE): 11103 (0x2b5f)
 *     Sequence Number (BE): 1 (0x0001)
 *     Sequence Number (LE): 256 (0x0100)
 *     [Response frame: 2]
 *     Timestamp from icmp data: Jun 17, 2020 14:17:58.190124000 CST
 *     [Timestamp from icmp data (relative): -0.134576000 seconds]
 *     Data (40 bytes)
 *         Data: 101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f3031323334353637
 *         [Length: 40]
 */

unsigned char data13[] = {
	0x00, 0x22, 0x46, 0x36, 0x51, 0x3c, 0x00, 0x22, 0x46, 0x36, 0x51, 0x46, 0x08, 0x00, 0x45, 0x00, 0x00, 0x54, 0x22, 0xf6, 0x40, 0x00, 0x40, 0x01, 0x45, 0x52,
	0xc0, 0xa8, 0x28, 0x8a, 0xc0, 0xa8, 0x28, 0x86, 0x08, 0x00, 0xab, 0x05, 0x5f, 0x2b, 0x00, 0x01, 0x96, 0xb5, 0xe9, 0x5e, 0x00, 0x00, 0x00, 0x00, 0xac, 0xe6,
	0x02, 0x00, 0x00, 0x00, 0x00, 0x00, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23,
	0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37};

#if 1
TEST(PACKET_PARSE, ETH_IP4_ICMP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data13, sizeof(data13));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data13 == 14 + 20 + 8);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 84);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record == inner_ipv4_record);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 64);

	// LAYER_PROTO_ICMP
	const struct layer_internal *outer_icmp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ICMP);
	const struct layer_internal *inner_icmp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ICMP);

	EXPECT_TRUE(outer_icmp_record != nullptr);
	EXPECT_TRUE(inner_icmp_record != nullptr);
	EXPECT_TRUE(outer_icmp_record == inner_icmp_record);
	EXPECT_TRUE(outer_icmp_record->hdr_offset == 34);
	EXPECT_TRUE(outer_icmp_record->hdr_len == 8);
	EXPECT_TRUE(outer_icmp_record->pld_len == 56);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "192.168.40.138-192.168.40.134");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "192.168.40.138-192.168.40.134");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ipv6:icmpv6:data]
 ******************************************************************************
 *
 * Frame 1: 114 bytes on wire (912 bits), 114 bytes captured (912 bits)
 * Ethernet II, Src: c2:00:51:fa:00:00 (c2:00:51:fa:00:00), Dst: c2:01:51:fa:00:00 (c2:01:51:fa:00:00)
 *     Destination: c2:01:51:fa:00:00 (c2:01:51:fa:00:00)
 *     Source: c2:00:51:fa:00:00 (c2:00:51:fa:00:00)
 *     Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2001:db8:0:12::1, Dst: 2001:db8:0:12::2
 *     0110 .... = Version: 6
 *     .... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         .... 0000 00.. .... .... .... .... .... = Differentiated Services Codepoint: Default (0)
 *         .... .... ..00 .... .... .... .... .... = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     .... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 *     Payload Length: 60
 *     Next Header: ICMPv6 (58)
 *     Hop Limit: 64
 *     Source Address: 2001:db8:0:12::1
 *     Destination Address: 2001:db8:0:12::2
 * Internet Control Message Protocol v6
 *     Type: Echo (ping) request (128)
 *     Code: 0
 *     Checksum: 0x863c [correct]
 *     [Checksum Status: Good]
 *     Identifier: 0x110d
 *     Sequence: 0
 *     [Response In: 2]
 *     Data (52 bytes)
 *         Data: 000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f30313233
 *         [Length: 52]
 */

unsigned char data14[] = {
	0xc2, 0x01, 0x51, 0xfa, 0x00, 0x00, 0xc2, 0x00, 0x51, 0xfa, 0x00, 0x00, 0x86, 0xdd, 0x60, 0x00, 0x00, 0x00, 0x00, 0x3c, 0x3a, 0x40, 0x20, 0x01, 0x0d, 0xb8,
	0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x20, 0x01, 0x0d, 0xb8, 0x00, 0x00, 0x00, 0x12, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x02, 0x80, 0x00, 0x86, 0x3c, 0x11, 0x0d, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x0a, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,
	0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 0x1e, 0x1f, 0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29,
	0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 0x30, 0x31, 0x32, 0x33};

#if 1
TEST(PACKET_PARSE, ETH_IP6_ICMP6)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data14, sizeof(data14));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data14 == 14 + 40 + 8);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 100);

	// LAYER_PROTO_IPV6
	const struct layer_internal *outer_ipv6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV6);
	const struct layer_internal *inner_ipv6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(outer_ipv6_record != nullptr);
	EXPECT_TRUE(inner_ipv6_record != nullptr);
	EXPECT_TRUE(outer_ipv6_record == inner_ipv6_record);
	EXPECT_TRUE(outer_ipv6_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(outer_ipv6_record->pld_len == 60);

	// LAYER_PROTO_ICMP6
	const struct layer_internal *outer_icmp6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ICMP6);
	const struct layer_internal *inner_icmp6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ICMP6);

	EXPECT_TRUE(outer_icmp6_record != nullptr);
	EXPECT_TRUE(inner_icmp6_record != nullptr);
	EXPECT_TRUE(outer_icmp6_record == inner_icmp6_record);
	EXPECT_TRUE(outer_icmp6_record->hdr_offset == 54);
	EXPECT_TRUE(outer_icmp6_record->hdr_len == 8);
	EXPECT_TRUE(outer_icmp6_record->pld_len == 52);

	/******************************************************
	 * packet_get_outermost/innermost_tuple2
	 ******************************************************/

	struct tuple2 outer_tuple2;
	struct tuple2 inner_tuple2;
	EXPECT_TRUE(packet_get_outermost_tuple2(&handler, &outer_tuple2) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple2(&handler, &inner_tuple2) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&outer_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001:db8:0:12::1-2001:db8:0:12::2");
	memset(buffer, 0, sizeof(buffer));
	tuple2_to_str(&inner_tuple2, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2001:db8:0:12::1-2001:db8:0:12::2");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:udp:l2tp:ppp:ip:udp:nbns]
 ******************************************************************************
 *
 * Frame 1: 150 bytes on wire (1200 bits), 150 bytes captured (1200 bits)
 * Ethernet II, Src: LCFCElectron_43:38:37 (28:d2:44:43:38:37), Dst: c0:00:14:8c:00:00 (c0:00:14:8c:00:00)
 *     Destination: c0:00:14:8c:00:00 (c0:00:14:8c:00:00)
 *     Source: LCFCElectron_43:38:37 (28:d2:44:43:38:37)
 *     Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 172.16.0.100, Dst: 172.16.0.254
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 136
 *     Identification: 0x06ca (1738)
 *     000. .... = Flags: 0x0
 *         0... .... = Reserved bit: Not set
 *         .0.. .... = Don't fragment: Not set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 128
 *     Protocol: UDP (17)
 *     Header Checksum: 0xda18 [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0xda18]
 *     Source Address: 172.16.0.100
 *     Destination Address: 172.16.0.254
 * User Datagram Protocol, Src Port: 1701, Dst Port: 1701
 *     Source Port: 1701
 *     Destination Port: 1701
 *     Length: 116
 *     Checksum: 0x962f [correct]
 *         [Calculated Checksum: 0x962f]
 *     [Checksum Status: Good]
 *     [Stream index: 0]
 *     [Timestamps]
 *         [Time since first frame: 0.000000000 seconds]
 *         [Time since previous frame: 0.000000000 seconds]
 *     UDP payload (108 bytes)
 * Layer 2 Tunneling Protocol
 *     Flags: 0x4002, Type: Data Message, Length Bit
 *         0... .... .... .... = Type: Data Message (0)
 *         .1.. .... .... .... = Length Bit: Length field is present
 *         .... 0... .... .... = Sequence Bit: Ns and Nr fields are not present
 *         .... ..0. .... .... = Offset bit: Offset size field is not present
 *         .... ...0 .... .... = Priority: No priority
 *         .... .... .... 0010 = Version: 2
 *     Length: 108
 *     Tunnel ID: 28998
 *     Session ID: 2
 * Point-to-Point Protocol
 *     Address: 0xff
 *     Control: 0x03
 *     Protocol: Internet Protocol version 4 (0x0021)
 * Internet Protocol Version 4, Src: 172.16.2.100, Dst: 255.255.255.255
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 96
 *     Identification: 0x0004 (4)
 *     000. .... = Flags: 0x0
 *         0... .... = Reserved bit: Not set
 *         .0.. .... = Don't fragment: Not set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 128
 *     Protocol: UDP (17)
 *     Header Checksum: 0x8c15 [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0x8c15]
 *     Source Address: 172.16.2.100
 *     Destination Address: 255.255.255.255
 * User Datagram Protocol, Src Port: 137, Dst Port: 137
 *     Source Port: 137
 *     Destination Port: 137
 *     Length: 76
 *     Checksum: 0xba80 [correct]
 *         [Calculated Checksum: 0xba80]
 *     [Checksum Status: Good]
 *     [Stream index: 1]
 *     [Timestamps]
 *         [Time since first frame: 0.000000000 seconds]
 *         [Time since previous frame: 0.000000000 seconds]
 *     UDP payload (68 bytes)
 * NetBIOS Name Service
 */

unsigned char data15[] = {
	0xc0, 0x00, 0x14, 0x8c, 0x00, 0x00, 0x28, 0xd2, 0x44, 0x43, 0x38, 0x37, 0x08, 0x00, 0x45, 0x00, 0x00, 0x88, 0x06, 0xca, 0x00, 0x00, 0x80, 0x11, 0xda, 0x18,
	0xac, 0x10, 0x00, 0x64, 0xac, 0x10, 0x00, 0xfe, 0x06, 0xa5, 0x06, 0xa5, 0x00, 0x74, 0x96, 0x2f, 0x40, 0x02, 0x00, 0x6c, 0x71, 0x46, 0x00, 0x02, 0xff, 0x03,
	0x00, 0x21, 0x45, 0x00, 0x00, 0x60, 0x00, 0x04, 0x00, 0x00, 0x80, 0x11, 0x8c, 0x15, 0xac, 0x10, 0x02, 0x64, 0xff, 0xff, 0xff, 0xff, 0x00, 0x89, 0x00, 0x89,
	0x00, 0x4c, 0xba, 0x80, 0xc6, 0x46, 0x29, 0x10, 0x00, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x20, 0x45, 0x4a, 0x45, 0x4a, 0x45, 0x46, 0x43, 0x4e, 0x46,
	0x44, 0x45, 0x4e, 0x43, 0x4e, 0x46, 0x45, 0x45, 0x49, 0x45, 0x4a, 0x45, 0x4f, 0x45, 0x4c, 0x43, 0x41, 0x43, 0x41, 0x43, 0x41, 0x41, 0x41, 0x00, 0x00, 0x20,
	0x00, 0x01, 0xc0, 0x0c, 0x00, 0x20, 0x00, 0x01, 0x00, 0x04, 0x93, 0xe0, 0x00, 0x06, 0x00, 0x00, 0xac, 0x10, 0x02, 0x64};

#if 1
TEST(PACKET_PARSE, ETH_IP4_UDP_L2TPV2_PPP_IP4_UDP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data15, sizeof(data15));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data15 == 14 + 20 + 8 + 8 + 4 + 20 + 8);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 136);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 116);

	// LAYER_PROTO_UDP
	const struct layer_internal *outer_udp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(outer_udp_record != nullptr);
	EXPECT_TRUE(outer_udp_record->hdr_offset == 34);
	EXPECT_TRUE(outer_udp_record->hdr_len == 8);
	EXPECT_TRUE(outer_udp_record->pld_len == 108);

	// LAYER_PROTO_L2TP
	const struct layer_internal *outer_l2tpv2_record = packet_get_outermost_layer(&handler, LAYER_PROTO_L2TP);

	EXPECT_TRUE(outer_l2tpv2_record != nullptr);
	EXPECT_TRUE(outer_l2tpv2_record->hdr_offset == 42);
	EXPECT_TRUE(outer_l2tpv2_record->hdr_len == 8);
	EXPECT_TRUE(outer_l2tpv2_record->pld_len == 100);

	// LAYER_PROTO_PPP
	const struct layer_internal *outer_ppp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_PPP);

	EXPECT_TRUE(outer_ppp_record != nullptr);
	EXPECT_TRUE(outer_ppp_record->hdr_offset == 50);
	EXPECT_TRUE(outer_ppp_record->hdr_len == 4);
	EXPECT_TRUE(outer_ppp_record->pld_len == 96);

	// LAYER_PROTO_IPV4
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record->hdr_offset == 54);
	EXPECT_TRUE(inner_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(inner_ipv4_record->pld_len == 76);

	// LAYER_PROTO_UDP
	const struct layer_internal *inner_udp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(inner_udp_record != nullptr);
	EXPECT_TRUE(inner_udp_record->hdr_offset == 74);
	EXPECT_TRUE(inner_udp_record->hdr_len == 8);
	EXPECT_TRUE(inner_udp_record->pld_len == 68);

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "172.16.0.100:1701-172.16.0.254:1701");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "172.16.2.100:137-255.255.255.255:137");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:tcp]
 ******************************************************************************
 *
 * Frame 1: 60 bytes on wire (480 bits), 60 bytes captured (480 bits)
 * Ethernet II, Src: 52:54:00:94:27:9b (52:54:00:94:27:9b), Dst: 52:54:00:19:8f:63 (52:54:00:19:8f:63)
 *     Destination: 52:54:00:19:8f:63 (52:54:00:19:8f:63)
 *     Source: 52:54:00:94:27:9b (52:54:00:94:27:9b)
 *     Type: IPv4 (0x0800)
 *     Padding: 000000000000
 * Internet Protocol Version 4, Src: 192.168.122.202, Dst: 192.168.122.100
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 40
 *     Identification: 0x0c5e (3166)
 *     010. .... = Flags: 0x2, Don't fragment
 *         0... .... = Reserved bit: Not set
 *         .1.. .... = Don't fragment: Set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 64
 *     Protocol: TCP (6)
 *     Header Checksum: 0xb7f2 [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0xb7f2]
 *     Source Address: 192.168.122.202
 *     Destination Address: 192.168.122.100
 * Transmission Control Protocol, Src Port: 1080, Dst Port: 62395, Seq: 1457975085, Ack: 1047768425, Len: 0
 *     Source Port: 1080
 *     Destination Port: 62395
 *     [Stream index: 0]
 *     [Conversation completeness: Incomplete (4)]
 *         ..0. .... = RST: Absent
 *         ...0 .... = FIN: Absent
 *         .... 0... = Data: Absent
 *         .... .1.. = ACK: Present
 *         .... ..0. = SYN-ACK: Absent
 *         .... ...0 = SYN: Absent
 *         [Completeness Flags: ···A··]
 *     [TCP Segment Len: 0]
 *     Sequence Number: 1457975085
 *     [Next Sequence Number: 1457975085]
 *     Acknowledgment Number: 1047768425
 *     0101 .... = Header Length: 20 bytes (5)
 *     Flags: 0x010 (ACK)
 *         000. .... .... = Reserved: Not set
 *         ...0 .... .... = Accurate ECN: Not set
 *         .... 0... .... = Congestion Window Reduced: Not set
 *         .... .0.. .... = ECN-Echo: Not set
 *         .... ..0. .... = Urgent: Not set
 *         .... ...1 .... = Acknowledgment: Set
 *         .... .... 0... = Push: Not set
 *         .... .... .0.. = Reset: Not set
 *         .... .... ..0. = Syn: Not set
 *         .... .... ...0 = Fin: Not set
 *         [TCP Flags: ·······A····]
 *     Window: 457
 *     [Calculated window size: 457]
 *     [Window size scaling factor: -1 (unknown)]
 *     Checksum: 0x0da7 [correct]
 *         [Calculated Checksum: 0x0da7]
 *     [Checksum Status: Good]
 *     Urgent Pointer: 0
 *     [Timestamps]
 *         [Time since first frame in this TCP stream: 0.000000000 seconds]
 *         [Time since previous frame in this TCP stream: 0.000000000 seconds]
 */

unsigned char data16[] = {
	0x52, 0x54, 0x00, 0x19, 0x8f, 0x63, 0x52, 0x54, 0x00, 0x94, 0x27, 0x9b, 0x08, 0x00, 0x45, 0x00, 0x00, 0x28, 0x0c, 0x5e, 0x40, 0x00, 0x40, 0x06, 0xb7, 0xf2,
	0xc0, 0xa8, 0x7a, 0xca, 0xc0, 0xa8, 0x7a, 0x64, 0x04, 0x38, 0xf3, 0xbb, 0x56, 0xe6, 0xef, 0x2d, 0x3e, 0x73, 0xad, 0x69, 0x50, 0x10, 0x01, 0xc9, 0x0d, 0xa7,
	0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

#if 1
TEST(PACKET_PARSE, ETH_IP4_TCP_PADDING)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data16, sizeof(data16));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data16 == 14 + 20 + 20);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 46);

	// LAYER_PROTO_IPV4
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record == inner_ipv4_record);
	EXPECT_TRUE(outer_ipv4_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(outer_ipv4_record->pld_len == 20);

	// LAYER_PROTO_TCP
	const struct layer_internal *outer_tcp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_TCP);
	const struct layer_internal *inner_tcp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_TCP);

	EXPECT_TRUE(outer_tcp_record != nullptr);
	EXPECT_TRUE(inner_tcp_record != nullptr);
	EXPECT_TRUE(outer_tcp_record == inner_tcp_record);
	EXPECT_TRUE(outer_tcp_record->hdr_offset == 34);
	EXPECT_TRUE(outer_tcp_record->hdr_len == 20);
	EXPECT_TRUE(outer_tcp_record->pld_len == 0);

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "192.168.122.202:1080-192.168.122.100:62395");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "192.168.122.202:1080-192.168.122.100:62395");
}
#endif

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ipv6:udp:gtp:ip:udp:data]
 ******************************************************************************
 *
 * Frame 1: 515 bytes on wire (4120 bits), 515 bytes captured (4120 bits)
 * Ethernet II, Src: 00:00:00_00:03:1c (00:00:00:00:03:1c), Dst: HuaweiTechno_f4:fc:31 (3c:9d:56:f4:fc:31)
 *     Destination: HuaweiTechno_f4:fc:31 (3c:9d:56:f4:fc:31)
 *     Source: 00:00:00_00:03:1c (00:00:00:00:03:1c)
 *     Type: IPv6 (0x86dd)
 * Internet Protocol Version 6, Src: 2408:8161:e100:10:0:16:3:a, Dst: 2408:8141:e0f0:1f08::4
 *     0110 .... = Version: 6
 *     .... 1011 1000 .... .... .... .... .... = Traffic Class: 0xb8 (DSCP: EF PHB, ECN: Not-ECT)
 *         .... 1011 10.. .... .... .... .... .... = Differentiated Services Codepoint: Expedited Forwarding (46)
 *         .... .... ..00 .... .... .... .... .... = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     .... 0100 0111 0100 0101 0011 = Flow Label: 0x47453
 *     Payload Length: 461
 *     Next Header: UDP (17)
 *     Hop Limit: 252
 *     Source Address: 2408:8161:e100:10:0:16:3:a
 *     Destination Address: 2408:8141:e0f0:1f08::4
 * User Datagram Protocol, Src Port: 2152, Dst Port: 2152
 *     Source Port: 2152
 *     Destination Port: 2152
 *     Length: 461
 *     Checksum: 0x6312 [correct]
 *         [Calculated Checksum: 0x6312]
 *     [Checksum Status: Good]
 *     [Stream index: 0]
 *     [Timestamps]
 *         [Time since first frame: 0.000000000 seconds]
 *         [Time since previous frame: 0.000000000 seconds]
 *     UDP payload (453 bytes)
 * GPRS Tunneling Protocol
 *     Flags: 0x34
 *         001. .... = Version: GTP release 99 version (1)
 *         ...1 .... = Protocol type: GTP (1)
 *         .... 0... = Reserved: 0
 *         .... .1.. = Is Next Extension Header present?: Yes
 *         .... ..0. = Is Sequence Number present?: No
 *         .... ...0 = Is N-PDU number present?: No
 *     Message Type: T-PDU (0xff)
 *     Length: 445
 *     TEID: 0x01447453 (21263443)
 *     Next extension header type: PDU Session container (0x85)
 *     Extension header (PDU Session container)
 *         Extension Header Length: 1
 *         PDU Session Container
 *             0001 .... = PDU Type: UL PDU SESSION INFORMATION (1)
 *             .... 0000 = Spare: 0x0
 *             00.. .... = Spare: 0x0
 *             ..00 0001 = QoS Flow Identifier (QFI): 1
 *         Next extension header type: No more extension headers (0x00)
 * Internet Protocol Version 4, Src: 10.67.71.179, Dst: 120.225.133.208
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 437
 *     Identification: 0x51bf (20927)
 *     000. .... = Flags: 0x0
 *         0... .... = Reserved bit: Not set
 *         .0.. .... = Don't fragment: Not set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 64
 *     Protocol: UDP (17)
 *     Header Checksum: 0xd6d1 [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0xd6d1]
 *     Source Address: 10.67.71.179
 *     Destination Address: 120.225.133.208
 * User Datagram Protocol, Src Port: 11102, Dst Port: 2152
 *     Source Port: 11102
 *     Destination Port: 2152
 *     Length: 417
 *     Checksum: 0x3bc2 [correct]
 *         [Calculated Checksum: 0x3bc2]
 *     [Checksum Status: Good]
 *     [Stream index: 1]
 *     [Timestamps]
 *         [Time since first frame: 0.000000000 seconds]
 *         [Time since previous frame: 0.000000000 seconds]
 *     UDP payload (409 bytes)
 * Data (409 bytes)
 *     Data [truncated]: 226f2fcaba48055d4b5500030000019183000104090002810901000000110102010014100000011a3e425e9ae48c6929daebcd0e3cbd830402320bebc2000402270000000d02022800050215000a001800051c3503021612e5050217000000006d9f8ccd020218010402140000088
 *     [Length: 409]
 */

unsigned char data17[] = {
	0x3c, 0x9d, 0x56, 0xf4, 0xfc, 0x31, 0x00, 0x00, 0x00, 0x00, 0x03, 0x1c, 0x86, 0xdd, 0x6b, 0x84, 0x74, 0x53, 0x01, 0xcd, 0x11, 0xfc, 0x24, 0x08, 0x81, 0x61,
	0xe1, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x16, 0x00, 0x03, 0x00, 0x0a, 0x24, 0x08, 0x81, 0x41, 0xe0, 0xf0, 0x1f, 0x08, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
	0x00, 0x04, 0x08, 0x68, 0x08, 0x68, 0x01, 0xcd, 0x63, 0x12, 0x34, 0xff, 0x01, 0xbd, 0x01, 0x44, 0x74, 0x53, 0x00, 0x00, 0x00, 0x85, 0x01, 0x10, 0x01, 0x00,
	0x45, 0x00, 0x01, 0xb5, 0x51, 0xbf, 0x00, 0x00, 0x40, 0x11, 0xd6, 0xd1, 0x0a, 0x43, 0x47, 0xb3, 0x78, 0xe1, 0x85, 0xd0, 0x2b, 0x5e, 0x08, 0x68, 0x01, 0xa1,
	0x3b, 0xc2, 0x22, 0x6f, 0x2f, 0xca, 0xba, 0x48, 0x05, 0x5d, 0x4b, 0x55, 0x00, 0x03, 0x00, 0x00, 0x01, 0x91, 0x83, 0x00, 0x01, 0x04, 0x09, 0x00, 0x02, 0x81,
	0x09, 0x01, 0x00, 0x00, 0x00, 0x11, 0x01, 0x02, 0x01, 0x00, 0x14, 0x10, 0x00, 0x00, 0x01, 0x1a, 0x3e, 0x42, 0x5e, 0x9a, 0xe4, 0x8c, 0x69, 0x29, 0xda, 0xeb,
	0xcd, 0x0e, 0x3c, 0xbd, 0x83, 0x04, 0x02, 0x32, 0x0b, 0xeb, 0xc2, 0x00, 0x04, 0x02, 0x27, 0x00, 0x00, 0x00, 0x0d, 0x02, 0x02, 0x28, 0x00, 0x05, 0x02, 0x15,
	0x00, 0x0a, 0x00, 0x18, 0x00, 0x05, 0x1c, 0x35, 0x03, 0x02, 0x16, 0x12, 0xe5, 0x05, 0x02, 0x17, 0x00, 0x00, 0x00, 0x00, 0x6d, 0x9f, 0x8c, 0xcd, 0x02, 0x02,
	0x18, 0x01, 0x04, 0x02, 0x14, 0x00, 0x00, 0x08, 0x80, 0x06, 0x02, 0x03, 0x00, 0x00, 0x00, 0x0c, 0x31, 0x30, 0x2e, 0x36, 0x37, 0x2e, 0x37, 0x31, 0x2e, 0x31,
	0x37, 0x39, 0x03, 0x02, 0x05, 0xdc, 0x01, 0x06, 0x02, 0x06, 0x00, 0x00, 0x00, 0x0e, 0x31, 0x31, 0x32, 0x2e, 0x31, 0x31, 0x31, 0x2e, 0x35, 0x35, 0x2e, 0x32,
	0x34, 0x33, 0x03, 0x02, 0x08, 0xdc, 0x01, 0x01, 0x02, 0x09, 0x00, 0x14, 0xf1, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xe3, 0x6b,
	0x65, 0xf6, 0xf9, 0x33, 0xcc, 0xa9, 0x06, 0x02, 0x10, 0x00, 0x00, 0x00, 0x0d, 0x32, 0x31, 0x31, 0x2e, 0x39, 0x31, 0x2e, 0x31, 0x36, 0x36, 0x2e, 0x34, 0x34,
	0x03, 0x02, 0x11, 0x4e, 0x21, 0x06, 0x02, 0x1b, 0x00, 0x00, 0x00, 0xb8, 0x32, 0x31, 0x37, 0x36, 0x7c, 0x31, 0x30, 0x2e, 0x36, 0x37, 0x2e, 0x37, 0x31, 0x2e,
	0x31, 0x37, 0x39, 0x7c, 0x30, 0x7c, 0x35, 0x36, 0x33, 0x32, 0x31, 0x7c, 0x31, 0x31, 0x32, 0x2e, 0x31, 0x31, 0x31, 0x2e, 0x35, 0x35, 0x2e, 0x32, 0x34, 0x33,
	0x7c, 0x30, 0x7c, 0x35, 0x36, 0x33, 0x32, 0x31, 0x7c, 0x32, 0x31, 0x31, 0x2e, 0x39, 0x31, 0x2e, 0x31, 0x36, 0x36, 0x2e, 0x34, 0x34, 0x7c, 0x32, 0x30, 0x30,
	0x30, 0x31, 0x7c, 0x46, 0x31, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30, 0x30,
	0x30, 0x45, 0x33, 0x36, 0x42, 0x36, 0x35, 0x46, 0x36, 0x46, 0x39, 0x33, 0x33, 0x43, 0x43, 0x41, 0x39, 0x7c, 0x32, 0x34, 0x30, 0x38, 0x3a, 0x38, 0x34, 0x34,
	0x62, 0x3a, 0x31, 0x38, 0x33, 0x30, 0x3a, 0x36, 0x31, 0x63, 0x62, 0x3a, 0x65, 0x63, 0x34, 0x32, 0x3a, 0x37, 0x65, 0x35, 0x32, 0x3a, 0x65, 0x65, 0x37, 0x38,
	0x3a, 0x65, 0x32, 0x61, 0x38, 0x7c, 0x30, 0x7c, 0x38, 0x38, 0x38, 0x39, 0x7c, 0x32, 0x34, 0x30, 0x38, 0x3a, 0x38, 0x37, 0x33, 0x64, 0x3a, 0x31, 0x30, 0x3a,
	0x34, 0x3a, 0x38, 0x30, 0x30, 0x3a, 0x3a, 0x34, 0x7c, 0x32, 0x30, 0x30, 0x30, 0x31, 0x04, 0x09, 0x02, 0x00, 0x00, 0x01, 0xf8};

#if 1
TEST(PACKET_PARSE, ETH_IP6_UDP_GTP_IP4_UDP)
{
	char buffer[256];
	struct packet handler;

	memset(&handler, 0, sizeof(handler));
	const char *payload = packet_parse(&handler, (const char *)data17, sizeof(data17));
	EXPECT_TRUE(payload != nullptr);
	EXPECT_TRUE((char *)payload - (char *)&data17 == 14 + 40 + 8 + 16 + 20 + 8);
	packet_print(&handler);

	/******************************************************
	 * packet_get_outermost/innermost_layer
	 ******************************************************/

	// LAYER_PROTO_ETHER
	const struct layer_internal *outer_eth_record = packet_get_outermost_layer(&handler, LAYER_PROTO_ETHER);
	const struct layer_internal *inner_eth_record = packet_get_innermost_layer(&handler, LAYER_PROTO_ETHER);

	EXPECT_TRUE(outer_eth_record != nullptr);
	EXPECT_TRUE(inner_eth_record != nullptr);
	EXPECT_TRUE(outer_eth_record == inner_eth_record);
	EXPECT_TRUE(outer_eth_record->hdr_offset == 0);
	EXPECT_TRUE(outer_eth_record->hdr_len == 14);
	EXPECT_TRUE(outer_eth_record->pld_len == 501);

	// LAYER_PROTO_IPV6
	const struct layer_internal *outer_ipv6_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV6);
	const struct layer_internal *inner_ipv6_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV6);

	EXPECT_TRUE(outer_ipv6_record != nullptr);
	EXPECT_TRUE(inner_ipv6_record != nullptr);
	EXPECT_TRUE(outer_ipv6_record == inner_ipv6_record);
	EXPECT_TRUE(outer_ipv6_record->hdr_offset == 14);
	EXPECT_TRUE(outer_ipv6_record->hdr_len == 40);
	EXPECT_TRUE(outer_ipv6_record->pld_len == 461);

	// LAYER_PROTO_UDP
	const struct layer_internal *outer_udp_record = packet_get_outermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(outer_udp_record != nullptr);
	EXPECT_TRUE(outer_udp_record->hdr_offset == 54);
	EXPECT_TRUE(outer_udp_record->hdr_len == 8);
	EXPECT_TRUE(outer_udp_record->pld_len == 453);

	// LAYER_PROTO_GTP_U
	const struct layer_internal *outer_gtpu_record = packet_get_outermost_layer(&handler, LAYER_PROTO_GTP_U);
	const struct layer_internal *inner_gtpu_record = packet_get_innermost_layer(&handler, LAYER_PROTO_GTP_U);

	EXPECT_TRUE(outer_gtpu_record != nullptr);
	EXPECT_TRUE(inner_gtpu_record != nullptr);
	EXPECT_TRUE(outer_gtpu_record == inner_gtpu_record);
	EXPECT_TRUE(outer_gtpu_record->hdr_offset == 62);
	EXPECT_TRUE(outer_gtpu_record->hdr_len == 16);
	EXPECT_TRUE(outer_gtpu_record->pld_len == 437);

	// LAYER_PROTO_IPV4
	const struct layer_internal *inner_ipv4_record = packet_get_innermost_layer(&handler, LAYER_PROTO_IPV4);
	const struct layer_internal *outer_ipv4_record = packet_get_outermost_layer(&handler, LAYER_PROTO_IPV4);

	EXPECT_TRUE(inner_ipv4_record != nullptr);
	EXPECT_TRUE(outer_ipv4_record != nullptr);
	EXPECT_TRUE(inner_ipv4_record == outer_ipv4_record);
	EXPECT_TRUE(inner_ipv4_record->hdr_offset == 78);
	EXPECT_TRUE(inner_ipv4_record->hdr_len == 20);
	EXPECT_TRUE(inner_ipv4_record->pld_len == 417);

	// LAYER_PROTO_UDP
	const struct layer_internal *inner_udp_record = packet_get_innermost_layer(&handler, LAYER_PROTO_UDP);

	EXPECT_TRUE(inner_udp_record != nullptr);
	EXPECT_TRUE(inner_udp_record->hdr_offset == 98);
	EXPECT_TRUE(inner_udp_record->hdr_len == 8);
	EXPECT_TRUE(inner_udp_record->pld_len == 409);

	/******************************************************
	 * packet_get_outermost/innermost_tuple4
	 ******************************************************/

	struct tuple4 outer_tuple4;
	struct tuple4 inner_tuple4;
	EXPECT_TRUE(packet_get_outermost_tuple4(&handler, &outer_tuple4) == 0);
	EXPECT_TRUE(packet_get_innermost_tuple4(&handler, &inner_tuple4) == 0);
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&outer_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "2408:8161:e100:10:0:16:3:a:2152-2408:8141:e0f0:1f08::4:2152");
	memset(buffer, 0, sizeof(buffer));
	tuple4_to_str(&inner_tuple4, buffer, sizeof(buffer));
	EXPECT_STREQ(buffer, "10.67.71.179:11102-120.225.133.208:2152");
}
#endif

int main(int argc, char **argv)
{
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
