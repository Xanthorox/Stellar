#include <gtest/gtest.h>

#include "packet_pool.h"

TEST(PACKET_POOL, TEST)
{
    struct packet *pkt1 = NULL;
    struct packet *pkt2 = NULL;
    struct packet *pkt3 = NULL;
    struct packet *pkt4 = NULL;

    // new
    struct packet_pool *pool = packet_pool_new(3);
    EXPECT_TRUE(pool != NULL);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 0);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 3);

    // pop
    pkt1 = packet_pool_acquire_packet(pool);
    EXPECT_TRUE(pkt1 != NULL);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 1);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 2);

    pkt2 = packet_pool_acquire_packet(pool);
    EXPECT_TRUE(pkt2 != NULL);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 2);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 1);

    pkt3 = packet_pool_acquire_packet(pool);
    EXPECT_TRUE(pkt3 != NULL);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 3);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 0);

    pkt4 = packet_pool_acquire_packet(pool);
    EXPECT_TRUE(pkt4 != NULL);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 4);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 0);

    // push
    packet_pool_release_packet(pool, pkt1);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 3);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 1);

    packet_pool_release_packet(pool, pkt2);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 2);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 2);

    packet_pool_release_packet(pool, pkt3);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 1);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 3);

    packet_pool_release_packet(pool, pkt4);
    EXPECT_TRUE(packet_pool_get_used_num(pool) == 0);
    EXPECT_TRUE(packet_pool_get_free_num(pool) == 3);

    // free
    packet_pool_free(pool);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
