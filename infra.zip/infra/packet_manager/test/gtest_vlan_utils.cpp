#include <gtest/gtest.h>

#include "packet_helper.h"

/*
 * IEEE 802.1ad, ID: 1
 *     000. .... .... .... = Priority: 0
 *     ...0 .... .... .... = DEI: 0
 *     .... 0000 0000 0001 = ID: 1
 *     Type: 802.1Q Virtual LAN (0x8100)
 */

unsigned char data[] = {
    0x00, 0x01, 0x81, 0x00};

TEST(VLAN_UTILS, GET)
{
    const struct vlan_hdr *hdr = (struct vlan_hdr *)data;

    EXPECT_TRUE(vlan_hdr_get_priority(hdr) == 0);
    EXPECT_TRUE(vlan_hdr_get_dei(hdr) == 0);
    EXPECT_TRUE(vlan_hdr_get_vid(hdr) == 1);
    EXPECT_TRUE(vlan_hdr_get_ethertype(hdr) == 0x8100);
}

TEST(VLAN_UTILS, SET)
{
    char buff[4] = {0};
    struct vlan_hdr *hdr = (struct vlan_hdr *)buff;

    vlan_hdr_set_priority(hdr, 0);
    vlan_hdr_set_dei(hdr, 0);
    vlan_hdr_set_vid(hdr, 1);
    vlan_hdr_set_ethertype(hdr, 0x8100);
    EXPECT_TRUE(memcmp(buff, data, 4) == 0);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
