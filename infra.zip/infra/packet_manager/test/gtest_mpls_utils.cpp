#include <gtest/gtest.h>

#include "packet_helper.h"

/*
 * MultiProtocol Label Switching Header, Label: 779408, Exp: 0, S: 0, TTL: 255
 *     1011 1110 0100 1001 0000 .... .... .... = MPLS Label: 779408 (0xbe490)
 *     .... .... .... .... .... 000. .... .... = MPLS Experimental Bits: 0
 *     .... .... .... .... .... ...0 .... .... = MPLS Bottom Of Label Stack: 0
 *     .... .... .... .... .... .... 1111 1111 = MPLS TTL: 255
 */

unsigned char data[] = {
    0xbe, 0x49, 0x00, 0xff};

TEST(MPLS_UTILS, GET)
{
    const struct mpls_label *hdr = (struct mpls_label *)data;

    EXPECT_TRUE(mpls_label_get_label(hdr) == 0xbe490);
    EXPECT_TRUE(mpls_label_get_tc(hdr) == 0);
    EXPECT_TRUE(mpls_label_get_bos(hdr) == 0);
    EXPECT_TRUE(mpls_label_get_ttl(hdr) == 255);
}

TEST(MPLS_UTILS, SET)
{
    char buff[4] = {0};
    struct mpls_label *hdr = (struct mpls_label *)buff;

    mpls_label_set_label(hdr, 0xbe490);
    mpls_label_set_tc(hdr, 0);
    mpls_label_set_bos(hdr, 0);
    mpls_label_set_ttl(hdr, 255);
    EXPECT_TRUE(memcmp(buff, data, 4) == 0);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
