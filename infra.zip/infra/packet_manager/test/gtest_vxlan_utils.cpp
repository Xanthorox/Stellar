#include <gtest/gtest.h>

#include "packet_helper.h"

/*
 * Virtual eXtensible Local Area Network
 *     Flags: 0x0800, VXLAN Network ID (VNI)
 *         0... .... .... .... = GBP Extension: Not defined
 *         .... 1... .... .... = VXLAN Network ID (VNI): True
 *         .... .... .0.. .... = Don't Learn: False
 *         .... .... .... 0... = Policy Applied: False
 *         .000 .000 0.00 .000 = Reserved(R): 0x0000
 *     Group Policy ID: 0
 *     VXLAN Network Identifier (VNI): 461829
 *     Reserved: 0
 */

unsigned char data[] = {
    0x08, 0x00, 0x00, 0x00, 0x07, 0x0c, 0x05, 0x00};

TEST(VXLAN_UTILS, GET)
{
    const struct vxlan_hdr *hdr = (struct vxlan_hdr *)data;

    EXPECT_TRUE(vxlan_hdr_get_flags(hdr) == 0x08);
    EXPECT_TRUE(vxlan_hdr_get_vni(hdr) == 461829);
}

TEST(VXLAN_UTILS, SET)
{
    char buff[8] = {0};
    struct vxlan_hdr *hdr = (struct vxlan_hdr *)buff;

    vxlan_hdr_set_flags(hdr, 0x08);
    vxlan_hdr_set_vni(hdr, 461829);
    EXPECT_TRUE(memcmp(buff, data, 8) == 0);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
