#include <gtest/gtest.h>

#include "packet_helper.h"

/*
 * Internet Protocol Version 6, Src: fe80::250:56ff:fe69:dc00, Dst: ff02::1:2
 *     0110 .... = Version: 6
 *     .... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         .... 0000 00.. .... .... .... .... .... = Differentiated Services Codepoint: Default (0)
 *         .... .... ..00 .... .... .... .... .... = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     .... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 *     Payload Length: 60
 *     Next Header: UDP (17)
 *     Hop Limit: 1
 *     Source Address: fe80::250:56ff:fe69:dc00
 *     Destination Address: ff02::1:2
 *     [Source SLAAC MAC: VMware_69:dc:00 (00:50:56:69:dc:00)]
 *  */

unsigned char data[] = {
    0x60, 0x00, 0x00, 0x00, 0x00, 0x3c, 0x11, 0x01, 0xfe, 0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x02, 0x50, 0x56, 0xff, 0xfe, 0x69, 0xdc, 0x00, 0xff, 0x02,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x00, 0x02};

TEST(IPV6_UTILS, GET)
{
    char src_str[INET6_ADDRSTRLEN];
    char dst_str[INET6_ADDRSTRLEN];
    const struct ip6_hdr *hdr = (struct ip6_hdr *)data;
    EXPECT_TRUE(ip6_hdr_get_version(hdr) == 6);
    EXPECT_TRUE(ip6_hdr_get_traffic_class(hdr) == 0);
    EXPECT_TRUE(ip6_hdr_get_flow_label(hdr) == 0);
    EXPECT_TRUE(ip6_hdr_get_payload_len(hdr) == 60);
    EXPECT_TRUE(ip6_hdr_get_next_header(hdr) == 17);
    EXPECT_TRUE(ip6_hdr_get_hop_limit(hdr) == 1);
    struct in6_addr src_addr = ip6_hdr_get_src_in6_addr(hdr);
    struct in6_addr dst_addr = ip6_hdr_get_dst_in6_addr(hdr);

    inet_ntop(AF_INET6, &src_addr, src_str, INET6_ADDRSTRLEN);
    inet_ntop(AF_INET6, &dst_addr, dst_str, INET6_ADDRSTRLEN);
    EXPECT_TRUE(strcmp(src_str, "fe80::250:56ff:fe69:dc00") == 0);
    EXPECT_TRUE(strcmp(dst_str, "ff02::1:2") == 0);
}

TEST(IPV6_UTILS, SET)
{
    char buff[40] = {0};
    struct in6_addr src_addr;
    struct in6_addr dst_addr;
    struct ip6_hdr *hdr = (struct ip6_hdr *)buff;

    inet_pton(AF_INET6, "fe80::250:56ff:fe69:dc00", &src_addr);
    inet_pton(AF_INET6, "ff02::1:2", &dst_addr);
    ip6_hdr_set_version(hdr, 6);
    ip6_hdr_set_traffic_class(hdr, 0);
    ip6_hdr_set_flow_label(hdr, 0);
    ip6_hdr_set_payload_len(hdr, 60);
    ip6_hdr_set_next_header(hdr, 17);
    ip6_hdr_set_hop_limit(hdr, 1);
    ip6_hdr_set_src_in6_addr(hdr, src_addr);
    ip6_hdr_set_dst_in6_addr(hdr, dst_addr);

    EXPECT_TRUE(memcmp(buff, data, 40) == 0);
}

/*
 * Fragment Header for IPv6
 *     Next header: UDP (17)
 *     Reserved octet: 0x00
 *     0000 0101 1010 1... = Offset: 181 (1448 bytes)
 *     .... .... .... .00. = Reserved bits: 0
 *     .... .... .... ...1 = More Fragments: Yes
 *     Identification: 0xf88eb466
 */

unsigned char frag[] = {
    0x11, 0x00, 0x05, 0xa9, 0xf8, 0x8e, 0xb4, 0x66};

TEST(IPV6_FRAG_HDR, GET)
{
    const struct ip6_frag *hdr = (struct ip6_frag *)frag;
    EXPECT_TRUE(ipv6_frag_get_next_header(hdr) == 17);
    EXPECT_TRUE(ipv6_frag_get_offset(hdr) == 1448);
    EXPECT_TRUE(ipv6_frag_get_more(hdr) == 1);
    EXPECT_TRUE(ipv6_frag_get_ident(hdr) == 0xf88eb466);
}

TEST(IPV6_FRAG_HDR, SET)
{
    char buff[8] = {0};

    struct ip6_frag *hdr = (struct ip6_frag *)buff;
    ipv6_frag_set_next_header(hdr, 17);
    ipv6_frag_set_offset(hdr, 1448);
    ipv6_frag_set_more(hdr, 1);
    ipv6_frag_set_ident(hdr, 0xf88eb466);

    EXPECT_TRUE(memcmp(buff, frag, 8) == 0);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
