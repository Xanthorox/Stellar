#include <gtest/gtest.h>

#include "packet_helper.h"

/*
 * User Datagram Protocol, Src Port: 4001, Dst Port: 8000
 *     Source Port: 4001
 *     Destination Port: 8000
 *     Length: 155
 *     Checksum: 0x1e1e [correct]
 *         [Calculated Checksum: 0x1e1e]
 *     [Checksum Status: Good]
 */

unsigned char data[] = {0x0f, 0xa1, 0x1f, 0x40, 0x00, 0x9b, 0x1e, 0x1e};

TEST(UDP_UTILS, GET)
{
    const struct udphdr *hdr = (struct udphdr *)data;

    EXPECT_TRUE(udp_hdr_get_src_port(hdr) == 4001);
    EXPECT_TRUE(udp_hdr_get_dst_port(hdr) == 8000);
    EXPECT_TRUE(udp_hdr_get_total_len(hdr) == 155);
    EXPECT_TRUE(udp_hdr_get_checksum(hdr) == 0x1e1e);
}

TEST(UDP_UTILS, SET)
{
    char buff[8] = {0};
    struct udphdr *hdr = (struct udphdr *)buff;

    udp_hdr_set_src_port(hdr, 4001);
    udp_hdr_set_dst_port(hdr, 8000);
    udp_hdr_set_total_len(hdr, 155);
    udp_hdr_set_checksum(hdr, 0x1e1e);
    EXPECT_TRUE(memcmp(buff, data, 8) == 0);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
