#include <gtest/gtest.h>

#include "packet_helper.h"

/*
 * Ethernet II, Src: 00:00:00_00:04:36 (00:00:00:00:04:36), Dst: 18:10:04:00:03:1f (18:10:04:00:03:1f)
 *     Destination: 18:10:04:00:03:1f (18:10:04:00:03:1f)
 *         Address: 18:10:04:00:03:1f (18:10:04:00:03:1f)
 *         .... ..0. .... .... .... .... = LG bit: Globally unique address (factory default)
 *         .... ...0 .... .... .... .... = IG bit: Individual address (unicast)
 *     Source: 00:00:00_00:04:36 (00:00:00:00:04:36)
 *         Address: 00:00:00_00:04:36 (00:00:00:00:04:36)
 *         .... ..0. .... .... .... .... = LG bit: Globally unique address (factory default)
 *         .... ...0 .... .... .... .... = IG bit: Individual address (unicast)
 *     Type: MPLS label switched packet (0x8847)
 */

unsigned char data[] = {
    0x18, 0x10, 0x04, 0x00, 0x03, 0x1f, 0x00, 0x00, 0x00, 0x00, 0x04, 0x36, 0x88, 0x47};

TEST(ETH_UTILS, GET)
{
    const struct ethhdr *hdr = (struct ethhdr *)data;

    char dest[18] = {0};
    char source[18] = {0};
    EXPECT_TRUE(eth_hdr_get_dest(hdr, dest, sizeof(dest)) == 17);
    EXPECT_TRUE(eth_hdr_get_source(hdr, source, sizeof(source)) == 17);
    EXPECT_TRUE(memcmp(dest, "18:10:04:00:03:1f", 17) == 0);
    EXPECT_TRUE(memcmp(source, "00:00:00:00:04:36", 17) == 0);
    EXPECT_TRUE(eth_hdr_get_proto(hdr) == ETH_P_MPLS_UC);
}

TEST(ETH_UTILS, SET)
{
    char buff[14] = {0};
    struct ethhdr *hdr = (struct ethhdr *)buff;

    eth_hdr_set_dest(hdr, "18:10:04:00:03:1f");
    eth_hdr_set_source(hdr, "00:00:00:00:04:36");
    eth_hdr_set_proto(hdr, ETH_P_MPLS_UC);
    EXPECT_TRUE(memcmp(buff, data, 14) == 0);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
