#include <gtest/gtest.h>

#include "packet_parser.h"
#include "packet_internal.h"
#include "packet_manager.h"

/******************************************************************************
 * [Protocols in frame: eth:ethertype:ip:ipv6:tcp]
 ******************************************************************************
 *
 * Frame 1: 106 bytes on wire (848 bits), 106 bytes captured (848 bits)
 * Ethernet II, Src: JuniperN_45:88:29 (2c:6b:f5:45:88:29), Dst: JuniperN_2a:a2:00 (5c:5e:ab:2a:a2:00)
 * 	Destination: JuniperN_2a:a2:00 (5c:5e:ab:2a:a2:00)
 * 	Source: JuniperN_45:88:29 (2c:6b:f5:45:88:29)
 * 	Type: IPv4 (0x0800)
 * Internet Protocol Version 4, Src: 210.77.88.163, Dst: 59.66.4.50
 * 	0100 .... = Version: 4
 * 	.... 0101 = Header Length: 20 bytes (5)
 * 	Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	Total Length: 92
 * 	Identification: 0x0b4d (2893)
 * 	000. .... = Flags: 0x0
 * 	...0 0000 0000 0000 = Fragment Offset: 0
 * 	Time to Live: 59
 * 	Protocol: IPv6 (41)
 * 	Header Checksum: 0x09c8 [validation disabled]
 * 	[Header checksum status: Unverified]
 * 	Source Address: 210.77.88.163
 * 	Destination Address: 59.66.4.50
 * Internet Protocol Version 6, Src: 2001:da8:200:900e:200:5efe:d24d:58a3, Dst: 2600:140e:6::1702:1058
 * 	0110 .... = Version: 6
 * 	.... 0000 0000 .... .... .... .... .... = Traffic Class: 0x00 (DSCP: CS0, ECN: Not-ECT)
 * 	.... 0000 0000 0000 0000 0000 = Flow Label: 0x00000
 * 	Payload Length: 32
 * 	Next Header: TCP (6)
 * 	Hop Limit: 64
 * 	Source Address: 2001:da8:200:900e:200:5efe:d24d:58a3
 * 	Destination Address: 2600:140e:6::1702:1058
 * 	[Source ISATAP IPv4: 210.77.88.163]
 * Transmission Control Protocol, Src Port: 52556, Dst Port: 80, Seq: 0, Len: 0
 * 	Source Port: 52556
 * 	Destination Port: 80
 * 	[Stream index: 0]
 * 	[Conversation completeness: Complete, WITH_DATA (31)]
 * 	[TCP Segment Len: 0]
 * 	Sequence Number: 0    (relative sequence number)
 * 	Sequence Number (raw): 2172673142
 * 	[Next Sequence Number: 1    (relative sequence number)]
 * 	Acknowledgment Number: 0
 * 	Acknowledgment number (raw): 0
 * 	1000 .... = Header Length: 32 bytes (8)
 * 	Flags: 0x002 (SYN)
 * 	Window: 8192
 * 	[Calculated window size: 8192]
 * 	Checksum: 0xf757 [unverified]
 * 	[Checksum Status: Unverified]
 * 	Urgent Pointer: 0
 * 	Options: (12 bytes), Maximum segment size, No-Operation (NOP), Window scale, No-Operation (NOP), No-Operation (NOP), SACK permitted
 * 	[Timestamps]
 */

unsigned char data[] = {
	0x5c, 0x5e, 0xab, 0x2a, 0xa2, 0x00, 0x2c, 0x6b, 0xf5, 0x45, 0x88, 0x29, 0x08, 0x00, 0x45, 0x00, 0x00, 0x5c, 0x0b, 0x4d, 0x00, 0x00, 0x3b, 0x29, 0x09, 0xc8,
	0xd2, 0x4d, 0x58, 0xa3, 0x3b, 0x42, 0x04, 0x32, 0x60, 0x00, 0x00, 0x00, 0x00, 0x20, 0x06, 0x40, 0x20, 0x01, 0x0d, 0xa8, 0x02, 0x00, 0x90, 0x0e, 0x02, 0x00,
	0x5e, 0xfe, 0xd2, 0x4d, 0x58, 0xa3, 0x26, 0x00, 0x14, 0x0e, 0x00, 0x06, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x17, 0x02, 0x10, 0x58, 0xcd, 0x4c, 0x00, 0x50,
	0x81, 0x80, 0x5c, 0x76, 0x00, 0x00, 0x00, 0x00, 0x80, 0x02, 0x20, 0x00, 0xf7, 0x57, 0x00, 0x00, 0x02, 0x04, 0x04, 0xc4, 0x01, 0x03, 0x03, 0x08, 0x01, 0x01,
	0x04, 0x02};

static uint16_t thread_id = 0;
static struct packet_manager_stat init_stat = {};

static void check_stat(struct packet_manager_stat *curr_stat, struct packet_manager_stat *expect_stat)
{
	EXPECT_TRUE(curr_stat->pkts_ingress == expect_stat->pkts_ingress);
	EXPECT_TRUE(curr_stat->pkts_egress == expect_stat->pkts_egress);

	for (int i = 0; i < PACKET_QUEUE_MAX; i++)
	{
		EXPECT_TRUE(curr_stat->queue[i].pkts_in == expect_stat->queue[i].pkts_in);
		EXPECT_TRUE(curr_stat->queue[i].pkts_out == expect_stat->queue[i].pkts_out);

		EXPECT_TRUE(curr_stat->queue[i].pkts_claim == expect_stat->queue[i].pkts_claim);
		EXPECT_TRUE(curr_stat->queue[i].pkts_schedule == expect_stat->queue[i].pkts_schedule);

		EXPECT_TRUE(curr_stat->queue[i].pkts_drop == expect_stat->queue[i].pkts_drop);

		EXPECT_TRUE(curr_stat->queue[i].pkts_dup_succ == expect_stat->queue[i].pkts_dup_succ);
		EXPECT_TRUE(curr_stat->queue[i].pkts_dup_fail == expect_stat->queue[i].pkts_dup_fail);

		EXPECT_TRUE(curr_stat->queue[i].pkts_build_tcp_succ == expect_stat->queue[i].pkts_build_tcp_succ);
		EXPECT_TRUE(curr_stat->queue[i].pkts_build_tcp_fail == expect_stat->queue[i].pkts_build_tcp_fail);

		EXPECT_TRUE(curr_stat->queue[i].pkts_build_udp_succ == expect_stat->queue[i].pkts_build_udp_succ);
		EXPECT_TRUE(curr_stat->queue[i].pkts_build_udp_fail == expect_stat->queue[i].pkts_build_udp_fail);

		EXPECT_TRUE(curr_stat->queue[i].pkts_build_l3_succ == expect_stat->queue[i].pkts_build_l3_succ);
		EXPECT_TRUE(curr_stat->queue[i].pkts_build_l3_fail == expect_stat->queue[i].pkts_build_l3_fail);
	}
}

#if 1
TEST(PACKET_MANAGER, NEW_FREE)
{
	struct packet_manager *pkt_mgr = packet_manager_new(1);
	EXPECT_TRUE(pkt_mgr);

	packet_manager_free(pkt_mgr);
}
#endif

#if 1
static void on_packet(struct packet *pkt, struct module *mod)
{
	enum packet_stage stage = packet_get_stage(pkt);
	printf("on_packet_stage: %s\n", packet_stage_to_str(stage));

	uint64_t tag_key_bits;
	uint64_t tag_val_bits;
	packet_tag_get(pkt, &tag_key_bits, &tag_val_bits);
	EXPECT_TRUE(tag_key_bits == PKT_TAG_KEY_IPPROTO);
	EXPECT_TRUE(tag_val_bits == PKT_TAG_VAL_IPPROTO_TCP);

	static int count = 0;
	EXPECT_TRUE(count == stage);
	EXPECT_TRUE(packet_get_type(pkt) == PACKET_TYPE_PSEUDO);
	EXPECT_TRUE(mod == NULL);
	count++;
}

TEST(PACKET_MANAGER, REGISTER)
{
	// module init
	struct packet_manager *pkt_mgr = packet_manager_new(1);
	EXPECT_TRUE(pkt_mgr);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_PREROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, on_packet, NULL) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_INPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, on_packet, NULL) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_FORWARD, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, on_packet, NULL) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_OUTPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, on_packet, NULL) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_POSTROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, on_packet, NULL) == 0);

	// per-thread init
	packet_manager_init(pkt_mgr, thread_id);

	// per-thread run
	struct packet pkt;
	memset(&pkt, 0, sizeof(pkt));
	packet_parse(&pkt, (const char *)data, sizeof(data));
	packet_set_type(&pkt, PACKET_TYPE_PSEUDO);

	struct packet_manager_stat *curr_stat = packet_manager_get_stat(pkt_mgr, thread_id);
	check_stat(curr_stat, &init_stat);
	packet_manager_ingress(pkt_mgr, thread_id, &pkt);
	packet_manager_dispatch(pkt_mgr, thread_id);
	EXPECT_TRUE(packet_manager_egress(pkt_mgr, thread_id) == &pkt);
	EXPECT_TRUE(packet_manager_egress(pkt_mgr, thread_id) == NULL);
	struct packet_manager_stat expect_stat = {
		.pkts_ingress = 1,
		.pkts_egress = 1,
		.queue = {
			[PACKET_STAGE_PREROUTING] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_INPUT] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_FORWARD] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_OUTPUT] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_POSTROUTING] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_MAX] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
		},
	};
	check_stat(curr_stat, &expect_stat);

	// per-thread free
	packet_manager_clean(pkt_mgr, thread_id);

	// module free
	packet_manager_free(pkt_mgr);
}
#endif

#if 1
static void drop_packet(struct packet *pkt, struct module *mod)
{
	enum packet_stage stage = packet_get_stage(pkt);
	printf("on_packet_stage: %s\n", packet_stage_to_str(stage));

	uint64_t tag_key_bits;
	uint64_t tag_val_bits;
	packet_tag_get(pkt, &tag_key_bits, &tag_val_bits);
	EXPECT_TRUE(tag_key_bits == PKT_TAG_KEY_IPPROTO);
	EXPECT_TRUE(tag_val_bits == PKT_TAG_VAL_IPPROTO_TCP);

	static int count = 0;
	EXPECT_TRUE(count == stage);
	EXPECT_TRUE(packet_get_type(pkt) == PACKET_TYPE_PSEUDO);
	EXPECT_TRUE(mod == NULL);
	count++;

	if (stage == PACKET_STAGE_FORWARD)
	{
		packet_set_action(pkt, PACKET_ACTION_DROP);
	}
}

TEST(PACKET_MANAGER, DROP_PACKET)
{
	// module init
	struct packet_manager *pkt_mgr = packet_manager_new(1);
	EXPECT_TRUE(pkt_mgr);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_PREROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, drop_packet, NULL) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_INPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, drop_packet, NULL) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_FORWARD, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, drop_packet, NULL) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_OUTPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, drop_packet, NULL) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_POSTROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, drop_packet, NULL) == 0);

	// per-thread init
	packet_manager_init(pkt_mgr, thread_id);

	// per-thread run
	struct packet pkt;
	memset(&pkt, 0, sizeof(pkt));
	packet_parse(&pkt, (const char *)data, sizeof(data));
	packet_set_type(&pkt, PACKET_TYPE_PSEUDO);

	struct packet_manager_stat *curr_stat = packet_manager_get_stat(pkt_mgr, thread_id);
	check_stat(curr_stat, &init_stat);
	packet_manager_ingress(pkt_mgr, thread_id, &pkt);
	packet_manager_dispatch(pkt_mgr, thread_id);
	EXPECT_TRUE(packet_manager_egress(pkt_mgr, thread_id) == NULL);
	struct packet_manager_stat expect_stat = {
		.pkts_ingress = 1,
		.pkts_egress = 0,
		.queue = {
			[PACKET_STAGE_PREROUTING] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_INPUT] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_FORWARD] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 1, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_OUTPUT] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_POSTROUTING] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_MAX] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
		},
	};
	check_stat(curr_stat, &expect_stat);

	// per-thread free
	packet_manager_clean(pkt_mgr, thread_id);

	// module free
	packet_manager_free(pkt_mgr);
}
#endif

#if 1
static void packet_claimed(struct packet *pkt, struct module *mod)
{
	char *str = (char *)mod;
	EXPECT_STREQ(str, "hello");
	printf("packet_claimed: with ctx %s\n", str);
	EXPECT_TRUE(packet_get_type(pkt) == PACKET_TYPE_PSEUDO);
	EXPECT_TRUE(packet_is_claim(pkt));
	free(str);
}

static void claim_packet_success(struct packet *pkt, struct module *mod)
{
	struct packet_manager *pkt_mgr = (struct packet_manager *)module_get_ctx(mod);
	enum packet_stage stage = packet_get_stage(pkt);
	printf("on_packet_stage: %s\n", packet_stage_to_str(stage));

	uint64_t tag_key_bits;
	uint64_t tag_val_bits;
	packet_tag_get(pkt, &tag_key_bits, &tag_val_bits);
	EXPECT_TRUE(tag_key_bits == PKT_TAG_KEY_IPPROTO);
	EXPECT_TRUE(tag_val_bits == PKT_TAG_VAL_IPPROTO_TCP);

	static int count = 0;
	EXPECT_TRUE(count == 0);
	EXPECT_TRUE(stage == PACKET_STAGE_PREROUTING);
	EXPECT_TRUE(packet_get_type(pkt) == PACKET_TYPE_PSEUDO);
	EXPECT_TRUE(!packet_is_claim(pkt));																		 // packet not claim
	EXPECT_TRUE(packet_manager_claim_packet(pkt_mgr, thread_id, pkt, packet_claimed, strdup("hello")) == 0); // claim packet success
	count++;
}

static void claim_packet_failed(struct packet *pkt, struct module *mod)
{
	struct packet_manager *pkt_mgr = (struct packet_manager *)module_get_ctx(mod);
	enum packet_stage stage = packet_get_stage(pkt);
	printf("on_packet_stage: %s\n", packet_stage_to_str(stage));

	uint64_t tag_key_bits;
	uint64_t tag_val_bits;
	packet_tag_get(pkt, &tag_key_bits, &tag_val_bits);
	EXPECT_TRUE(tag_key_bits == PKT_TAG_KEY_IPPROTO);
	EXPECT_TRUE(tag_val_bits == PKT_TAG_VAL_IPPROTO_TCP);

	static int count = 0;
	EXPECT_TRUE(count == 0);
	EXPECT_TRUE(stage == PACKET_STAGE_PREROUTING);
	EXPECT_TRUE(packet_get_type(pkt) == PACKET_TYPE_PSEUDO);
	EXPECT_TRUE(packet_is_claim(pkt));													 // packet already claim
	EXPECT_TRUE(packet_manager_claim_packet(pkt_mgr, thread_id, pkt, NULL, NULL) == -1); // claim packet failed
	count++;
}

TEST(PACKET_MANAGER, CLAIM_PACKET)
{
	// module init
	struct packet_manager *pkt_mgr = packet_manager_new(1);
	struct module *pkt_mgr_mod = module_new("packet_manager", pkt_mgr);
	EXPECT_TRUE(pkt_mgr);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_PREROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_success, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_INPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_success, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_FORWARD, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_success, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_OUTPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_success, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_POSTROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_success, pkt_mgr_mod) == 0);

	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_PREROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_failed, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_INPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_failed, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_FORWARD, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_failed, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_OUTPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_failed, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_POSTROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_failed, pkt_mgr_mod) == 0);

	// per-thread init
	packet_manager_init(pkt_mgr, thread_id);

	// per-thread run
	struct packet pkt;
	memset(&pkt, 0, sizeof(pkt));
	packet_parse(&pkt, (const char *)data, sizeof(data));
	packet_set_type(&pkt, PACKET_TYPE_PSEUDO);

	struct packet_manager_stat *curr_stat = packet_manager_get_stat(pkt_mgr, thread_id);
	check_stat(curr_stat, &init_stat);
	packet_manager_ingress(pkt_mgr, thread_id, &pkt);
	packet_manager_dispatch(pkt_mgr, thread_id);
	EXPECT_TRUE(packet_manager_egress(pkt_mgr, thread_id) == NULL);
	struct packet_manager_stat expect_stat = {
		.pkts_ingress = 1,
		.pkts_egress = 0,
		.queue = {
			[PACKET_STAGE_PREROUTING] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 1, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_INPUT] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_FORWARD] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_OUTPUT] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_POSTROUTING] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_MAX] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
		},
	};
	check_stat(curr_stat, &expect_stat);

	// per-thread free
	packet_manager_clean(pkt_mgr, thread_id);

	// module free
	packet_manager_free(pkt_mgr);
	module_free(pkt_mgr_mod);
}
#endif

#if 1
static void schedule_packet(struct packet *pkt, struct module *mod)
{
	struct packet_manager *pkt_mgr = (struct packet_manager *)module_get_ctx(mod);
	enum packet_stage stage = packet_get_stage(pkt);
	printf("on_packet_stage: %s\n", packet_stage_to_str(stage));

	uint64_t tag_key_bits;
	uint64_t tag_val_bits;
	packet_tag_get(pkt, &tag_key_bits, &tag_val_bits);
	EXPECT_TRUE(tag_key_bits == PKT_TAG_KEY_IPPROTO);
	EXPECT_TRUE(tag_val_bits == PKT_TAG_VAL_IPPROTO_TCP);

	EXPECT_TRUE(!packet_is_claim(pkt));

	if (stage == PACKET_STAGE_PREROUTING)
	{
		packet_manager_schedule_packet(pkt_mgr, thread_id, packet_new(10), PACKET_STAGE_INPUT);
		packet_manager_schedule_packet(pkt_mgr, thread_id, packet_new(10), PACKET_STAGE_FORWARD);
		packet_manager_schedule_packet(pkt_mgr, thread_id, packet_new(10), PACKET_STAGE_OUTPUT);
		packet_manager_schedule_packet(pkt_mgr, thread_id, packet_new(10), PACKET_STAGE_POSTROUTING);
	}
}

TEST(PACKET_MANAGER, SCHEDULE_PACKET)
{
	// module init
	struct packet_manager *pkt_mgr = packet_manager_new(1);
	struct module *pkt_mgr_mod = module_new("packet_manager", pkt_mgr);
	EXPECT_TRUE(pkt_mgr);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_PREROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, schedule_packet, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_INPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, schedule_packet, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_FORWARD, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, schedule_packet, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_OUTPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, schedule_packet, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_POSTROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, schedule_packet, pkt_mgr_mod) == 0);

	// per-thread init
	packet_manager_init(pkt_mgr, thread_id);

	// per-thread run
	struct packet pkt;
	memset(&pkt, 0, sizeof(pkt));
	packet_parse(&pkt, (const char *)data, sizeof(data));
	packet_set_type(&pkt, PACKET_TYPE_PSEUDO);

	struct packet_manager_stat *curr_stat = packet_manager_get_stat(pkt_mgr, thread_id);
	check_stat(curr_stat, &init_stat);
	packet_manager_ingress(pkt_mgr, thread_id, &pkt);
	packet_manager_dispatch(pkt_mgr, thread_id);

	struct packet *tmp = NULL;
	for (int i = 0; i < 4; i++)
	{
		tmp = packet_manager_egress(pkt_mgr, thread_id);
		EXPECT_TRUE(tmp);
		packet_free(tmp);
	}
	EXPECT_TRUE(packet_manager_egress(pkt_mgr, thread_id) == &pkt);
	EXPECT_TRUE(packet_manager_egress(pkt_mgr, thread_id) == NULL);
	struct packet_manager_stat expect_stat = {
		.pkts_ingress = 1,
		.pkts_egress = 5,
		.queue = {
			[PACKET_STAGE_PREROUTING] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_INPUT] = {.pkts_in = 2, .pkts_out = 2, .pkts_claim = 0, .pkts_schedule = 1, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_FORWARD] = {.pkts_in = 3, .pkts_out = 3, .pkts_claim = 0, .pkts_schedule = 1, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_OUTPUT] = {.pkts_in = 4, .pkts_out = 4, .pkts_claim = 0, .pkts_schedule = 1, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_POSTROUTING] = {.pkts_in = 5, .pkts_out = 5, .pkts_claim = 0, .pkts_schedule = 1, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_MAX] = {.pkts_in = 5, .pkts_out = 5, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
		},
	};
	check_stat(curr_stat, &expect_stat);

	// per-thread free
	packet_manager_clean(pkt_mgr, thread_id);

	// module free
	packet_manager_free(pkt_mgr);

	module_free(pkt_mgr_mod);
}
#endif

#if 1
static void schedule_claimed_packet(struct packet *pkt, struct module *mod)
{
	struct packet_manager *pkt_mgr = (struct packet_manager *)module_get_ctx(mod);

	printf("schedule_claimed_packet:  %p\n", pkt);
	EXPECT_TRUE(packet_get_type(pkt) == PACKET_TYPE_PSEUDO);
	EXPECT_TRUE(packet_is_claim(pkt));

	packet_manager_schedule_packet(pkt_mgr, thread_id, pkt, PACKET_STAGE_POSTROUTING);
}

static void claim_packet_to_schedule(struct packet *pkt, struct module *mod)
{
	struct packet_manager *pkt_mgr = (struct packet_manager *)module_get_ctx(mod);
	enum packet_stage stage = packet_get_stage(pkt);
	printf("on_packet_stage: %s\n", packet_stage_to_str(stage));

	uint64_t tag_key_bits;
	uint64_t tag_val_bits;
	packet_tag_get(pkt, &tag_key_bits, &tag_val_bits);
	EXPECT_TRUE(tag_key_bits == PKT_TAG_KEY_IPPROTO);
	EXPECT_TRUE(tag_val_bits == PKT_TAG_VAL_IPPROTO_TCP);

	static int count = 0;
	EXPECT_TRUE(packet_get_type(pkt) == PACKET_TYPE_PSEUDO);
	EXPECT_TRUE(!packet_is_claim(pkt));
	if (stage == PACKET_STAGE_PREROUTING)
	{
		EXPECT_TRUE(count == 0);																				  // packet not claim
		EXPECT_TRUE(packet_manager_claim_packet(pkt_mgr, thread_id, pkt, schedule_claimed_packet, mod) == 0); // claim packet success
	}
	else if (stage == PACKET_STAGE_POSTROUTING)
	{
		EXPECT_TRUE(count == 1);
		EXPECT_TRUE(!packet_is_claim(pkt));
	}
	else
	{
		EXPECT_TRUE(0);
	}
	count++;
}

TEST(PACKET_MANAGER, SCHEDULE_CLAIMED_PACKET)
{
	// module init
	struct packet_manager *pkt_mgr = packet_manager_new(1);
	struct module *pkt_mgr_mod=module_new("packet_manager", pkt_mgr);
	EXPECT_TRUE(pkt_mgr);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_PREROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_to_schedule, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_INPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_to_schedule, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_FORWARD, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_to_schedule, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_OUTPUT, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_to_schedule, pkt_mgr_mod) == 0);
	EXPECT_TRUE(packet_manager_register_node(pkt_mgr, "name", PACKET_STAGE_POSTROUTING, PKT_TAG_KEY_IPPROTO, PKT_TAG_VAL_IPPROTO_TCP, claim_packet_to_schedule, pkt_mgr_mod) == 0);

	// per-thread init
	packet_manager_init(pkt_mgr, thread_id);

	// per-thread run
	struct packet pkt;
	memset(&pkt, 0, sizeof(pkt));
	packet_parse(&pkt, (const char *)data, sizeof(data));
	packet_set_type(&pkt, PACKET_TYPE_PSEUDO);

	struct packet_manager_stat *curr_stat = packet_manager_get_stat(pkt_mgr, thread_id);
	check_stat(curr_stat, &init_stat);
	packet_manager_ingress(pkt_mgr, thread_id, &pkt);
	packet_manager_dispatch(pkt_mgr, thread_id);
	EXPECT_TRUE(packet_manager_egress(pkt_mgr, thread_id) == &pkt);
	struct packet_manager_stat expect_stat = {
		.pkts_ingress = 1,
		.pkts_egress = 1,
		.queue = {
			[PACKET_STAGE_PREROUTING] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 1, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_INPUT] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_FORWARD] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_OUTPUT] = {.pkts_in = 0, .pkts_out = 0, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_POSTROUTING] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 1, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
			[PACKET_STAGE_MAX] = {.pkts_in = 1, .pkts_out = 1, .pkts_claim = 0, .pkts_schedule = 0, .pkts_drop = 0, .pkts_dup_succ = 0, .pkts_dup_fail = 0, .pkts_build_tcp_succ = 0, .pkts_build_tcp_fail = 0, .pkts_build_udp_succ = 0, .pkts_build_udp_fail = 0, .pkts_build_l3_succ = 0, .pkts_build_l3_fail = 0},
		},
	};
	check_stat(curr_stat, &expect_stat);

	// per-thread free
	packet_manager_clean(pkt_mgr, thread_id);

	// module free
	packet_manager_free(pkt_mgr);

	module_free(pkt_mgr_mod);
}
#endif

int main(int argc, char **argv)
{
	::testing::InitGoogleTest(&argc, argv);
	return RUN_ALL_TESTS();
}
