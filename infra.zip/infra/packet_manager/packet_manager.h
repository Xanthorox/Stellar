#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/packet.h"

#define PACKET_QUEUE_MAX (PACKET_STAGE_MAX + 1)

struct packet_manager_stat
{
    uint64_t pkts_ingress;
    uint64_t pkts_egress;
    struct
    {
        uint64_t pkts_in;  // include the packets that are scheduled
        uint64_t pkts_out; // include the packets that are claimed
        uint64_t pkts_claim;
        uint64_t pkts_schedule;
        uint64_t pkts_drop;
        uint64_t pkts_dup_succ;
        uint64_t pkts_dup_fail;
        uint64_t pkts_build_tcp_succ;
        uint64_t pkts_build_tcp_fail;
        uint64_t pkts_build_udp_succ;
        uint64_t pkts_build_udp_fail;
        uint64_t pkts_build_l3_succ;
        uint64_t pkts_build_l3_fail;
    } queue[PACKET_QUEUE_MAX]; // the last queue is for sending packets
};

// XX(type, name, val)
#define PKT_MGR_STAT_MAP(XX)                                                                                                                     \
    XX(PKT_MGR_STAT_PKTS_INGRESS, pkts_ingress, pkts_ingress)                                                                                    \
    XX(PKT_MGR_STAT_PKTS_EGRESS, pkts_egress, pkts_egress)                                                                                       \
    /* PREROUTING */                                                                                                                             \
    XX(PKT_MGR_STAT_PKTS_IN_ON_PREROUTING, pkts_in_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_in)                                        \
    XX(PKT_MGR_STAT_PKTS_OUT_ON_PREROUTING, pkts_out_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_out)                                     \
    XX(PKT_MGR_STAT_PKTS_CLAIM_ON_PREROUTING, pkts_claim_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_claim)                               \
    XX(PKT_MGR_STAT_PKTS_SCHEDULE_ON_PREROUTING, pkts_schedule_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_schedule)                      \
    XX(PKT_MGR_STAT_PKTS_DROP_ON_PREROUTING, pkts_drop_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_drop)                                  \
    XX(PKT_MGR_STAT_PKTS_DUP_SUCC_ON_PREROUTING, pkts_dup_succ_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_dup_succ)                      \
    XX(PKT_MGR_STAT_PKTS_DUP_FAIL_ON_PREROUTING, pkts_dup_fail_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_dup_fail)                      \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_SUCC_ON_PREROUTING, pkts_build_tcp_succ_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_build_tcp_succ)    \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_FAIL_ON_PREROUTING, pkts_build_tcp_fail_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_build_tcp_fail)    \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_SUCC_ON_PREROUTING, pkts_build_udp_succ_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_build_udp_succ)    \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_FAIL_ON_PREROUTING, pkts_build_udp_fail_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_build_udp_fail)    \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_SUCC_ON_PREROUTING, pkts_build_l3_succ_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_build_l3_succ)       \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_FAIL_ON_PREROUTING, pkts_build_l3_fail_on_prerouting, queue[PACKET_STAGE_PREROUTING].pkts_build_l3_fail)       \
    /* INPUT */                                                                                                                                  \
    XX(PKT_MGR_STAT_PKTS_IN_ON_INPUT, pkts_in_on_input, queue[PACKET_STAGE_INPUT].pkts_in)                                                       \
    XX(PKT_MGR_STAT_PKTS_OUT_ON_INPUT, pkts_out_on_input, queue[PACKET_STAGE_INPUT].pkts_out)                                                    \
    XX(PKT_MGR_STAT_PKTS_CLAIM_ON_INPUT, pkts_claim_on_input, queue[PACKET_STAGE_INPUT].pkts_claim)                                              \
    XX(PKT_MGR_STAT_PKTS_SCHEDULE_ON_INPUT, pkts_schedule_on_input, queue[PACKET_STAGE_INPUT].pkts_schedule)                                     \
    XX(PKT_MGR_STAT_PKTS_DROP_ON_INPUT, pkts_drop_on_input, queue[PACKET_STAGE_INPUT].pkts_drop)                                                 \
    XX(PKT_MGR_STAT_PKTS_DUP_SUCC_ON_INPUT, pkts_dup_succ_on_input, queue[PACKET_STAGE_INPUT].pkts_dup_succ)                                     \
    XX(PKT_MGR_STAT_PKTS_DUP_FAIL_ON_INPUT, pkts_dup_fail_on_input, queue[PACKET_STAGE_INPUT].pkts_dup_fail)                                     \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_SUCC_ON_INPUT, pkts_build_tcp_succ_on_input, queue[PACKET_STAGE_INPUT].pkts_build_tcp_succ)                   \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_FAIL_ON_INPUT, pkts_build_tcp_fail_on_input, queue[PACKET_STAGE_INPUT].pkts_build_tcp_fail)                   \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_SUCC_ON_INPUT, pkts_build_udp_succ_on_input, queue[PACKET_STAGE_INPUT].pkts_build_udp_succ)                   \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_FAIL_ON_INPUT, pkts_build_udp_fail_on_input, queue[PACKET_STAGE_INPUT].pkts_build_udp_fail)                   \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_SUCC_ON_INPUT, pkts_build_l3_succ_on_input, queue[PACKET_STAGE_INPUT].pkts_build_l3_succ)                      \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_FAIL_ON_INPUT, pkts_build_l3_fail_on_input, queue[PACKET_STAGE_INPUT].pkts_build_l3_fail)                      \
    /* FORWARD */                                                                                                                                \
    XX(PKT_MGR_STAT_PKTS_IN_ON_FORWARD, pkts_in_on_forward, queue[PACKET_STAGE_FORWARD].pkts_in)                                                 \
    XX(PKT_MGR_STAT_PKTS_OUT_ON_FORWARD, pkts_out_on_forward, queue[PACKET_STAGE_FORWARD].pkts_out)                                              \
    XX(PKT_MGR_STAT_PKTS_CLAIM_ON_FORWARD, pkts_claim_on_forward, queue[PACKET_STAGE_FORWARD].pkts_claim)                                        \
    XX(PKT_MGR_STAT_PKTS_SCHEDULE_ON_FORWARD, pkts_schedule_on_forward, queue[PACKET_STAGE_FORWARD].pkts_schedule)                               \
    XX(PKT_MGR_STAT_PKTS_DROP_ON_FORWARD, pkts_drop_on_forward, queue[PACKET_STAGE_FORWARD].pkts_drop)                                           \
    XX(PKT_MGR_STAT_PKTS_DUP_SUCC_ON_FORWARD, pkts_dup_succ_on_forward, queue[PACKET_STAGE_FORWARD].pkts_dup_succ)                               \
    XX(PKT_MGR_STAT_PKTS_DUP_FAIL_ON_FORWARD, pkts_dup_fail_on_forward, queue[PACKET_STAGE_FORWARD].pkts_dup_fail)                               \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_SUCC_ON_FORWARD, pkts_build_tcp_succ_on_forward, queue[PACKET_STAGE_FORWARD].pkts_build_tcp_succ)             \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_FAIL_ON_FORWARD, pkts_build_tcp_fail_on_forward, queue[PACKET_STAGE_FORWARD].pkts_build_tcp_fail)             \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_SUCC_ON_FORWARD, pkts_build_udp_succ_on_forward, queue[PACKET_STAGE_FORWARD].pkts_build_udp_succ)             \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_FAIL_ON_FORWARD, pkts_build_udp_fail_on_forward, queue[PACKET_STAGE_FORWARD].pkts_build_udp_fail)             \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_SUCC_ON_FORWARD, pkts_build_l3_succ_on_forward, queue[PACKET_STAGE_FORWARD].pkts_build_l3_succ)                \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_FAIL_ON_FORWARD, pkts_build_l3_fail_on_forward, queue[PACKET_STAGE_FORWARD].pkts_build_l3_fail)                \
    /* OUTPUT */                                                                                                                                 \
    XX(PKT_MGR_STAT_PKTS_IN_ON_OUTPUT, pkts_in_on_output, queue[PACKET_STAGE_OUTPUT].pkts_in)                                                    \
    XX(PKT_MGR_STAT_PKTS_OUT_ON_OUTPUT, pkts_out_on_output, queue[PACKET_STAGE_OUTPUT].pkts_out)                                                 \
    XX(PKT_MGR_STAT_PKTS_CLAIM_ON_OUTPUT, pkts_claim_on_output, queue[PACKET_STAGE_OUTPUT].pkts_claim)                                           \
    XX(PKT_MGR_STAT_PKTS_SCHEDULE_ON_OUTPUT, pkts_schedule_on_output, queue[PACKET_STAGE_OUTPUT].pkts_schedule)                                  \
    XX(PKT_MGR_STAT_PKTS_DROP_ON_OUTPUT, pkts_drop_on_output, queue[PACKET_STAGE_OUTPUT].pkts_drop)                                              \
    XX(PKT_MGR_STAT_PKTS_DUP_SUCC_ON_OUTPUT, pkts_dup_succ_on_output, queue[PACKET_STAGE_OUTPUT].pkts_dup_succ)                                  \
    XX(PKT_MGR_STAT_PKTS_DUP_FAIL_ON_OUTPUT, pkts_dup_fail_on_output, queue[PACKET_STAGE_OUTPUT].pkts_dup_fail)                                  \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_SUCC_ON_OUTPUT, pkts_build_tcp_succ_on_output, queue[PACKET_STAGE_OUTPUT].pkts_build_tcp_succ)                \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_FAIL_ON_OUTPUT, pkts_build_tcp_fail_on_output, queue[PACKET_STAGE_OUTPUT].pkts_build_tcp_fail)                \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_SUCC_ON_OUTPUT, pkts_build_udp_succ_on_output, queue[PACKET_STAGE_OUTPUT].pkts_build_udp_succ)                \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_FAIL_ON_OUTPUT, pkts_build_udp_fail_on_output, queue[PACKET_STAGE_OUTPUT].pkts_build_udp_fail)                \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_SUCC_ON_OUTPUT, pkts_build_l3_succ_on_output, queue[PACKET_STAGE_OUTPUT].pkts_build_l3_succ)                   \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_FAIL_ON_OUTPUT, pkts_build_l3_fail_on_output, queue[PACKET_STAGE_OUTPUT].pkts_build_l3_fail)                   \
    /* POSTROUTING */                                                                                                                            \
    XX(PKT_MGR_STAT_PKTS_IN_ON_POSTROUTING, pkts_in_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_in)                                     \
    XX(PKT_MGR_STAT_PKTS_OUT_ON_POSTROUTING, pkts_out_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_out)                                  \
    XX(PKT_MGR_STAT_PKTS_CLAIM_ON_POSTROUTING, pkts_claim_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_claim)                            \
    XX(PKT_MGR_STAT_PKTS_SCHEDULE_ON_POSTROUTING, pkts_schedule_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_schedule)                   \
    XX(PKT_MGR_STAT_PKTS_DROP_ON_POSTROUTING, pkts_drop_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_drop)                               \
    XX(PKT_MGR_STAT_PKTS_DUP_SUCC_ON_POSTROUTING, pkts_dup_succ_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_dup_succ)                   \
    XX(PKT_MGR_STAT_PKTS_DUP_FAIL_ON_POSTROUTING, pkts_dup_fail_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_dup_fail)                   \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_SUCC_ON_POSTROUTING, pkts_build_tcp_succ_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_build_tcp_succ) \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_FAIL_ON_POSTROUTING, pkts_build_tcp_fail_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_build_tcp_fail) \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_SUCC_ON_POSTROUTING, pkts_build_udp_succ_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_build_udp_succ) \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_FAIL_ON_POSTROUTING, pkts_build_udp_fail_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_build_udp_fail) \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_SUCC_ON_POSTROUTING, pkts_build_l3_succ_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_build_l3_succ)    \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_FAIL_ON_POSTROUTING, pkts_build_l3_fail_on_postrouting, queue[PACKET_STAGE_POSTROUTING].pkts_build_l3_fail)    \
    /* MAX */                                                                                                                                    \
    XX(PKT_MGR_STAT_PKTS_IN_ON_POLLING, pkts_in_on_polling, queue[PACKET_STAGE_MAX].pkts_in)                                                     \
    XX(PKT_MGR_STAT_PKTS_OUT_ON_POLLING, pkts_out_on_polling, queue[PACKET_STAGE_MAX].pkts_out)                                                  \
    XX(PKT_MGR_STAT_PKTS_CLAIM_ON_POLLING, pkts_claim_on_polling, queue[PACKET_STAGE_MAX].pkts_claim)                                            \
    XX(PKT_MGR_STAT_PKTS_SCHEDULE_ON_POLLING, pkts_schedule_on_polling, queue[PACKET_STAGE_MAX].pkts_schedule)                                   \
    XX(PKT_MGR_STAT_PKTS_DROP_ON_POLLING, pkts_drop_on_polling, queue[PACKET_STAGE_MAX].pkts_drop)                                               \
    XX(PKT_MGR_STAT_PKTS_DUP_SUCC_ON_POLLING, pkts_dup_succ_on_polling, queue[PACKET_STAGE_MAX].pkts_dup_succ)                                   \
    XX(PKT_MGR_STAT_PKTS_DUP_FAIL_ON_POLLING, pkts_dup_fail_on_polling, queue[PACKET_STAGE_MAX].pkts_dup_fail)                                   \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_SUCC_ON_POLLING, pkts_build_tcp_succ_on_polling, queue[PACKET_STAGE_MAX].pkts_build_tcp_succ)                 \
    XX(PKT_MGR_STAT_PKTS_BUILD_TCP_FAIL_ON_POLLING, pkts_build_tcp_fail_on_polling, queue[PACKET_STAGE_MAX].pkts_build_tcp_fail)                 \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_SUCC_ON_POLLING, pkts_build_udp_succ_on_polling, queue[PACKET_STAGE_MAX].pkts_build_udp_succ)                 \
    XX(PKT_MGR_STAT_PKTS_BUILD_UDP_FAIL_ON_POLLING, pkts_build_udp_fail_on_polling, queue[PACKET_STAGE_MAX].pkts_build_udp_fail)                 \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_SUCC_ON_POLLING, pkts_build_l3_succ_on_polling, queue[PACKET_STAGE_MAX].pkts_build_l3_succ)                    \
    XX(PKT_MGR_STAT_PKTS_BUILD_L3_FAIL_ON_POLLING, pkts_build_l3_fail_on_polling, queue[PACKET_STAGE_MAX].pkts_build_l3_fail)

enum pkt_mgr_stat_type
{
#define XX(type, name, val) type,
    PKT_MGR_STAT_MAP(XX)
#undef XX
    PKT_MGR_STAT_MAX
};

__attribute__((unused)) static const char pkt_mgr_stat_str[PKT_MGR_STAT_MAX][64] =
{
#define XX(type, name, val) #name,
    PKT_MGR_STAT_MAP(XX)
#undef XX
};

struct packet_manager *packet_manager_new(uint16_t thread_num);
void packet_manager_free(struct packet_manager *pkt_mgr);

int packet_manager_init(struct packet_manager *pkt_mgr, uint16_t thread_id);
void packet_manager_clean(struct packet_manager *pkt_mgr, uint16_t thread_id);

void packet_manager_ingress(struct packet_manager *pkt_mgr, uint16_t thread_id, struct packet *pkt);
struct packet *packet_manager_egress(struct packet_manager *pkt_mgr, uint16_t thread_id);

void packet_manager_dispatch(struct packet_manager *pkt_mgr, uint16_t thread_id);

struct packet_manager_stat *packet_manager_get_stat(struct packet_manager *pkt_mgr, uint16_t thread_id);
void packet_manager_print_stat(struct packet_manager *pkt_mgr, uint16_t thread_id);
uint64_t packet_manager_stat_get(struct packet_manager_stat *stat, enum pkt_mgr_stat_type type);

#ifdef __cplusplus
}
#endif
