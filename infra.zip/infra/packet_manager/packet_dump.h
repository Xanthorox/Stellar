#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/packet.h"

int packet_dump_pcap(const struct packet *pkt, const char *file);
void packet_dump_hex(const struct packet *pkt, int fd);
int packet_dump_str(const struct packet *pkt, char *buff, int size);
void packet_print(const struct packet *pkt);

#ifdef __cplusplus
}
#endif
