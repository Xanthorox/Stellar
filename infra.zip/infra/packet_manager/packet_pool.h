#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/packet.h"

struct packet_pool;
struct packet_pool *packet_pool_new(uint64_t capacity);
void packet_pool_free(struct packet_pool *pool);

struct packet *packet_pool_acquire_packet(struct packet_pool *pool);
void packet_pool_release_packet(struct packet_pool *pool, struct packet *pkt);

uint64_t packet_pool_get_used_num(const struct packet_pool *pool);
uint64_t packet_pool_get_free_num(const struct packet_pool *pool);

#ifdef __cplusplus
}
#endif
