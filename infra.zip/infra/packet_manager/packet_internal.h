#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <sys/queue.h>

#include "tuple/tuple.h"
#include "stellar/packet.h"

#define PACKET_MAX_LAYERS 32

#define MAX_ROUTE_CTX 64
struct route_ctx
{
    char data[MAX_ROUTE_CTX];
    int used;
};

struct metadata
{
    struct route_ctx route_ctx;
    struct sids sids;
    uint64_t session_id;
    uint64_t domain;
    uint16_t link_id;
    enum packet_direction direction;
    struct timeval tv;
};

enum origin_type
{
    ORIGIN_TYPE_MR,
    ORIGIN_TYPE_PCAP,
    ORIGIN_TYPE_USER,
};

typedef void origin_free(struct packet *pkt, void *args);
struct packet_origin
{
    enum origin_type type;
    void *ctx;

    origin_free *cb;
    void *args;

    int thr_idx;
};

struct layer_internal
{
    enum layer_proto proto;

    uint16_t hdr_len;    // header length
    const char *hdr_ptr; // header pointer

    uint16_t pld_len;    // payload length
    const char *pld_ptr; // payload pointer

    uint16_t hdr_offset; // header offset from data_ptr
};

TAILQ_HEAD(packet_queue, packet);

struct packet
{
    void *user_data;
    struct layer_internal layers[PACKET_MAX_LAYERS];
    struct layer_internal *frag_layer; // fragment layer
    int8_t layers_used;
    int8_t layers_size;
    int8_t need_free;
    int8_t is_defraged;
    int8_t is_claim;
    int8_t ip_proto; // innermost ip proto

    const char *data_ptr;
    uint16_t data_len;
    uint16_t trim_len; // trim eth padding

    uint64_t tag_key_bits;
    uint64_t tag_val_bits;

    TAILQ_ENTRY(packet) pool_tqe;  // for packet pool
    TAILQ_ENTRY(packet) frag_tqe;  // for IP reassembly
    TAILQ_ENTRY(packet) stage_tqe; // for packet manager
    struct packet_queue frag_list; // for defraged packet

    struct metadata meta;
    enum packet_stage stage;
    enum packet_type type;
    enum packet_action action;
    struct packet_origin origin;
};

enum packet_load_balance_method
{
    PKT_LDBC_METH_OUTERMOST_INT_IP = 1,
    PKT_LDBC_METH_OUTERMOST_EXT_IP = 2,
    PKT_LDBC_METH_OUTERMOST_INT_EXT_IP = 3,
    PKT_LDBC_METH_INNERMOST_INT_IP = 4,
    PKT_LDBC_METH_INNERMOST_EXT_IP = 5,
};

/******************************************************************************
 * metadata utils
 ******************************************************************************/

void packet_set_route_ctx(struct packet *pkt, const struct route_ctx *ctx);
const struct route_ctx *packet_get_route_ctx(const struct packet *pkt);

void packet_set_sids(struct packet *pkt, const struct sids *sids);
const struct sids *packet_get_sids(const struct packet *pkt);

void packet_set_session_id(struct packet *pkt, uint64_t id);
uint64_t packet_get_session_id(const struct packet *pkt);

void packet_set_domain(struct packet *pkt, uint64_t domain);
uint64_t packet_get_domain(const struct packet *pkt);

void packet_set_link_id(struct packet *pkt, uint16_t id);
uint16_t packet_get_link_id(const struct packet *pkt);

void packet_set_direction(struct packet *pkt, enum packet_direction dir);

/******************************************************************************
 * tuple uitls
 ******************************************************************************/

// return  0: found
// return -1: not found
int packet_get_innermost_tuple2(const struct packet *pkt, struct tuple2 *tuple);
int packet_get_outermost_tuple2(const struct packet *pkt, struct tuple2 *tuple);

// return  0: found
// return -1: not found
int packet_get_innermost_tuple4(const struct packet *pkt, struct tuple4 *tuple);
int packet_get_outermost_tuple4(const struct packet *pkt, struct tuple4 *tuple);

// return  0: found
// return -1: not found
int packet_get_innermost_tuple6(const struct packet *pkt, struct tuple6 *tuple);
int packet_get_outermost_tuple6(const struct packet *pkt, struct tuple6 *tuple);

/******************************************************************************
 * layer uitls
 ******************************************************************************/

const struct layer_internal *packet_get_layer(const struct packet *pkt, int idx);
const struct layer_internal *packet_get_innermost_layer(const struct packet *pkt, enum layer_proto proto);
const struct layer_internal *packet_get_outermost_layer(const struct packet *pkt, enum layer_proto proto);

/******************************************************************************
 * load balance uitls
 ******************************************************************************/

uint64_t packet_ldbc_hash(const struct packet *pkt, enum packet_load_balance_method method, enum packet_direction direction);

/******************************************************************************
 * other uitls
 ******************************************************************************/

struct packet *packet_new(uint16_t pkt_len);
struct packet *packet_dup(const struct packet *pkt);
void packet_free(struct packet *pkt);

int packet_is_fragment(const struct packet *pkt);
int packet_is_defraged(const struct packet *pkt);
void packet_set_defraged(struct packet *pkt);

void packet_push_frag(struct packet *pkt, struct packet *frag);
struct packet *packet_pop_frag(struct packet *pkt);

void packet_set_claim(struct packet *pkt, bool claim);
bool packet_is_claim(const struct packet *pkt);

void *packet_get_user_data(struct packet *pkt);
void packet_set_user_data(struct packet *pkt, void *data);

void packet_set_origin(struct packet *pkt, struct packet_origin *origin);
struct packet_origin *packet_get_origin(struct packet *pkt);

void packet_set_stage(struct packet *pkt, enum packet_stage stage);

void packet_tag_clean(struct packet *pkt);

const char *packet_stage_to_str(enum packet_stage stage);

#ifdef __cplusplus
}
#endif
