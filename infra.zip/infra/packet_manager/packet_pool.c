#include <assert.h>
#include <stdlib.h>

#include "packet_pool.h"
#include "packet_internal.h"

struct packet_pool
{
    uint64_t capacity;
    uint64_t used;
    uint64_t free;
    struct packet_queue free_list;
};

struct packet_pool *packet_pool_new(uint64_t capacity)
{
    struct packet_pool *pool = (struct packet_pool *)calloc(1, sizeof(struct packet_pool));
    if (pool == NULL)
    {
        return NULL;
    }
    pool->capacity = capacity;
    pool->used = 0;
    pool->free = 0;
    TAILQ_INIT(&pool->free_list);

    for (uint64_t i = 0; i < capacity; i++)
    {
        struct packet *pkt = (struct packet *)calloc(1, sizeof(struct packet));
        if (pkt == NULL)
        {
            goto error_out;
        }
        TAILQ_INSERT_TAIL(&pool->free_list, pkt, pool_tqe);
        pool->free++;
    }

    return pool;

error_out:
    packet_pool_free(pool);
    return NULL;
}

void packet_pool_free(struct packet_pool *pool)
{
    struct packet *pkt;
    if (pool)
    {
        while ((pkt = TAILQ_FIRST(&pool->free_list)))
        {
            TAILQ_REMOVE(&pool->free_list, pkt, pool_tqe);
            free(pkt);
            pool->free--;
        }

        assert(pool->used == 0);
        assert(pool->free == 0);

        free(pool);
        pool = NULL;
    }
}

struct packet *packet_pool_acquire_packet(struct packet_pool *pool)
{
    struct packet *pkt = TAILQ_FIRST(&pool->free_list);
    if (pkt == NULL)
    {
        pkt = (struct packet *)calloc(1, sizeof(struct packet));
        if (pkt == NULL)
        {
            return NULL;
        }
    }
    else
    {
        TAILQ_REMOVE(&pool->free_list, pkt, pool_tqe);
        pool->free--;
    }

    pool->used++;

    return pkt;
}

void packet_pool_release_packet(struct packet_pool *pool, struct packet *pkt)
{
    if (pool == NULL || pkt == NULL)
    {
        return;
    }

    pool->used--;

    if (pool->free < pool->capacity)
    {
        TAILQ_INSERT_TAIL(&pool->free_list, pkt, pool_tqe);
        pool->free++;
    }
    else
    {
        free(pkt);
    }
}

uint64_t packet_pool_get_used_num(const struct packet_pool *pool)
{
    return pool->used;
}

uint64_t packet_pool_get_free_num(const struct packet_pool *pool)
{
    return pool->free;
}