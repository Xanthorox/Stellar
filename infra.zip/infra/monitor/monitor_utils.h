#pragma once
#include <stdint.h>
#include <stddef.h>
#include <time.h>
#include <netinet/in.h>
#include "stellar/session.h"
#include "tuple/tuple.h"
#ifdef __cplusplus
extern "C"
{
#endif
    int stm_replace_str(const char *raw, const char *search, const char *replace, char **outline);
    int stm_strncasecmp_exactly(const char *s1, const char *s2, size_t n);
    struct stm_cmd_reply *stm_build_reply_error(const char *format, ...);
    struct stm_cmd_reply *stm_cmd_reply_dup(const struct stm_cmd_reply *src);
    const char *stm_session_flow_dir_ntop(uint32_t dir);
    int stm_time_range_pton(const char *time_str, time_t now, time_t time_range[2]);
    int stm_time_in_range(time_t t, const time_t time_range[2]);
    uint32_t stm_inet_pton(const char *ipstr, void *ipv4_value, void *ipv6_value);
    uint32_t stm_ip_cidr_pton(const char *ipcidr, void *ipv4_value, void *ipv4_mask, void *ipv6_value, void *ipv6_mask);
    int stm_ipv4_cidr_to_range(uint32_t ipaddr, uint32_t ipmask, uint32_t iprange[2]);
    int stm_ipv6_cidr_to_range(const struct in6_addr *ipaddr, const struct in6_addr *ipmask, struct in6_addr iprange[2]);
    void stm_mem_fill_rand(char *buf, size_t len, unsigned char range_min, unsigned char range_max);
    int stm_string_isdigit(const char *str);
    int stm_timeout(struct timeval start, struct timeval end, int timeout_sec);
    const char *stm_session_state_ntop(enum session_state state);
    const char *stm_get0_readable_session_addr(const struct tuple6 *addr, char *addr_buf, size_t max_buf_len);
#ifdef __cplusplus
}
#endif