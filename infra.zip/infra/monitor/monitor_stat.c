#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stddef.h>
#include <arpa/inet.h>
#include <getopt.h>
#include <evhttp.h>
#include "monitor_private.h"
#include <fieldstat/fieldstat_easy.h>

static const char *stm_stat_field_name[] = {
    "connection_new",
    "connection_close",
    "request_succ",
    "request_err",
    "response_succ",
    "response_err",
    NULL,
};

long long stm_get_stat_count(struct stm_stat *stat, enum stm_stat_type type)
{
    if ((int)type < 0 || type >= STM_STAT_MAX)
    {
        return 0;
    }
    return stat->counters[type].count;
}

long long stm_get_stat_bytes(struct stm_stat *stat, enum stm_stat_type type)
{
    if ((int)type < 0 || type >= STM_STAT_MAX)
    {
        return 0;
    }
    return stat->counters[type].bytes;
}

void stm_stat_update(struct stm_stat *stat, int thread_idx, enum stm_stat_type type, long long value)
{
    if ((int)type < 0 || type >= STM_STAT_MAX)
    {
        return;
    }
    fieldstat_easy_counter_incrby(stat->fs4_ins, thread_idx, stat->counters[type].counter_id, NULL, 0, value);
}

struct stm_stat *stm_stat_init(struct stellar_monitor *stm)
{
    const struct stellar_monitor_config *config = stm->config;
    assert(sizeof(stm_stat_field_name) / sizeof(stm_stat_field_name[0]) == STM_STAT_MAX + 1);
    struct stm_stat *stat = CALLOC(struct stm_stat, 1);
    /* worker thread count + 1, reserved for libevent callback thread context */
    stat->fs4_ins = fieldstat_easy_new(stm->worker_thread_num + 1, "monitor", NULL, 0);
    for (int i = 0; stm_stat_field_name[i] != NULL; i++)
    {
        stat->counters[i].counter_id = fieldstat_easy_register_counter(stat->fs4_ins, stm_stat_field_name[i]);
    }
    fieldstat_easy_enable_auto_output(stat->fs4_ins, config->output_path, MAX(config->output_interval_ms / 1000, 1));
    return stat;
}

void stm_stat_free(struct stm_stat *stat)
{
    if (NULL == stat)
    {
        return;
    }
    if (stat->fs4_ins)
    {
        fieldstat_easy_free(stat->fs4_ins);
    }
    FREE(stat);
}