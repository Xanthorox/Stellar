#pragma once

struct stm_spinlock;

struct stm_spinlock *stm_spinlock_new(void);
void stm_spinlock_lock(struct stm_spinlock *splock);
void stm_spinlock_unlock(struct stm_spinlock *splock);
void stm_spinlock_free(struct stm_spinlock *splock);
