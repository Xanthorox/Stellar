#pragma once
#include <stdint.h>
#include <stddef.h>
#include "stellar/monitor.h"
#include <bits/types/struct_iovec.h>

struct monitor_rpc;

typedef struct iovec(monitor_rpc_callabck)(int worker_thread_idx, struct iovec user_data, void *user_args);
struct iovec monitor_worker_thread_rpc(struct stellar_monitor *monitor, int worker_thread_idx, struct iovec user_data, monitor_rpc_callabck *cb, void *user_args);
