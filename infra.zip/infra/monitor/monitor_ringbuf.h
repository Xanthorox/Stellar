#pragma once
#include <stddef.h>

#ifdef __cplusplus
extern "C"
{
#endif

#include "ringbuf/ringbuf.h"

    /*
        Message format:
        || header |  payload ....(variable-length) || header | payload ....(variable-length) ||  ....
    */

    struct monitor_ringbuf_wrap;
    struct monitor_ringbuf_wrap *stm_ringbuf_wrap_new(int thread_tot_num, size_t ringbuf_size);
    int stm_ringbuf_easy_push(int thread_id, struct monitor_ringbuf_wrap *rbf, const void *value, size_t len);
    void stm_ringbuf_release(struct monitor_ringbuf_wrap *rbf, int rel_len);
    void *stm_ringbuf_pop(struct monitor_ringbuf_wrap *rbf, size_t *pop_len);
    void stm_ringbuf_wrap_free(struct monitor_ringbuf_wrap *rbf);
    ssize_t stm_ringbuf_stream_start(int thread_id, struct monitor_ringbuf_wrap *rbf, size_t require_size);
    int stm_ringbuf_stream_append(int thread_id, struct monitor_ringbuf_wrap *rbf, size_t rbf_offset, const void *value, size_t len);
    void stm_ringbuf_stream_finish(int thread_id, struct monitor_ringbuf_wrap *rbf);
    void stm_ringbuf_get_statistics(const struct monitor_ringbuf_wrap *rbf, unsigned long long *push_number,
                                    unsigned long long *push_bytes, unsigned long long *pop_number, unsigned long long *pop_bytes);

#ifdef __cplusplus
}
#endif