#pragma once
#ifdef __cplusplus
extern "C"
{
#endif
#include "cJSON.h"
#include "sds/sds.h"

#ifndef MIN
#define MIN(x, y) ((x) < (y) ? (x) : (y))
#endif

#ifndef MAX
#define MAX(x, y) ((x) > (y) ? (x) : (y))
#endif
    struct stm_cmd_assistant;
    struct stm_cmd_spec;

    struct stm_cmd_assistant *stm_cmd_assistant_new();
    void stm_cmd_assistant_free(struct stm_cmd_assistant *aide);
    int stm_cmd_assistant_json_load(struct stm_cmd_assistant *aide, const char *json_str);
    char *stm_cmd_assistant_brief_print(void);
    char *stm_cmd_assistant_verbose_print(int format);
    int stm_cmd_assistant_is_help(const char *line);
    cJSON *stm_cmd_assistant_search(struct stm_cmd_assistant *aide, const char *cli_cmd_line);
    int stm_cmd_assistant_register(struct stm_cmd_assistant *aide, const char *cli_cmd_line);
    int stm_cmd_assistant_register_usage(struct stm_cmd_assistant *aide, const char *cli_cmd_line, const char *usage);

    // return value shoule be free after uesd.
    char *stm_cmd_assistant_serialize(struct stm_cmd_assistant *aide);
    int stm_cmd_assistant_dserialize(struct stm_cmd_assistant *aide, const char *json);

    /*
     * return value:
     *  0: success
     * -1: failed
     *  1: already exist
     */
    int stm_cmd_assistant_register_cmd(struct stm_cmd_assistant *aide, const char *cmd, void *cmd_cb, void *cmd_arg,
                                       const char *flags, const char *hint, const char *description);

    int stm_cmd_assistant_sds_compare(sds *cli_array, int cli_argc, sds *register_cmd_array, int register_argc);
    typedef void(stm_cmd_assistant_completion_cb)(void *arg, const char *candidate_completion);
    typedef char *(stm_cmd_assistant_hints_cb)(const char *line);
    int stm_cmd_assistant_set_completion_cb(struct stm_cmd_assistant *aide, stm_cmd_assistant_completion_cb *cb);
    int stm_cmd_assistant_set_hints_cb(struct stm_cmd_assistant *aide, stm_cmd_assistant_hints_cb *cb);
    void stm_cmd_assistant_input_line(struct stm_cmd_assistant *aide, const char *line, void *arg);
    const char *stm_cmd_assistant_input_line_for_hints(struct stm_cmd_assistant *aide, const char *line);
    struct stm_cmd_assistant *stm_cmd_assistant_get(void);

    // struct stm_cmd_spec *stm_cmd_assistant_get_cmd(struct stm_cmd_assistant *aide, const char *cmd);
    void *stm_cmd_assistant_get_cb(struct stm_cmd_assistant *aide, const char *cmd);
    void *stm_cmd_assistant_get_user_arg(struct stm_cmd_assistant *aide, const char *cmd);
    int stm_cmd_assistant_get_arity(struct stm_cmd_assistant *aide, const char *cmd);
    sds stm_cmd_assistant_list_cmd_brief(struct stm_cmd_assistant *aide);
    sds stm_cmd_assistant_list_cmd_verbose(struct stm_cmd_assistant *aide);

#ifdef __cplusplus
}
#endif