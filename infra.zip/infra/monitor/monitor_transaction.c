#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stddef.h>
#include <pthread.h>
#include "uthash/utlist.h"
#include "monitor_private.h"

/******************************************** connection manager *****************************************/
struct stm_connection_manager *stm_connection_insert(struct evhttp_connection *evconn)
{
    struct stellar_monitor *stm = stellar_monitor_get();
    struct stm_connection_manager *conn_mgr = stm->connection_mgr;
    struct stm_connection_manager *ele, *tmp;
    DL_FOREACH_SAFE(conn_mgr, ele, tmp) // check if current connection already exist
    {
        if (ele->conn == evconn)
        {
            gettimeofday(&ele->last_active_time, NULL);
            return ele;
        }
    }

    stm_stat_update(stm->stat, stm->worker_thread_num, STM_STAT_CLI_CONNECTION_NEW, 1);
    struct stm_connection_manager *new_conn = (struct stm_connection_manager *)calloc(1, sizeof(struct stm_connection_manager));
    char *tmp_ip_addr;
    uint16_t tmp_port;
    evhttp_connection_get_peer(evconn, &tmp_ip_addr, &tmp_port);
    if (tmp_ip_addr)
    {
        strncpy(new_conn->peer_ipaddr, tmp_ip_addr, INET6_ADDRSTRLEN - 1);
    }
    new_conn->peer_port_host_order = tmp_port;
    gettimeofday(&new_conn->link_start_time, NULL);
    new_conn->last_active_time = new_conn->link_start_time;
    new_conn->conn = evconn;
    DL_APPEND(stm->connection_mgr, new_conn);
    return new_conn;
}

void stm_connection_delete(struct evhttp_connection *evconn)
{
    struct stellar_monitor *stm = stellar_monitor_get();
    struct stm_connection_manager *conn_mgr = stm->connection_mgr;
    struct stm_connection_manager *ele, *tmp;
    DL_FOREACH_SAFE(conn_mgr, ele, tmp)
    {
        if (ele->conn == evconn)
        {
            DL_DELETE(conn_mgr, ele);
            FREE(ele);
        }
    }
    stm->connection_mgr = conn_mgr;
}

void stm_connection_update(struct stm_connection_manager *conn_mgr, const struct evhttp_connection *evconn)
{
    struct stm_connection_manager *ele, *tmp;
    DL_FOREACH_SAFE(conn_mgr, ele, tmp)
    {
        if (ele->conn == evconn)
        {
            gettimeofday(&ele->last_active_time, NULL);
        }
    }
}

const struct stm_connection_manager *stm_connection_search(const struct stm_connection_manager *conn_mgr_head, const struct evhttp_connection *evconn)
{
    const struct stm_connection_manager *ele, *tmp;
    DL_FOREACH_SAFE(conn_mgr_head, ele, tmp)
    {
        if (ele->conn == evconn)
        {
            return ele;
        }
    }
    return NULL;
}
