#include "session_manager_log.h"
#include "session_manager_stat.h"

uint64_t session_manager_stat_get(struct session_manager_stat *stat, enum sess_mgr_stat_type type)
{
    switch (type)
    {
#define XX(_type, _name) case _type: return stat->_name;
    SESS_MGR_STAT_MAP(XX)
#undef XX
    default:
        return 0;
    }
}

void session_manager_stat_print(struct session_manager_stat *stat)
{
    // TCP session
    SESSION_MANAGER_LOG_INFO("runtime: %p, TCP session stat => history: %lu, used: %lu, opening: %lu, active: %lu, closing: %lu, discard: %lu, closed: %lu",
                             stat, stat->history_tcp_sessions, stat->tcp_sess_used, stat->tcp_sess_opening, stat->tcp_sess_active,
                             stat->tcp_sess_closing, stat->tcp_sess_discard, stat->tcp_sess_closed);
    // UDP session
    SESSION_MANAGER_LOG_INFO("runtime: %p, UDP session stat => history: %lu, used: %lu, opening: %lu, active: %lu, closing: %lu, discard: %lu, closed: %lu",
                             stat, stat->history_udp_sessions, stat->udp_sess_used, stat->udp_sess_opening, stat->udp_sess_active,
                             stat->udp_sess_closing, stat->udp_sess_discard, stat->udp_sess_closed);
    // Evicted session
    SESSION_MANAGER_LOG_INFO("runtime: %p, evicted session stat => TCP: %lu, UDP: %lu",
                             stat, stat->tcp_sess_evicted, stat->udp_sess_evicted);
    // Bypassed packet
    SESSION_MANAGER_LOG_INFO("runtime: %p, bypassed TCP packet stat => table_full: %lu, session_not_found: %lu, duplicated: %lu",
                             stat, stat->tcp_pkts_bypass_table_full, stat->tcp_pkts_bypass_session_not_found, stat->tcp_pkts_bypass_duplicated);
    SESSION_MANAGER_LOG_INFO("runtime: %p, bypassed UDP packet stat => table_full: %lu, session_evicted: %lu, duplicated: %lu",
                             stat, stat->udp_pkts_bypass_table_full, stat->udp_pkts_bypass_session_evicted, stat->udp_pkts_bypass_duplicated);
    // TCP segment
    SESSION_MANAGER_LOG_INFO("runtime: %p, TCP segment stat => input: %lu, consumed: %lu, timeout: %lu, retransmited: %lu, overlapped: %lu, omitted_too_many: %lu, inorder: %lu, reordered: %lu, buffered: %lu, freed: %lu",
                             stat, stat->tcp_segs_input, stat->tcp_segs_consumed, stat->tcp_segs_timeout, stat->tcp_segs_retransmited,
                             stat->tcp_segs_overlapped, stat->tcp_segs_omitted_too_many, stat->tcp_segs_inorder, stat->tcp_segs_reordered,
                             stat->tcp_segs_buffered, stat->tcp_segs_freed);
}
