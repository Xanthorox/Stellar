#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>

struct session_timer;
struct session_timer *session_timer_new(uint64_t now);
void session_timer_free(struct session_timer *timer);
void session_timer_update(struct session_timer *timer, struct session *sess, uint64_t expires);
void session_timer_add(struct session_timer *timer, struct session *sess, uint64_t expires);
void session_timer_del(struct session_timer *timer, struct session *sess);
/*
 * return one session which timeout, or NULL if no session timeout.
 * if return session, the session will be removed from timer.
 */
struct session *session_timer_expire(struct session_timer *timer, uint64_t abs_current_ts);
// return  0: have already timeout session
// return >0: next expire interval
uint64_t session_timer_next_expire_interval(struct session_timer *timer);

#ifdef __cplusplus
}
#endif
