#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "tuple.h"
#include "stellar/session.h"
#include "session_manager_cfg.h"

struct session_filter
{
    uint64_t cursor;
    uint64_t count;
    uint64_t limit;

    enum session_type type;
    enum session_state state;

    uint32_t src_family;                // AF_INET or AF_INET6
    uint32_t dst_family;                // AF_INET or AF_INET6
    union ip_address src_addr_range[2]; // network byte order
    union ip_address dst_addr_range[2]; // network byte order
    uint16_t src_port;                  // network byte order
    uint16_t dst_port;                  // network byte order

    uint64_t sess_created_ts_in_ms;
    uint64_t pkt_received_ts_in_ms;
};

struct session_manager_rte;
struct session_manager_rte *session_manager_rte_new(const struct session_manager_cfg *sess_mgr_cfg, uint64_t now_ms);
void session_manager_rte_free(struct session_manager_rte *sess_mgr_rte);

struct session *session_manager_rte_new_session(struct session_manager_rte *sess_mgr_rte, const struct packet *pkt, uint64_t now_ms);
void session_manager_rte_free_session(struct session_manager_rte *sess_mgr_rte, struct session *sess);

struct session *session_manager_rte_lookup_session_by_packet(struct session_manager_rte *sess_mgr_rte, const struct packet *pkt);
struct session *session_manager_rte_lookup_session_by_id(struct session_manager_rte *sess_mgr_rte, uint64_t sess_id);
int session_manager_rte_update_session(struct session_manager_rte *sess_mgr_rte, struct session *sess, const struct packet *pkt, uint64_t now_ms);

struct session *session_manager_rte_get_expired_session(struct session_manager_rte *sess_mgr_rte, uint64_t now_ms);
struct session *session_manager_rte_get_evicted_session(struct session_manager_rte *sess_mgr_rte);

uint64_t session_manager_rte_scan_session(struct session_manager_rte *sess_mgr_rte, const struct session_filter *filter, uint64_t mached_sess_id[], uint64_t array_size);
void session_manager_rte_discard_session(struct session_manager_rte *sess_mgr_rte, struct session *sess);

void session_manager_rte_record_duplicated_packet(struct session_manager_rte *sess_mgr_rte, const struct packet *pkt);

struct session_manager_stat *session_manager_rte_get_stat(struct session_manager_rte *sess_mgr_rte);

#ifdef __cplusplus
}
#endif
