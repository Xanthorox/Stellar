#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>

#define SESS_MGR_STAT_INC(stat, state, proto) \
    {                                         \
        switch ((state))                      \
        {                                     \
        case SESSION_STATE_OPENING:           \
            (stat)->proto##_sess_opening++;   \
            break;                            \
        case SESSION_STATE_ACTIVE:            \
            (stat)->proto##_sess_active++;    \
            break;                            \
        case SESSION_STATE_CLOSING:           \
            (stat)->proto##_sess_closing++;   \
            break;                            \
        case SESSION_STATE_DISCARD:           \
            (stat)->proto##_sess_discard++;   \
            break;                            \
        case SESSION_STATE_CLOSED:            \
            (stat)->proto##_sess_closed++;    \
            break;                            \
        default:                              \
            break;                            \
        }                                     \
    }

#define SESS_MGR_STAT_DEC(stat, state, proto) \
    {                                         \
        switch ((state))                      \
        {                                     \
        case SESSION_STATE_OPENING:           \
            (stat)->proto##_sess_opening--;   \
            break;                            \
        case SESSION_STATE_ACTIVE:            \
            (stat)->proto##_sess_active--;    \
            break;                            \
        case SESSION_STATE_CLOSING:           \
            (stat)->proto##_sess_closing--;   \
            break;                            \
        case SESSION_STATE_DISCARD:           \
            (stat)->proto##_sess_discard--;   \
            break;                            \
        case SESSION_STATE_CLOSED:            \
            (stat)->proto##_sess_closed--;    \
            break;                            \
        default:                              \
            break;                            \
        }                                     \
    }

#define SESS_MGR_STAT_UPDATE(stat, curr, next, proto) \
    {                                                 \
        if (curr != next)                             \
        {                                             \
            SESS_MGR_STAT_DEC(stat, curr, proto);     \
            SESS_MGR_STAT_INC(stat, next, proto);     \
        }                                             \
    }

struct session_manager_stat
{
    // TCP session
    uint64_t history_tcp_sessions;
    uint64_t tcp_sess_used;
    uint64_t tcp_sess_opening;
    uint64_t tcp_sess_active;
    uint64_t tcp_sess_closing;
    uint64_t tcp_sess_discard;
    uint64_t tcp_sess_closed;

    // UDP session
    uint64_t history_udp_sessions;
    uint64_t udp_sess_used;
    uint64_t udp_sess_opening;
    uint64_t udp_sess_active;
    uint64_t udp_sess_closing;
    uint64_t udp_sess_discard;
    uint64_t udp_sess_closed;

    // Evicted session
    uint64_t tcp_sess_evicted; // sum
    uint64_t udp_sess_evicted; // sum

    // Packet
    uint64_t udp_pkts_bypass_table_full;        // sum
    uint64_t tcp_pkts_bypass_table_full;        // sum
    uint64_t tcp_pkts_bypass_session_not_found; // sum
    uint64_t tcp_pkts_bypass_duplicated;        // sum
    uint64_t udp_pkts_bypass_duplicated;        // sum
    uint64_t udp_pkts_bypass_session_evicted;   // sum

    // TCP segments
    uint64_t tcp_segs_input;            // sum
    uint64_t tcp_segs_consumed;         // sum
    uint64_t tcp_segs_timeout;          // sum
    uint64_t tcp_segs_retransmited;     // sum
    uint64_t tcp_segs_overlapped;       // sum
    uint64_t tcp_segs_omitted_too_many; // sum
    uint64_t tcp_segs_inorder;          // sum
    uint64_t tcp_segs_reordered;        // sum
    uint64_t tcp_segs_buffered;         // sum
    uint64_t tcp_segs_freed;            // sum
} __attribute__((aligned(64)));

#define SESS_MGR_STAT_MAP(XX)                                                              \
    XX(SESS_MGR_STAT_HISTORY_TCP_SESSIONS, history_tcp_sessions)                           \
    XX(SESS_MGR_STAT_TCP_SESS_USED, tcp_sess_used)                                         \
    XX(SESS_MGR_STAT_TCP_SESS_OPENING, tcp_sess_opening)                                   \
    XX(SESS_MGR_STAT_TCP_SESS_ACTIVE, tcp_sess_active)                                     \
    XX(SESS_MGR_STAT_TCP_SESS_CLOSING, tcp_sess_closing)                                   \
    XX(SESS_MGR_STAT_TCP_SESS_DISCARD, tcp_sess_discard)                                   \
    XX(SESS_MGR_STAT_TCP_SESS_CLOSED, tcp_sess_closed)                                     \
    XX(SESS_MGR_STAT_HISTORY_UDP_SESSIONS, history_udp_sessions)                           \
    XX(SESS_MGR_STAT_UDP_SESS_USED, udp_sess_used)                                         \
    XX(SESS_MGR_STAT_UDP_SESS_OPENING, udp_sess_opening)                                   \
    XX(SESS_MGR_STAT_UDP_SESS_ACTIVE, udp_sess_active)                                     \
    XX(SESS_MGR_STAT_UDP_SESS_CLOSING, udp_sess_closing)                                   \
    XX(SESS_MGR_STAT_UDP_SESS_DISCARD, udp_sess_discard)                                   \
    XX(SESS_MGR_STAT_UDP_SESS_CLOSED, udp_sess_closed)                                     \
    XX(SESS_MGR_STAT_TCP_SESS_EVICTED, tcp_sess_evicted)                                   \
    XX(SESS_MGR_STAT_UDP_SESS_EVICTED, udp_sess_evicted)                                   \
    XX(SESS_MGR_STAT_UDP_PKTS_BYPASS_TABLE_FULL, udp_pkts_bypass_table_full)               \
    XX(SESS_MGR_STAT_TCP_PKTS_BYPASS_TABLE_FULL, tcp_pkts_bypass_table_full)               \
    XX(SESS_MGR_STAT_TCP_PKTS_BYPASS_SESSION_NOT_FOUND, tcp_pkts_bypass_session_not_found) \
    XX(SESS_MGR_STAT_TCP_PKTS_BYPASS_DUPLICATED, tcp_pkts_bypass_duplicated)               \
    XX(SESS_MGR_STAT_UDP_PKTS_BYPASS_DUPLICATED, udp_pkts_bypass_duplicated)               \
    XX(SESS_MGR_STAT_UDP_PKTS_BYPASS_SESSION_EVICTED, udp_pkts_bypass_session_evicted)     \
    XX(SESS_MGR_STAT_TCP_SEGS_INPUT, tcp_segs_input)                                       \
    XX(SESS_MGR_STAT_TCP_SEGS_CONSUMED, tcp_segs_consumed)                                 \
    XX(SESS_MGR_STAT_TCP_SEGS_TIMEOUT, tcp_segs_timeout)                                   \
    XX(SESS_MGR_STAT_TCP_SEGS_RETRANSMITED, tcp_segs_retransmited)                         \
    XX(SESS_MGR_STAT_TCP_SEGS_OVERLAPPED, tcp_segs_overlapped)                             \
    XX(SESS_MGR_STAT_TCP_SEGS_OMITTED_TOO_MANY, tcp_segs_omitted_too_many)                 \
    XX(SESS_MGR_STAT_TCP_SEGS_INORDER, tcp_segs_inorder)                                   \
    XX(SESS_MGR_STAT_TCP_SEGS_REORDERED, tcp_segs_reordered)                               \
    XX(SESS_MGR_STAT_TCP_SEGS_BUFFERED, tcp_segs_buffered)                                 \
    XX(SESS_MGR_STAT_TCP_SEGS_FREED, tcp_segs_freed)

enum sess_mgr_stat_type
{
#define XX(type, name) type,
    SESS_MGR_STAT_MAP(XX)
#undef XX
    SESS_MGR_STAT_MAX
};

__attribute__((unused)) static const char sess_mgr_stat_str[SESS_MGR_STAT_MAX][64] =
{
#define XX(type, name) #name,
    SESS_MGR_STAT_MAP(XX)
#undef XX
};

uint64_t session_manager_stat_get(struct session_manager_stat *stat, enum sess_mgr_stat_type type);
void session_manager_stat_print(struct session_manager_stat *stat);

#ifdef __cplusplus
}
#endif
