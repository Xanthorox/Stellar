#include <assert.h>

#define HASH_INITIAL_NUM_BUCKETS 32768U // initial number of buckets
#define HASH_FUNCTION(keyptr, keylen, hashv) HASH_FUNCTION_OVERWRITE(keyptr, keylen, &hashv)
#define HASH_KEYCMP(a, b, len) HASH_KEYCMP_OVERWRITE(a, b, len)
#include "session_internal.h"
#include "session_table.h"

struct session_table
{
    struct session *root_tuple6;
    struct session *root_tuple4;
    struct session *root_sessid;
    session_free_cb free_cb;
    void *arg;
    uint64_t count;

    struct session_queue lru_list;
};

/******************************************************************************
 * Private API
 ******************************************************************************/

static void HASH_FUNCTION_OVERWRITE(const void *keyptr, unsigned int keylen, uint32_t *hashv)
{
    switch (keylen)
    {
    case sizeof(struct tuple6):
        *hashv = tuple6_hash((const struct tuple6 *)keyptr);
        break;
    case sizeof(struct tuple4):
        *hashv = tuple4_hash((const struct tuple4 *)keyptr);
        break;
    case sizeof(uint64_t):
        HASH_JEN(keyptr, keylen, *hashv);
        break;
    default:
        assert(0);
        break;
    }
}

static int HASH_KEYCMP_OVERWRITE(const void *key_a, const void *key_b, size_t len)
{
    if (len == sizeof(struct tuple6))
    {
        if (tuple6_cmp((const struct tuple6 *)key_a, (const struct tuple6 *)key_b) == -1)
        {
            struct tuple6 rev;
            tuple6_reverse((const struct tuple6 *)key_b, &rev);
            return tuple6_cmp((const struct tuple6 *)key_a, &rev);
        }
        else
        {
            return 0;
        }
    }
    else if (len == sizeof(struct tuple4))
    {
        if (tuple4_cmp((const struct tuple4 *)key_a, (const struct tuple4 *)key_b) == -1)
        {
            struct tuple4 rev;
            tuple4_reverse((const struct tuple4 *)key_b, &rev);
            return tuple4_cmp((const struct tuple4 *)key_a, &rev);
        }
        else
        {
            return 0;
        }
    }
    else if (len == sizeof(uint64_t))
    {
        return memcmp(key_a, key_b, len);
    }
    else
    {
        assert(0);
        return -1;
    }
}

/******************************************************************************
 * Public API
 ******************************************************************************/

struct session_table *session_table_new()
{
    struct session_table *table = (struct session_table *)calloc(1, sizeof(struct session_table));
    if (table == NULL)
    {
        return NULL;
    }

    table->count = 0;
    TAILQ_INIT(&table->lru_list);

    return table;
}

void session_table_free(struct session_table *table)
{
    if (table)
    {
        struct session *node = NULL;
        struct session *tmp = NULL;
        HASH_ITER(hh1, table->root_tuple6, node, tmp)
        {
            TAILQ_REMOVE(&table->lru_list, node, lru_tqe);
            HASH_DELETE(hh1, table->root_tuple6, node);
            HASH_DELETE(hh2, table->root_tuple4, node);
            HASH_DELETE(hh3, table->root_sessid, node);
            if (table->free_cb && node)
            {
                table->free_cb(node, table->arg);
            }
        }
        table->count--;

        free(table);
        table = NULL;
    }
}

uint64_t session_table_get_count(struct session_table *table)
{
    if (table == NULL)
    {
        return 0;
    }

    return table->count;
}

void session_table_set_freecb(struct session_table *table, session_free_cb free_cb, void *arg)
{
    if (table)
    {
        table->free_cb = free_cb;
        table->arg = arg;
    }
}

void session_table_add(struct session_table *table, struct session *sess)
{
    if (table == NULL || sess == NULL)
    {
        return;
    }

    HASH_ADD(hh1, table->root_tuple6, tuple, sizeof(struct tuple6), sess);
    HASH_ADD(hh2, table->root_tuple4, tuple, sizeof(struct tuple4), sess);
    HASH_ADD(hh3, table->root_sessid, id, sizeof(uint64_t), sess);
    TAILQ_INSERT_TAIL(&table->lru_list, sess, lru_tqe);
    table->count++;
}

void session_table_del(struct session_table *table, struct session *sess)
{
    if (table == NULL || sess == NULL)
    {
        return;
    }

    HASH_DELETE(hh1, table->root_tuple6, sess);
    HASH_DELETE(hh2, table->root_tuple4, sess);
    HASH_DELETE(hh3, table->root_sessid, sess);
    TAILQ_REMOVE(&table->lru_list, sess, lru_tqe);
    if (table->free_cb)
    {
        table->free_cb(sess, table->arg);
    }
    table->count--;
}

struct session *session_table_find_sessid(struct session_table *table, uint64_t id, uint8_t quiet)
{
    if (table == NULL)
    {
        return NULL;
    }

    struct session *sess = NULL;
    HASH_FIND(hh3, table->root_sessid, &id, sizeof(uint64_t), sess);
    if (sess && !quiet)
    {
        TAILQ_REMOVE(&table->lru_list, sess, lru_tqe);
        TAILQ_INSERT_TAIL(&table->lru_list, sess, lru_tqe);
    }

    return sess;
}

struct session *session_table_find_tuple6(struct session_table *table, const struct tuple6 *tuple, uint8_t quiet)
{
    if (table == NULL)
    {
        return NULL;
    }

    struct session *sess = NULL;
    HASH_FIND(hh1, table->root_tuple6, tuple, sizeof(struct tuple6), sess);
    if (sess && !quiet)
    {
        TAILQ_REMOVE(&table->lru_list, sess, lru_tqe);
        TAILQ_INSERT_TAIL(&table->lru_list, sess, lru_tqe);
    }

    return sess;
}

struct session *session_table_find_tuple4(struct session_table *table, const struct tuple4 *tuple, uint8_t quiet)
{
    if (table == NULL)
    {
        return NULL;
    }

    struct session *sess = NULL;
    HASH_FIND(hh2, table->root_tuple4, tuple, sizeof(struct tuple4), sess);
    if (sess && !quiet)
    {
        TAILQ_REMOVE(&table->lru_list, sess, lru_tqe);
        TAILQ_INSERT_TAIL(&table->lru_list, sess, lru_tqe);
    }

    return sess;
}

struct session *session_table_find_lru(struct session_table *table)
{
    if (table == NULL)
    {
        return NULL;
    }

    return TAILQ_FIRST(&table->lru_list);
}