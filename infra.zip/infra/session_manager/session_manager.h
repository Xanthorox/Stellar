#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/session.h"

struct session_manager;
struct session_manager *session_manager_new(struct packet_manager *pkt_mgr, const char *toml_file);
void session_manager_free(struct session_manager *sess_mgr);

int session_manager_init(struct session_manager *sess_mgr, uint16_t thread_id);
void session_manager_clean(struct session_manager *sess_mgr, uint16_t thread_id);

struct session_manager_rte *session_manager_get_rte(const struct session_manager *sess_mgr, uint16_t thread_id);
struct session_manager_cfg *session_manager_get_cfg(const struct session_manager *sess_mgr);

#ifdef __cplusplus
}
#endif
