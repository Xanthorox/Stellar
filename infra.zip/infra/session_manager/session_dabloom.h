#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "tuple.h"

struct session_dabloom *session_dabloom_new(uint32_t capacity, uint32_t timeout, double error_rate, uint64_t now);
void session_dabloom_free(struct session_dabloom *sess_dab);

int session_dabloom_lookup(struct session_dabloom *sess_dab, const struct tuple6 *key, uint64_t now);
void session_dabloom_add(struct session_dabloom *sess_dab, const struct tuple6 *key, uint64_t now);

#ifdef __cplusplus
}
#endif
