#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>

#include "tuple.h"
#include "uthash.h"
#include "timeout.h"
#include "tcp_reassembly.h"
#include "packet_internal.h"
#include "stellar/session.h"
#include "session_manager_stat.h"

// output format: "${src_addr}:${src_port}-${dst_addr}:${dst_port}-${ip_proto}-${domain}"
// output max len: (46 + 1 + 5) + 1 + (46 + 1 + 5) + 1 + 1 + 1 + 20 = 129
#define TUPLE6_STR_SIZE 130

struct tcp_half
{
    struct tcp_reassembly *tcp_reass;
    struct tcp_segment inorder_seg; // current packet in order segment
    uint32_t inorder_seg_consumed;
    uint32_t seq;  // current packet sequence number
    uint32_t ack;  // current packet ack number
    uint16_t len;  // current packet payload length
    uint8_t flags; // current packet flags

    uint32_t isn;    // current direction initial sequence number
    uint8_t history; // current direction received flags
};

/*
 * sizeof(struct session) > 1024 bytes
 * max thread number = 128
 * per thread max tcp session number = 50000
 * per thread max udp session number = 50000
 *
 * session memory usage = 128 * (50000 + 50000) * 1024 = 13107200000 bytes = 12.2 GB
 */
struct session
{
    uint64_t id;
    uint64_t stats[MAX_FLOW_TYPE][MAX_STAT];
    uint64_t timestamps[MAX_TIMESTAMP]; // realtime msec
    struct tcp_half tcp_halfs[MAX_FLOW_TYPE];
    struct timeout timeout;
    TAILQ_ENTRY(session) lru_tqe;
    TAILQ_ENTRY(session) free_tqe;
    TAILQ_ENTRY(session) evc_tqe;
    UT_hash_handle hh1;
    UT_hash_handle hh2;
    UT_hash_handle hh3;
    struct tuple6 tuple; // FLOW_TYPE_C2S tuple
    char tuple_str[TUPLE6_STR_SIZE];
    struct sids sids[MAX_FLOW_TYPE];
    struct route_ctx route_ctx[MAX_FLOW_TYPE];
    const struct packet *first_pkt[MAX_FLOW_TYPE];
    const struct packet *curr_pkt;
    void *user_data;
    int is_symmetric;
    int dup;
    enum session_direction sess_dir;
    enum flow_type flow_type;
    enum session_type sess_type;
    enum session_state state;
    enum closing_reason reason;
    struct session_manager_stat *sess_mgr_stat;
};

TAILQ_HEAD(session_queue, session);

void session_init(struct session *sess);

void session_set_id(struct session *sess, uint64_t id);
// uint64_t session_get_id(const struct session *sess);

void session_set_tuple6(struct session *sess, const struct tuple6 *tuple);
const struct tuple6 *session_get_tuple6(const struct session *sess);
// const char *session_get_readable_addr(const struct session *sess);

void session_set_direction(struct session *sess, enum session_direction dir);
enum session_direction session_get_direction(const struct session *sess);

void session_set_flow_type(struct session *sess, enum flow_type type);
// enum flow_type session_get_flow_type(const struct session *sess);

void session_set_current_state(struct session *sess, enum session_state state);
// enum session_state session_get_current_state(const struct session *sess);

void session_set_type(struct session *sess, enum session_type type);
// enum session_type session_get_type(const struct session *sess);

void session_set_duplicate_traffic(struct session *sess);
// int session_has_duplicate_traffic(const struct session *sess);

void session_set_closing_reason(struct session *sess, enum closing_reason reason);
// enum closing_reason session_get_closing_reason(const struct session *sess);

void session_inc_stat(struct session *sess, enum flow_type type, enum session_stat stat, uint64_t val);
// uint64_t session_get_stat(const struct session *sess, enum flow_type dir, enum session_stat stat);

void session_set_timestamp(struct session *sess, enum session_timestamp type, uint64_t value);
// uint64_t session_get_timestamp(const struct session *sess, enum session_timestamp type);

void session_clear_sids(struct session *sess, enum flow_type type);
void session_set_sids(struct session *sess, enum flow_type type, const struct sids *sids);
const struct sids *session_get_sids(const struct session *sess, enum flow_type type);

void session_clear_route_ctx(struct session *sess, enum flow_type type);
void session_set_route_ctx(struct session *sess, enum flow_type type, const struct route_ctx *ctx);
const struct route_ctx *session_get_route_ctx(const struct session *sess, enum flow_type type);

void session_set_first_packet(struct session *sess, enum flow_type type, const struct packet *pkt);
// const struct packet *session_get_first_packet(const struct session *sess, enum flow_type type);

void session_set_current_packet(struct session *sess, const struct packet *pkt);
const struct packet *session_get_current_packet(const struct session *sess);

// int session_is_symmetric(const struct session *sess, unsigned char *flag);

void session_set_user_data(struct session *sess, void *user_data);
void *session_get_user_data(const struct session *sess);

struct tcp_segment *session_get_tcp_segment(struct session *sess);
void session_free_tcp_segment(struct session *sess, struct tcp_segment *seg);

/******************************************************************************
 * to string
 ******************************************************************************/

const char *closing_reason_to_str(enum closing_reason reason);
const char *session_state_to_str(enum session_state state);
const char *session_type_to_str(enum session_type type);
const char *flow_direction_to_str(enum flow_type type);

// bref : 1, output session bref info
// bref : 0, output session detail info
int session_to_str(const struct session *sess, int bref, char *buff, int size);
void session_print(const struct session *sess);

#ifdef __cplusplus
}
#endif
