#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>

struct session_pool;
struct session_pool *session_pool_new(uint64_t capacity);
void session_pool_free(struct session_pool *pool);

struct session *session_pool_acquire_sessoin(struct session_pool *pool);
void session_pool_release_sessoin(struct session_pool *pool, struct session *sess);
const struct session *session_pool_get0(const struct session_pool *pool, uint64_t idx);

uint64_t session_pool_get_free_num(const struct session_pool *pool);
uint64_t session_pool_get_used_num(const struct session_pool *pool);

#ifdef __cplusplus
}
#endif
