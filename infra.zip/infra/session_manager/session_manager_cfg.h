#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>

struct session_manager_cfg
{
    uint64_t instance_id;
    uint64_t thread_num;
    uint64_t session_id_seed;

    uint64_t tcp_session_max;
    uint64_t udp_session_max;

    uint64_t evict_old_on_tcp_table_limit; // range: [0, 1]
    uint64_t evict_old_on_udp_table_limit; // range: [0, 1]

    uint64_t expire_period_ms; // range: [0, 60000] (ms)
    uint64_t expire_batch_max; // range: [1, 1024]

    struct
    {
        uint64_t init;            // range: [1, 60000] (ms)
        uint64_t handshake;       // range: [1, 60000] (ms)
        uint64_t data;            // range: [1, 15999999000] (ms)
        uint64_t half_closed;     // range: [1, 604800000] (ms)
        uint64_t time_wait;       // range: [1, 600000] (ms)
        uint64_t discard_default; // range: [1, 15999999000] (ms)
        uint64_t unverified_rst;  // range: [1, 600000] (ms)
    } tcp_timeout_ms;

    struct
    {
        uint64_t data;            // range: [1, 15999999000] (ms)
        uint64_t discard_default; // range: [1, 15999999000] (ms)
    } udp_timeout_ms;

    struct
    {
        uint64_t enable;          // range: [0, 1]
        uint64_t capacity;       // range: [1, 4294967295]
        uint64_t time_window_ms; // range: [1, 60000] (ms)
        double error_rate;       // range: [0.0, 1.0]
    } duplicated_packet_bloom_filter;

    struct
    {
        uint64_t enable;          // range: [0, 1]
        uint64_t capacity;       // range: [1, 4294967295]
        uint64_t time_window_ms; // range: [1, 60000] (ms)
        double error_rate;       // range: [0.0, 1.0]
    } evicted_session_bloom_filter;

    struct
    {
        uint64_t enable;                 // range: [0, 1]
        uint64_t timeout_ms;            // range: [1, 60000] (ms)
        uint64_t buffered_segments_max; // range: [2, 4096]
    } tcp_reassembly;
};

struct session_manager_cfg *session_manager_cfg_new(const char *toml_file);
void session_manager_cfg_free(struct session_manager_cfg *sess_mgr_cfg);
void session_manager_cfg_print(struct session_manager_cfg *sess_mgr_cfg);

#ifdef __cplusplus
}
#endif
