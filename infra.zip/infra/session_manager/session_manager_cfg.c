#include "utils_internal.h"
#include "session_manager_log.h"
#include "session_manager_cfg.h"

struct session_manager_cfg *session_manager_cfg_new(const char *toml_file)
{
    if (toml_file == NULL)
    {
        return NULL;
    }

    struct session_manager_cfg *sess_mgr_cfg = (struct session_manager_cfg *)calloc(1, sizeof(struct session_manager_cfg));
    if (sess_mgr_cfg == NULL)
    {
        return NULL;
    }

    int ret = 0;
    ret += load_toml_integer_config(toml_file, "instance.id", &sess_mgr_cfg->instance_id, 0, 4095);
    ret += load_toml_integer_config(toml_file, "packet_io.thread_num", &sess_mgr_cfg->thread_num, 0, MAX_THREAD_NUM);

    // max session number
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_session_max", &sess_mgr_cfg->tcp_session_max, RX_BURST_MAX * 2, UINT64_MAX);
    ret += load_toml_integer_config(toml_file, "session_manager.udp_session_max", &sess_mgr_cfg->udp_session_max, RX_BURST_MAX * 2, UINT64_MAX);

    // session overload
    ret += load_toml_integer_config(toml_file, "session_manager.evict_old_on_tcp_table_limit", &sess_mgr_cfg->evict_old_on_tcp_table_limit, 0, 1);
    ret += load_toml_integer_config(toml_file, "session_manager.evict_old_on_udp_table_limit", &sess_mgr_cfg->evict_old_on_udp_table_limit, 0, 1);

    // limit
    ret += load_toml_integer_config(toml_file, "session_manager.expire_period_ms", &sess_mgr_cfg->expire_period_ms, 0, 60000);
    ret += load_toml_integer_config(toml_file, "session_manager.expire_batch_max", &sess_mgr_cfg->expire_batch_max, 1, 1024);

    // TCP timeout
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_timeout_ms.init", &sess_mgr_cfg->tcp_timeout_ms.init, 1, 60000);
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_timeout_ms.handshake", &sess_mgr_cfg->tcp_timeout_ms.handshake, 1, 60000);
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_timeout_ms.data", &sess_mgr_cfg->tcp_timeout_ms.data, 1, 15999999000);
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_timeout_ms.half_closed", &sess_mgr_cfg->tcp_timeout_ms.half_closed, 1, 604800000);
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_timeout_ms.time_wait", &sess_mgr_cfg->tcp_timeout_ms.time_wait, 1, 600000);
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_timeout_ms.discard_default", &sess_mgr_cfg->tcp_timeout_ms.discard_default, 1, 15999999000);
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_timeout_ms.unverified_rst", &sess_mgr_cfg->tcp_timeout_ms.unverified_rst, 1, 600000);

    // UDP timeout
    ret += load_toml_integer_config(toml_file, "session_manager.udp_timeout_ms.data", &sess_mgr_cfg->udp_timeout_ms.data, 1, 15999999000);
    ret += load_toml_integer_config(toml_file, "session_manager.udp_timeout_ms.discard_default", &sess_mgr_cfg->udp_timeout_ms.discard_default, 1, 15999999000);

    // duplicated packet filter
    ret += load_toml_integer_config(toml_file, "session_manager.duplicated_packet_bloom_filter.enable", &sess_mgr_cfg->duplicated_packet_bloom_filter.enable, 0, 1);
    ret += load_toml_integer_config(toml_file, "session_manager.duplicated_packet_bloom_filter.capacity", &sess_mgr_cfg->duplicated_packet_bloom_filter.capacity, 1, 4294967295);
    ret += load_toml_integer_config(toml_file, "session_manager.duplicated_packet_bloom_filter.time_window_ms", &sess_mgr_cfg->duplicated_packet_bloom_filter.time_window_ms, 1, 60000);
    ret += load_toml_double_config(toml_file, "session_manager.duplicated_packet_bloom_filter.error_rate", (double *)&sess_mgr_cfg->duplicated_packet_bloom_filter.error_rate, 0.0, 1.0);

    // eviction session filter
    ret += load_toml_integer_config(toml_file, "session_manager.evicted_session_bloom_filter.enable", &sess_mgr_cfg->evicted_session_bloom_filter.enable, 0, 1);
    ret += load_toml_integer_config(toml_file, "session_manager.evicted_session_bloom_filter.capacity", &sess_mgr_cfg->evicted_session_bloom_filter.capacity, 1, 4294967295);
    ret += load_toml_integer_config(toml_file, "session_manager.evicted_session_bloom_filter.time_window_ms", &sess_mgr_cfg->evicted_session_bloom_filter.time_window_ms, 1, 60000);
    ret += load_toml_double_config(toml_file, "session_manager.evicted_session_bloom_filter.error_rate", (double *)&sess_mgr_cfg->evicted_session_bloom_filter.error_rate, 0.0, 1.0);

    // TCP reassembly
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_reassembly.enable", &sess_mgr_cfg->tcp_reassembly.enable, 0, 1);
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_reassembly.timeout_ms", &sess_mgr_cfg->tcp_reassembly.timeout_ms, 1, 60000);
    ret += load_toml_integer_config(toml_file, "session_manager.tcp_reassembly.buffered_segments_max", &sess_mgr_cfg->tcp_reassembly.buffered_segments_max, 2, 4096);

    if (ret != 0)
    {
        session_manager_cfg_free(sess_mgr_cfg);
        return NULL;
    }

    return sess_mgr_cfg;
}

void session_manager_cfg_free(struct session_manager_cfg *sess_mgr_cfg)
{
    if (sess_mgr_cfg)
    {
        free(sess_mgr_cfg);
        sess_mgr_cfg = NULL;
    }
}

void session_manager_cfg_print(struct session_manager_cfg *sess_mgr_cfg)
{
    if (sess_mgr_cfg)
    {
        // max session number
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_session_max                               : %lu", sess_mgr_cfg->tcp_session_max);
        SESSION_MANAGER_LOG_INFO("session_manager.udp_session_max                               : %lu", sess_mgr_cfg->udp_session_max);

        // session overload
        SESSION_MANAGER_LOG_INFO("session_manager.evict_old_on_tcp_table_limit                  : %d", sess_mgr_cfg->evict_old_on_tcp_table_limit);
        SESSION_MANAGER_LOG_INFO("session_manager.evict_old_on_udp_table_limit                  : %d", sess_mgr_cfg->evict_old_on_udp_table_limit);

        // limit
        SESSION_MANAGER_LOG_INFO("session_manager.expire_period_ms                              : %lu", sess_mgr_cfg->expire_period_ms);
        SESSION_MANAGER_LOG_INFO("session_manager.expire_batch_max                              : %lu", sess_mgr_cfg->expire_batch_max);

        // TCP timeout
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_timeout_ms.init                           : %lu", sess_mgr_cfg->tcp_timeout_ms.init);
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_timeout_ms.handshake                      : %lu", sess_mgr_cfg->tcp_timeout_ms.handshake);
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_timeout_ms.data                           : %lu", sess_mgr_cfg->tcp_timeout_ms.data);
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_timeout_ms.half_closed                    : %lu", sess_mgr_cfg->tcp_timeout_ms.half_closed);
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_timeout_ms.time_wait                      : %lu", sess_mgr_cfg->tcp_timeout_ms.time_wait);
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_timeout_ms.discard_default                : %lu", sess_mgr_cfg->tcp_timeout_ms.discard_default);
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_timeout_ms.unverified_rst                 : %lu", sess_mgr_cfg->tcp_timeout_ms.unverified_rst);

        // UDP timeout
        SESSION_MANAGER_LOG_INFO("session_manager.udp_timeout_ms.data                           : %lu", sess_mgr_cfg->udp_timeout_ms.data);
        SESSION_MANAGER_LOG_INFO("session_manager.udp_timeout_ms.discard_default                : %lu", sess_mgr_cfg->udp_timeout_ms.discard_default);

        // duplicated packet filter
        SESSION_MANAGER_LOG_INFO("session_manager.duplicated_packet_bloom_filter.enable         : %d", sess_mgr_cfg->duplicated_packet_bloom_filter.enable);
        SESSION_MANAGER_LOG_INFO("session_manager.duplicated_packet_bloom_filter.capacity       : %lu", sess_mgr_cfg->duplicated_packet_bloom_filter.capacity);
        SESSION_MANAGER_LOG_INFO("session_manager.duplicated_packet_bloom_filter.time_window_ms : %lu", sess_mgr_cfg->duplicated_packet_bloom_filter.time_window_ms);
        SESSION_MANAGER_LOG_INFO("session_manager.duplicated_packet_bloom_filter.error_rate     : %f", sess_mgr_cfg->duplicated_packet_bloom_filter.error_rate);

        // eviction session filter
        SESSION_MANAGER_LOG_INFO("session_manager.evicted_session_bloom_filter.enable           : %d", sess_mgr_cfg->evicted_session_bloom_filter.enable);
        SESSION_MANAGER_LOG_INFO("session_manager.evicted_session_bloom_filter.capacity         : %lu", sess_mgr_cfg->evicted_session_bloom_filter.capacity);
        SESSION_MANAGER_LOG_INFO("session_manager.evicted_session_bloom_filter.time_window_ms   : %lu", sess_mgr_cfg->evicted_session_bloom_filter.time_window_ms);
        SESSION_MANAGER_LOG_INFO("session_manager.evicted_session_bloom_filter.error_rate       : %f", sess_mgr_cfg->evicted_session_bloom_filter.error_rate);

        // TCP reassembly
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_reassembly.enable                         : %d", sess_mgr_cfg->tcp_reassembly.enable);
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_reassembly.timeout_ms                     : %lu", sess_mgr_cfg->tcp_reassembly.timeout_ms);
        SESSION_MANAGER_LOG_INFO("session_manager.tcp_reassembly.buffered_segments_max          : %lu", sess_mgr_cfg->tcp_reassembly.buffered_segments_max);
    }
}