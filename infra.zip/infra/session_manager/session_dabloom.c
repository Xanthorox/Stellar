#include "dablooms.h"
#include "session_dabloom.h"

struct session_dabloom
{
    struct expiry_dablooms_handle *dablooms;
};

struct session_dabloom *session_dabloom_new(uint32_t capacity, uint32_t timeout, double error_rate, uint64_t now)
{
    struct session_dabloom *sess_dab = (struct session_dabloom *)calloc(1, sizeof(struct session_dabloom));
    if (sess_dab == NULL)
    {
        return NULL;
    }

    sess_dab->dablooms = expiry_dablooms_new(capacity, error_rate, now, timeout);
    if (sess_dab->dablooms == NULL)
    {
        free(sess_dab);
        return NULL;
    }

    return sess_dab;
}

void session_dabloom_free(struct session_dabloom *sess_dab)
{
    if (sess_dab)
    {
        if (sess_dab->dablooms)
        {
            expiry_dablooms_free(sess_dab->dablooms);
            sess_dab->dablooms = NULL;
        }
        free(sess_dab);
        sess_dab = NULL;
    }
}

// return 1: found
// reutrn 0: no found
int session_dabloom_lookup(struct session_dabloom *sess_dab, const struct tuple6 *key, uint64_t now)
{
    if (expiry_dablooms_search(sess_dab->dablooms, (const char *)key, sizeof(struct tuple6), now) == 1)
    {
        return 1;
    }

    return 0;
}

void session_dabloom_add(struct session_dabloom *sess_dab, const struct tuple6 *key, uint64_t now)
{
    struct tuple6 reverse_key;
    tuple6_reverse(key, &reverse_key);

    expiry_dablooms_add(sess_dab->dablooms, (const char *)key, sizeof(struct tuple6), now);
    expiry_dablooms_add(sess_dab->dablooms, (const char *)&reverse_key, sizeof(struct tuple6), now);
}
