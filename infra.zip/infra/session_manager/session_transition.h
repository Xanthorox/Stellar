#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/session.h"

enum session_inputs
{
    NONE = 0,

    // packet
    TCP_SYN = 1 << 0,
    TCP_SYN_ACK = 1 << 1,
    TCP_FIN = 1 << 2, // Only Fist FIN
    TCP_RST = 1 << 3,
    TCP_DATA = 1 << 4,
    UDP_DATA = 1 << 5,

    // session timeout
    TIMEOUT = 1 << 6,

    // session table full evict
    LRU_EVICT = 1 << 7,

    // port reuse evict
    PORT_REUSE_EVICT = 1 << 8,

    // user close
    USER_CLOSE = 1 << 9,
};

void session_transition_init();
enum session_state session_transition_run(enum session_state curr_state, int inputs);
void session_transition_log(struct session *sess, enum session_state curr_state, enum session_state next_state, int inputs);

#ifdef __cplusplus
}
#endif
