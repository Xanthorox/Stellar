#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "tuple.h"

struct session_table;
struct session_table *session_table_new();
void session_table_free(struct session_table *table);
uint64_t session_table_get_count(struct session_table *table);

typedef void (*session_free_cb)(struct session *sess, void *arg);
void session_table_set_freecb(struct session_table *table, session_free_cb free_cb, void *arg);
void session_table_add(struct session_table *table, struct session *sess);
void session_table_del(struct session_table *table, struct session *sess);

/*
 * When a session is found, it also updates the LRU list,
 * moving the current session to the end of the LRU to indicate that it is the most recently used.
 * If quiet is 1, the LRU list is not updated.
 */
struct session *session_table_find_sessid(struct session_table *table, uint64_t id, uint8_t quiet);
struct session *session_table_find_tuple6(struct session_table *table, const struct tuple6 *tuple, uint8_t quiet);
struct session *session_table_find_tuple4(struct session_table *table, const struct tuple4 *tuple, uint8_t quiet);
struct session *session_table_find_lru(struct session_table *table);

#ifdef __cplusplus
}
#endif
