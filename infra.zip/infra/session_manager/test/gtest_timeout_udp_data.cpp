#include "test_utils.h"

#if 1
TEST(TIMEOUT, UDP_TIMEOUT_DATA1)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S REQ Packet
    printf("\n=> Packet Parse: UDP C2S REQ packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)udp_pkt1_dns_req, sizeof(udp_pkt1_dns_req));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.udp_timeout_ms.data) == NULL);                      // opening -> closing
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.udp_timeout_ms.data + sess_mgr_cfg.udp_timeout_ms.data); // closing -> closed
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

#if 1
TEST(TIMEOUT, UDP_TIMEOUT_DATA2)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S REQ Packet
    printf("\n=> Packet Parse: UDP C2S REQ packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)udp_pkt1_dns_req, sizeof(udp_pkt1_dns_req));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // S2C RESP Packet
    printf("\n=> Packet Parse: UDP S2C RESP packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)udp_pkt2_dns_resp, sizeof(udp_pkt2_dns_resp));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 2 + sess_mgr_cfg.udp_timeout_ms.data) == NULL);                      // active -> closing
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 2 + sess_mgr_cfg.udp_timeout_ms.data + sess_mgr_cfg.udp_timeout_ms.data); // closing -> closed
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
