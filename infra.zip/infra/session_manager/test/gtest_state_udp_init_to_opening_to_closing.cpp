// UDP state machine test: init -> opening -> closing
#include "test_utils.h"

/******************************************************************************
 * case: UDP init -> opening (by C2S Packet)
 * case: UDP opening -> closing (by timeout)
 * ******************************************************************************/

#if 1
TEST(UDP_INIT_TO_OPENING_TO_CLOSING, BY_C2S)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S REQ Packet
    printf("\n=> Packet Parse: UDP C2S REQ packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)udp_pkt1_dns_req, sizeof(udp_pkt1_dns_req));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:61099-121.14.154.93:53-17-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_OPENING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_UDP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 74);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 0);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) == NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == 1);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.udp_timeout_ms.data) == NULL);                      // opening -> closing
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.udp_timeout_ms.data + sess_mgr_cfg.udp_timeout_ms.data); // closing -> closed
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

/******************************************************************************
 * case: UDP init -> opening (by S2C Packet)
 * case: UDP opening -> closing (by timeout)
 ******************************************************************************/

#if 1
TEST(UDP_INIT_TO_OPENING_TO_CLOSING, BY_S2C)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // S2C RESP Packet
    printf("\n=> Packet Parse: UDP S2C RESP packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)udp_pkt2_dns_resp, sizeof(udp_pkt2_dns_resp));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:61099-121.14.154.93:53-17-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_OPENING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_UDP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 550);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) == NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == 1);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.udp_timeout_ms.data) == NULL);                      // opening -> closing
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.udp_timeout_ms.data + sess_mgr_cfg.udp_timeout_ms.data); // closing -> closed
    EXPECT_TRUE(sess);

    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}