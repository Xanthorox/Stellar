#include <time.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

int main(int argc, char **argv)
{
    if (argc != 2)
    {
        printf("Usage: %s <id>\n", argv[0]);
        return -1;
    }

    uint64_t id = atoll(argv[1]);

    uint64_t sequence = id & 0x7FFF;
    uint64_t time_relative = (id >> 15) & 0xFFFFFFF;
    uint64_t seed = (id >> 43) & 0xFFFFF;

    uint64_t thread_id = seed & 0xFF;
    uint64_t instance_id = (seed >> 8) & 0xFFF;

    printf("id: %lu, seed: %lu, instance_id: %lu, thread_id: %lu, time_relative: %lu, sequence: %lu\n", id, seed, instance_id, thread_id, time_relative, sequence);

#define MAX_ID_BASE_TIME (268435456L)

    for (int i = 6; i < 10; i++)
    {
        char buff[64];
        time_t tt = MAX_ID_BASE_TIME * i + time_relative;
        struct tm *tm = localtime(&tt);
        strftime(buff, sizeof(buff), "%Y-%m-%d %H:%M:%S", tm);
        printf("\ttime_period * %d + time_relative => %s\n", i, buff);
    }

    return 0;
}