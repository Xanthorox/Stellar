#include "test_utils.h"

#define TUPLE6_SET_V4_TCP(t6)                               \
    {                                                       \
        memset(&t6, 0, sizeof(struct tuple6));              \
        (t6).addr_family = AF_INET;                         \
        (t6).src_addr.v4.s_addr = inet_addr("192.168.1.2"); \
        (t6).dst_addr.v4.s_addr = inet_addr("192.168.1.3"); \
        (t6).src_port = htons(1234);                        \
        (t6).dst_port = htons(5678);                        \
        (t6).ip_proto = IPPROTO_TCP;                        \
        (t6).domain = 123;                                  \
    }

#define TUPLE6_SET_V6_UDP(t6)                                                  \
    {                                                                          \
        memset(&t6, 0, sizeof(struct tuple6));                                 \
        (t6).addr_family = AF_INET6;                                           \
        inet_pton(AF_INET6, "2001:db8:0:0:0:ff00:42:8329", &(t6).src_addr.v6); \
        inet_pton(AF_INET6, "2001:db8:0:0:0:ff00:42:832a", &(t6).dst_addr.v6); \
        (t6).src_port = htons(2345);                                           \
        (t6).dst_port = htons(6789);                                           \
        (t6).ip_proto = IPPROTO_UDP;                                           \
        (t6).domain = 456;                                                     \
    }

#define TUPLE6_SET_V6_TCP(t6)                                                  \
    {                                                                          \
        memset(&t6, 0, sizeof(struct tuple6));                                 \
        (t6).addr_family = AF_INET6;                                           \
        inet_pton(AF_INET6, "2001:db8:0:0:0:ff00:42:8329", &(t6).src_addr.v6); \
        inet_pton(AF_INET6, "2001:db8:0:0:0:ff00:42:832a", &(t6).dst_addr.v6); \
        (t6).src_port = htons(3456);                                           \
        (t6).dst_port = htons(7890);                                           \
        (t6).ip_proto = IPPROTO_TCP;                                           \
        (t6).domain = 789;                                                     \
    }

#define TUPLE6_TO_TUPLE4(t6, t4)                 \
    {                                            \
        memset(&(t4), 0, sizeof(struct tuple4)); \
        (t4).addr_family = (t6).addr_family;     \
        (t4).src_addr = (t6).src_addr;           \
        (t4).dst_addr = (t6).dst_addr;           \
        (t4).src_port = (t6).src_port;           \
        (t4).dst_port = (t6).dst_port;           \
    }

static void session_free_callback(struct session *sess, void *arg)
{
    if (sess)
    {
        struct session_pool *sess_pool = (struct session_pool *)arg;
        session_pool_release_sessoin(sess_pool, sess);
        sess = NULL;
    }
}

#if 1
TEST(SESSION_TABLE, OP_SESSION)
{
    struct session *sess1 = NULL;
    struct session *sess2 = NULL;
    struct session *sess3 = NULL;

    struct tuple4 sess1_tup4;
    struct tuple4 sess2_tup4;
    struct tuple4 sess3_tup4;

    struct tuple4 sess1_rev_tup4;
    struct tuple4 sess2_rev_tup4;
    struct tuple4 sess3_rev_tup4;

    struct tuple6 sess1_tup6;
    struct tuple6 sess2_tup6;
    struct tuple6 sess3_tup6;

    struct tuple6 sess1_rev_tup6;
    struct tuple6 sess2_rev_tup6;
    struct tuple6 sess3_rev_tup6;

    struct session_pool *sess_pool = NULL;
    struct session_table *sess_table = NULL;

    TUPLE6_SET_V4_TCP(sess1_tup6);
    TUPLE6_SET_V6_UDP(sess2_tup6);
    TUPLE6_SET_V6_TCP(sess3_tup6);

    TUPLE6_TO_TUPLE4(sess1_tup6, sess1_tup4);
    TUPLE6_TO_TUPLE4(sess2_tup6, sess2_tup4);
    TUPLE6_TO_TUPLE4(sess3_tup6, sess3_tup4);

    tuple4_reverse(&sess1_tup4, &sess1_rev_tup4);
    tuple4_reverse(&sess2_tup4, &sess2_rev_tup4);
    tuple4_reverse(&sess3_tup4, &sess3_rev_tup4);

    tuple6_reverse(&sess1_tup6, &sess1_rev_tup6);
    tuple6_reverse(&sess2_tup6, &sess2_rev_tup6);
    tuple6_reverse(&sess3_tup6, &sess3_rev_tup6);

    // Create
    sess_pool = session_pool_new(3);
    EXPECT_TRUE(sess_pool != NULL);
    sess_table = session_table_new();
    EXPECT_TRUE(sess_table != NULL);
    session_table_set_freecb(sess_table, session_free_callback, sess_pool);

    // Add
    sess1 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess1 != NULL);
    session_set_id(sess1, 1);
    session_set_tuple6(sess1, &sess1_tup6);

    sess2 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess2 != NULL);
    session_set_id(sess2, 2);
    session_set_tuple6(sess2, &sess2_tup6);

    sess3 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess3 != NULL);
    session_set_id(sess3, 3);
    session_set_tuple6(sess3, &sess3_tup6);

    session_table_add(sess_table, sess1);
    EXPECT_TRUE(session_table_get_count(sess_table) == 1);
    session_table_add(sess_table, sess2);
    EXPECT_TRUE(session_table_get_count(sess_table) == 2);
    session_table_add(sess_table, sess3);
    EXPECT_TRUE(session_table_get_count(sess_table) == 3);

    // Search
    EXPECT_TRUE(session_table_find_sessid(sess_table, 1, 0) == sess1);
    EXPECT_TRUE(session_table_find_sessid(sess_table, 2, 0) == sess2);
    EXPECT_TRUE(session_table_find_sessid(sess_table, 3, 0) == sess3);

    EXPECT_TRUE(session_table_find_tuple4(sess_table, &sess1_tup4, 0) == sess1);
    EXPECT_TRUE(session_table_find_tuple4(sess_table, &sess2_tup4, 0) == sess2);
    EXPECT_TRUE(session_table_find_tuple4(sess_table, &sess3_tup4, 0) == sess3);

    EXPECT_TRUE(session_table_find_tuple4(sess_table, &sess1_rev_tup4, 0) == sess1);
    EXPECT_TRUE(session_table_find_tuple4(sess_table, &sess2_rev_tup4, 0) == sess2);
    EXPECT_TRUE(session_table_find_tuple4(sess_table, &sess3_rev_tup4, 0) == sess3);

    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess1_tup6, 0) == sess1);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess2_tup6, 0) == sess2);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess3_tup6, 0) == sess3);

    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess1_rev_tup6, 0) == sess1);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess2_rev_tup6, 0) == sess2);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess3_rev_tup6, 0) == sess3);

    // Delete
    session_table_del(sess_table, sess1);
    EXPECT_TRUE(session_table_get_count(sess_table) == 2);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess1_tup6, 0) == NULL);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess1_rev_tup6, 0) == NULL);

    session_table_del(sess_table, sess2);
    EXPECT_TRUE(session_table_get_count(sess_table) == 1);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess2_tup6, 0) == NULL);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess2_rev_tup6, 0) == NULL);

    session_table_del(sess_table, sess3);
    EXPECT_TRUE(session_table_get_count(sess_table) == 0);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess3_tup6, 0) == NULL);
    EXPECT_TRUE(session_table_find_tuple6(sess_table, &sess3_rev_tup6, 0) == NULL);

    // Destroy
    session_table_free(sess_table);
    session_pool_free(sess_pool);
}
#endif

#if 1
TEST(SESSION_TABLE, FIND_OLDEST_NEWEST)
{
    struct session *sess1 = NULL;
    struct session *sess2 = NULL;
    struct session *sess3 = NULL;

    struct tuple6 sess1_tup6;
    struct tuple6 sess2_tup6;
    struct tuple6 sess3_tup6;

    struct session_pool *sess_pool = NULL;
    struct session_table *sess_table = NULL;

    TUPLE6_SET_V4_TCP(sess1_tup6);
    TUPLE6_SET_V6_UDP(sess2_tup6);
    TUPLE6_SET_V6_TCP(sess3_tup6);

    // Create
    sess_pool = session_pool_new(3);
    EXPECT_TRUE(sess_pool != NULL);
    sess_table = session_table_new();
    EXPECT_TRUE(sess_table != NULL);
    session_table_set_freecb(sess_table, session_free_callback, sess_pool);

    // Add Session

    EXPECT_TRUE(session_table_find_lru(sess_table) == NULL);

    sess1 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess1 != NULL);
    session_set_id(sess1, 1);
    session_set_tuple6(sess1, &sess1_tup6);
    session_table_add(sess_table, sess1);
    EXPECT_TRUE(session_table_find_lru(sess_table) == sess1);

    sess2 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess2 != NULL);
    session_set_id(sess2, 2);
    session_set_tuple6(sess2, &sess2_tup6);
    session_table_add(sess_table, sess2);
    EXPECT_TRUE(session_table_find_lru(sess_table) == sess1);

    sess3 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess3 != NULL);
    session_set_id(sess3, 3);
    session_set_tuple6(sess3, &sess3_tup6);
    session_table_add(sess_table, sess3);
    EXPECT_TRUE(session_table_find_lru(sess_table) == sess1);

    // Delete Session

    session_table_del(sess_table, sess1);
    EXPECT_TRUE(session_table_find_lru(sess_table) == sess2);

    session_table_del(sess_table, sess2);
    EXPECT_TRUE(session_table_find_lru(sess_table) == sess3);

    session_table_del(sess_table, sess3);
    EXPECT_TRUE(session_table_find_lru(sess_table) == NULL);

    // Destroy
    session_table_free(sess_table);
    session_pool_free(sess_pool);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
