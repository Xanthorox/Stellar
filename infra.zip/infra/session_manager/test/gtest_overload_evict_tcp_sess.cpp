#include "test_utils.h"

#if 1
TEST(TCP_OVERLOAD, EVICT_OLD_SESS)
{
    struct packet pkt;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;
    struct session_manager_cfg _sess_mgr_cfg;
    memcpy(&_sess_mgr_cfg, &sess_mgr_cfg, sizeof(struct session_manager_cfg));
    _sess_mgr_cfg.tcp_session_max = RX_BURST_MAX * 2;
    _sess_mgr_cfg.udp_session_max = RX_BURST_MAX * 2;

    sess_mgr_rte = session_manager_rte_new(&_sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // new session
    for (uint32_t i = 0; i < _sess_mgr_cfg.tcp_session_max; i++)
    {
        packet_overwrite_v4_saddr(&pkt, (struct in_addr *)&i);
        EXPECT_TRUE(session_manager_rte_new_session(sess_mgr_rte, &pkt, 1));
    }
    printf("=> Session Manager: after add %lu new sessions\n", _sess_mgr_cfg.tcp_session_max);
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == _sess_mgr_cfg.tcp_session_max);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closed == RX_BURST_MAX); // have evicted, have't free
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_evicted == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_table_full == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_session_not_found == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

#if 1
TEST(TCP_OVERLOAD, EVICT_NEW_SESS)
{
    struct packet pkt;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;
    struct session_manager_cfg _sess_mgr_cfg;
    memcpy(&_sess_mgr_cfg, &sess_mgr_cfg, sizeof(struct session_manager_cfg));
    _sess_mgr_cfg.tcp_session_max = RX_BURST_MAX * 2;
    _sess_mgr_cfg.udp_session_max = RX_BURST_MAX * 2;
    _sess_mgr_cfg.evict_old_on_tcp_table_limit = 0;

    sess_mgr_rte = session_manager_rte_new(&_sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // new session
    for (uint32_t i = 0; i < _sess_mgr_cfg.tcp_session_max; i++)
    {
        packet_overwrite_v4_saddr(&pkt, (struct in_addr *)&i);
        EXPECT_TRUE(session_manager_rte_new_session(sess_mgr_rte, &pkt, 1));
    }
    printf("=> Session Manager: after add %lu new sessions\n", _sess_mgr_cfg.tcp_session_max);
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == _sess_mgr_cfg.tcp_session_max);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == _sess_mgr_cfg.tcp_session_max);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closed == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_evicted == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_table_full == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_session_not_found == 0);

    // table full, evict new session
    for (uint32_t i = 0; i < RX_BURST_MAX; i++)
    {
        uint32_t idx = _sess_mgr_cfg.tcp_session_max + i;
        packet_overwrite_v4_saddr(&pkt, (struct in_addr *)&idx);
        EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);
        EXPECT_TRUE(session_manager_rte_new_session(sess_mgr_rte, &pkt, 1) == NULL);
    }
    printf("=> Session Manager: after evicte new session\n");
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == _sess_mgr_cfg.tcp_session_max);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == _sess_mgr_cfg.tcp_session_max);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closed == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_evicted == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_table_full == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_session_not_found == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}