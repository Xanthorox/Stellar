#include "test_utils.h"

#if 1
TEST(TIMEOUT, TCP_TIMEOUT_HANDSHAKE)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // S2C SYNACK Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.tcp_timeout_ms.handshake) == NULL);
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.tcp_timeout_ms.handshake + sess_mgr_cfg.tcp_timeout_ms.data);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
