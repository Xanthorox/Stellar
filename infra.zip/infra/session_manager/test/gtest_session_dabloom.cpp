#include "test_utils.h"

TEST(SESSION_DABLOOM, TEST)
{
    struct tuple6 c2s_key;
    struct tuple6 s2c_key;

    uint32_t capacity = 1000000;
    uint32_t timeout = 2;
    double error_rate = 0.00001;

    memset(&c2s_key, 0, sizeof(c2s_key));
    c2s_key.addr_family = AF_INET;
    c2s_key.src_addr.v4.s_addr = inet_addr("192.168.1.2");
    c2s_key.dst_addr.v4.s_addr = inet_addr("192.168.1.3");
    c2s_key.src_port = 0x0303;
    c2s_key.dst_port = 0x0404;
    c2s_key.ip_proto = 0x05;
    c2s_key.domain = 0x0606060606060606;

    memset(&s2c_key, 0, sizeof(s2c_key));
    s2c_key.addr_family = AF_INET;
    s2c_key.src_addr.v4.s_addr = inet_addr("192.168.1.3");
    s2c_key.dst_addr.v4.s_addr = inet_addr("192.168.1.2");
    s2c_key.src_port = 0x0404;
    s2c_key.dst_port = 0x0303;
    s2c_key.ip_proto = 0x05;
    s2c_key.domain = 0x0606060606060606;

    struct session_dabloom *filter = session_dabloom_new(capacity, timeout, error_rate, 1);
    EXPECT_TRUE(filter != nullptr);

    EXPECT_TRUE(session_dabloom_lookup(filter, &c2s_key, 1) == 0); // no found
    EXPECT_TRUE(session_dabloom_lookup(filter, &s2c_key, 1) == 0); // no found
    session_dabloom_add(filter, &c2s_key, 1);                      // add
    EXPECT_TRUE(session_dabloom_lookup(filter, &c2s_key, 1) == 1); // found
    EXPECT_TRUE(session_dabloom_lookup(filter, &s2c_key, 1) == 1); // found
    EXPECT_TRUE(session_dabloom_lookup(filter, &c2s_key, 2) == 1); // found
    EXPECT_TRUE(session_dabloom_lookup(filter, &s2c_key, 2) == 1); // found
    EXPECT_TRUE(session_dabloom_lookup(filter, &c2s_key, 3) == 0); // not found
    EXPECT_TRUE(session_dabloom_lookup(filter, &s2c_key, 3) == 0); // not found

    session_dabloom_free(filter);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
