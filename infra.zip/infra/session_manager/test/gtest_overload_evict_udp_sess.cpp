#include "test_utils.h"

#if 1
TEST(UDP_OVERLOAD, EVICT_OLD_SESS)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;
    struct session_manager_cfg _sess_mgr_cfg;
    memcpy(&_sess_mgr_cfg, &sess_mgr_cfg, sizeof(struct session_manager_cfg));
    _sess_mgr_cfg.tcp_session_max = RX_BURST_MAX * 2;
    _sess_mgr_cfg.udp_session_max = RX_BURST_MAX * 2;

    sess_mgr_rte = session_manager_rte_new(&_sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S REQ Packet
    printf("\n=> Packet Parse: UDP C2S REQ packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)udp_pkt1_dns_req, sizeof(udp_pkt1_dns_req));
    printf("<= Packet Parse: done\n\n");

    // new session
    for (uint32_t i = 0; i < _sess_mgr_cfg.udp_session_max; i++)
    {
        packet_overwrite_v4_saddr(&pkt, (struct in_addr *)&i);
        EXPECT_TRUE(session_manager_rte_new_session(sess_mgr_rte, &pkt, 1));
    }
    printf("=> Session Manager: after add %lu new sessions\n", _sess_mgr_cfg.udp_session_max);
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == _sess_mgr_cfg.udp_session_max);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closed == RX_BURST_MAX); // have evicted, have't free
    EXPECT_TRUE(sess_mgr_stat->udp_sess_evicted == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_table_full == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_session_evicted == 0);

    // evicted session
    while (1)
    {
        sess = session_manager_rte_get_evicted_session(sess_mgr_rte);
        if (sess)
        {
            session_manager_rte_free_session(sess_mgr_rte, sess);
        }
        else
        {
            break;
        }
    }

    for (uint32_t i = 0; i < RX_BURST_MAX; i++)
    {
        packet_overwrite_v4_saddr(&pkt, (struct in_addr *)&i);
        EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);
        EXPECT_TRUE(session_manager_rte_new_session(sess_mgr_rte, &pkt, 1) == NULL); // hit evicted session, can't renew session
    }
    printf("=> Session Manager: after readd %d evicted sessions\n", RX_BURST_MAX);
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closed == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_evicted == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_table_full == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_session_evicted == RX_BURST_MAX);

    // evicted session timeout
    uint32_t idx = 0;
    packet_overwrite_v4_saddr(&pkt, (struct in_addr *)&idx);
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);
    EXPECT_TRUE(session_manager_rte_new_session(sess_mgr_rte, &pkt, 1 + _sess_mgr_cfg.evicted_session_bloom_filter.time_window_ms));
    printf("=> Session Manager: after evicted session timeout\n");
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == RX_BURST_MAX + 1);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closed == 1); // have evicted, have't free
    EXPECT_TRUE(sess_mgr_stat->udp_sess_evicted == RX_BURST_MAX + 1);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_table_full == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_session_evicted == RX_BURST_MAX);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

#if 1
TEST(UDP_OVERLOAD, EVICT_NEW_SESS)
{
    struct packet pkt;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;
    struct session_manager_cfg _sess_mgr_cfg;
    memcpy(&_sess_mgr_cfg, &sess_mgr_cfg, sizeof(struct session_manager_cfg));
    _sess_mgr_cfg.tcp_session_max = RX_BURST_MAX * 2;
    _sess_mgr_cfg.udp_session_max = RX_BURST_MAX * 2;
    _sess_mgr_cfg.evict_old_on_udp_table_limit = 0;

    sess_mgr_rte = session_manager_rte_new(&_sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S REQ Packet
    printf("\n=> Packet Parse: UDP C2S REQ packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)udp_pkt1_dns_req, sizeof(udp_pkt1_dns_req));
    printf("<= Packet Parse: done\n\n");

    // new session
    for (uint32_t i = 0; i < _sess_mgr_cfg.udp_session_max; i++)
    {
        packet_overwrite_v4_saddr(&pkt, (struct in_addr *)&i);
        EXPECT_TRUE(session_manager_rte_new_session(sess_mgr_rte, &pkt, 1));
    }
    printf("=> Session Manager: after add %lu new sessions\n", _sess_mgr_cfg.udp_session_max);
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == _sess_mgr_cfg.udp_session_max);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == _sess_mgr_cfg.udp_session_max);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closed == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_evicted == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_table_full == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_session_evicted == 0);

    // evicted session
    EXPECT_TRUE(session_manager_rte_get_evicted_session(sess_mgr_rte) == NULL);

    // table full, evict new session
    for (uint32_t i = 0; i < RX_BURST_MAX; i++)
    {
        uint32_t idx = _sess_mgr_cfg.udp_session_max + i;
        packet_overwrite_v4_saddr(&pkt, (struct in_addr *)&idx);
        EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);
        EXPECT_TRUE(session_manager_rte_new_session(sess_mgr_rte, &pkt, 1) == NULL);
    }
    printf("=> Session Manager: after readd %d evicted session\n", RX_BURST_MAX);
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_used == _sess_mgr_cfg.udp_session_max);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_opening == _sess_mgr_cfg.udp_session_max);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closing == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_closed == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_sess_evicted == 0);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_table_full == RX_BURST_MAX);
    EXPECT_TRUE(sess_mgr_stat->udp_pkts_bypass_session_evicted == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}