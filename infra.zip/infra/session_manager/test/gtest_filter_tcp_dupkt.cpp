#include "test_utils.h"

#if 1
TEST(TCP_DUPKT_FILTER_ENABLE, SYN_DUP)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    // C2S SYN dup Packet
    printf("\n=> Packet Parse: TCP C2S SYN dup packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == -1);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 1);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 1);

    // C2S SYN retransmission Packet
    printf("\n=> Packet Parse: TCP C2S SYN retransmission packet\n");
    char syn_retransmission[1500] = {0};
    memcpy(syn_retransmission, tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)syn_retransmission, sizeof(tcp_pkt1_c2s_syn));
    packet_overwrite_ipid(&pkt, 0x1234);
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 1);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 1);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

#if 1
TEST(TCP_DUPKT_FILTER_ENABLE, SYNACK_DUP)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // S2C SYNACK Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    // S2C SYNACK dup Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK dup packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == -1);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 1);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 1);

    // S2C SYNACK retransmission Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK retransmission packet\n");
    char synack_retransmission[1500] = {0};
    memcpy(synack_retransmission, tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)synack_retransmission, sizeof(tcp_pkt2_s2c_syn_ack));
    packet_overwrite_ipid(&pkt, 0x1234);
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 1);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 1);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

#if 1
TEST(TCP_DUPKT_FILTER_ENABLE, SKIP)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;
    char syn_retransmission[1500] = {0};

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    // C2S SYN retransmission Packet
    printf("\n=> Packet Parse: TCP C2S SYN retransmission packet\n");
    memcpy(syn_retransmission, tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)syn_retransmission, sizeof(tcp_pkt1_c2s_syn));
    packet_overwrite_ipid(&pkt, 0x1234);
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    // C2S SYN retransmission Packet
    printf("\n=> Packet Parse: TCP C2S SYN retransmission packet\n");
    memcpy(syn_retransmission, tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)syn_retransmission, sizeof(tcp_pkt1_c2s_syn));
    packet_overwrite_ipid(&pkt, 0x1235);
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    // C2S SYN dup Packet
    printf("\n=> Packet Parse: TCP C2S SYN dup packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

#if 1
TEST(TCP_DUPKT_FILTER_DISABLE, SYN_DUP)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;
    struct session_manager_cfg _sess_mgr_cfg;
    memcpy(&_sess_mgr_cfg, &sess_mgr_cfg, sizeof(struct session_manager_cfg));
    _sess_mgr_cfg.duplicated_packet_bloom_filter.enable = 0;

    sess_mgr_rte = session_manager_rte_new(&_sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    // C2S SYN dup Packet
    printf("\n=> Packet Parse: TCP C2S SYN dup packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

#if 1
TEST(TCP_DUPKT_FILTER_DISABLE, SYNACK_DUP)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;
    struct session_manager_cfg _sess_mgr_cfg;
    memcpy(&_sess_mgr_cfg, &sess_mgr_cfg, sizeof(struct session_manager_cfg));
    _sess_mgr_cfg.duplicated_packet_bloom_filter.enable = 0;

    sess_mgr_rte = session_manager_rte_new(&_sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // S2C SYNACK Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    // S2C SYNACK dup Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK dup packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_pkts_bypass_duplicated == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}