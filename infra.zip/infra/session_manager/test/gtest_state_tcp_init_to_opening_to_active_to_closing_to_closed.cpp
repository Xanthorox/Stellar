// TCP state machine test: init -> opening -> active -> closing -> closed
#include "test_utils.h"

#if 1
TEST(TCP_INIT_TO_OPENING_TO_ACTIVE_TO_CLOSING_TO_CLOSED, TEST)
{
    char buffer[1024];
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_OPENING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 0);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) == NULL);

    // S2C SYNACK Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_OPENING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // C2S ACK Packet
    printf("\n=> Packet Parse: TCP C2S ACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt3_c2s_ack, sizeof(tcp_pkt3_c2s_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_OPENING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // C2S REQ Packet
    printf("\n=> Packet Parse: TCP C2S REQ packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt4_c2s_http_req, sizeof(tcp_pkt4_c2s_http_req));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 4) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_ACTIVE);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66 + 145);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // S2C ACK Packet
    printf("\n=> Packet Parse: TCP S2C ACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt5_s2c_ack, sizeof(tcp_pkt5_s2c_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 5) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_ACTIVE);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66 + 145);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1 + 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // S2C HTTP Resp Packet1
    printf("\n=> Packet Parse: TCP S2C Resp packet1\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt6_s2c_http_resq_1, sizeof(tcp_pkt6_s2c_http_resq_1));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 6) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_ACTIVE);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66 + 145);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74 + 66 + 1354);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // S2C HTTP Resp Packet2
    printf("\n=> Packet Parse: TCP S2C Resp packet2\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt7_s2c_http_resp_2, sizeof(tcp_pkt7_s2c_http_resp_2));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 7) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_ACTIVE);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66 + 145);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74 + 66 + 1354 + 385);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // C2S ACK Packet
    printf("\n=> Packet Parse: TCP C2S ACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt8_c2s_ack, sizeof(tcp_pkt8_c2s_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 8) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_ACTIVE);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66 + 145 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74 + 66 + 1354 + 385);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // C2S FIN Packet
    printf("\n=> Packet Parse: TCP C2S FIN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt9_c2s_fin, sizeof(tcp_pkt9_c2s_fin));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 9) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_FIN);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66 + 145 + 66 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74 + 66 + 1354 + 385);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // S2C FIN Packet
    printf("\n=> Packet Parse: TCP S2C FIN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt10_s2c_fin, sizeof(tcp_pkt10_s2c_fin));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 10) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_FIN);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66 + 145 + 66 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74 + 66 + 1354 + 385 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // C2S ACK Packet
    printf("\n=> Packet Parse: TCP C2S ACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt11_c2s_ack, sizeof(tcp_pkt11_c2s_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 11) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    memset(buffer, 0, sizeof(buffer));
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_FIN);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66 + 145 + 66 + 66 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74 + 66 + 1354 + 385 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1 + 1 + 1 + 1 + 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 1);

    // expire session
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 11 + sess_mgr_cfg.tcp_timeout_ms.time_wait);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_FIN);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}