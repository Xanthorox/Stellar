// TCP state machine test: opening -> closing
#include "test_utils.h"

/******************************************************************************
 * case: TCP opening -> closing (by FIN-FIN)
 ******************************************************************************/

#if 1
TEST(TCP_OPENING_TO_CLOSING, BY_FIN_FIN)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // C2S FIN Packet
    printf("\n=> Packet Parse: TCP C2S FIN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt9_c2s_fin, sizeof(tcp_pkt9_c2s_fin));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    // S2C FIN Packet
    printf("\n=> Packet Parse: TCP S2C FIN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt10_s2c_fin, sizeof(tcp_pkt10_s2c_fin));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_FIN);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 1);

    // expire session
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 3 + sess_mgr_cfg.tcp_timeout_ms.time_wait);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_FIN);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

/******************************************************************************
 * case: TCP opening -> closing (by C2S RST)
 ******************************************************************************/

#if 1
TEST(TCP_OPENING_TO_CLOSING, BY_C2S_RST)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // C2S RST Packet
    printf("\n=> Packet Parse: TCP C2S RST packet\n");
    char tcp_pkt_c2s_rst[1500] = {0};
    memcpy(tcp_pkt_c2s_rst, tcp_pkt9_c2s_fin, sizeof(tcp_pkt9_c2s_fin));
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt_c2s_rst, sizeof(tcp_pkt9_c2s_fin));
    const struct layer_internal *tcp_layer = packet_get_innermost_layer(&pkt, LAYER_PROTO_TCP);
    EXPECT_TRUE(tcp_layer);
    struct tcphdr *hdr = (struct tcphdr *)tcp_layer->hdr_ptr;
    hdr->th_flags = TH_RST;
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_RST);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 0);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) == NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 1);

    // expire session
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 2 + sess_mgr_cfg.tcp_timeout_ms.unverified_rst);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_RST);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

/******************************************************************************
 * case: TCP opening -> closing (by S2C RST)
 ******************************************************************************/

#if 1
TEST(TCP_OPENING_TO_CLOSING, BY_S2C_RST)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // S2C RST Packet
    printf("\n=> Packet Parse: TCP S2C RST packet\n");
    char tcp_pkt_s2c_rst[1500] = {0};
    memcpy(tcp_pkt_s2c_rst, tcp_pkt10_s2c_fin, sizeof(tcp_pkt10_s2c_fin));
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt_s2c_rst, sizeof(tcp_pkt10_s2c_fin));
    const struct layer_internal *tcp_layer = packet_get_innermost_layer(&pkt, LAYER_PROTO_TCP);
    EXPECT_TRUE(tcp_layer);
    struct tcphdr *hdr = (struct tcphdr *)tcp_layer->hdr_ptr;
    hdr->th_flags = TH_RST;
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_SERVER_RST);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 1);

    // expire session
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 2 + sess_mgr_cfg.tcp_timeout_ms.unverified_rst);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_SERVER_RST);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

/******************************************************************************
 * case: TCP opening -> closing (by init timeout)
 ******************************************************************************/

#if 1
TEST(TCP_OPENING_TO_CLOSING, BY_INIT_TIMEOUT)
{
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.tcp_timeout_ms.init) == NULL);
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 1 + sess_mgr_cfg.tcp_timeout_ms.init + sess_mgr_cfg.tcp_timeout_ms.data);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

/******************************************************************************
 * case: TCP opening -> closing (by handshake timeout)
 ******************************************************************************/

#if 1
TEST(TCP_OPENING_TO_CLOSING, BY_HANDSHAKE_TIMEOUT)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // S2C SYNACK Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_OPENING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 2 + sess_mgr_cfg.tcp_timeout_ms.handshake) == NULL);
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 2 + sess_mgr_cfg.tcp_timeout_ms.handshake + sess_mgr_cfg.tcp_timeout_ms.data);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

/******************************************************************************
 * case: TCP opening -> closing (by data timeout)
 ******************************************************************************/

#if 1
TEST(TCP_OPENING_TO_CLOSING, BY_DATA_TIMEOUT)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // S2C SYNACK Packet
    printf("\n=> Packet Parse: TCP S2C SYNACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt2_s2c_syn_ack, sizeof(tcp_pkt2_s2c_syn_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    // C2S ACK Packet
    printf("\n=> Packet Parse: TCP C2S ACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt3_c2s_ack, sizeof(tcp_pkt3_c2s_ack));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_OPENING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 74);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 3 + sess_mgr_cfg.tcp_timeout_ms.data) == NULL);
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 3 + sess_mgr_cfg.tcp_timeout_ms.data + sess_mgr_cfg.tcp_timeout_ms.data);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

/******************************************************************************
 * case: TCP opening -> closing (by C2S half FIN)
 ******************************************************************************/

#if 1
TEST(TCP_OPENING_TO_CLOSING, BY_C2S_HALF_FIN)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // C2S FIN Packet
    printf("\n=> Packet Parse: TCP C2S FIN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt9_c2s_fin, sizeof(tcp_pkt9_c2s_fin));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_FIN);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78 + 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 0);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1 + 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 0);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_C2S);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) == NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 1);

    // expire session
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 2 + sess_mgr_cfg.tcp_timeout_ms.half_closed);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_CLIENT_FIN);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

/******************************************************************************
 * case: TCP opening -> closing (by S2C half FIN)
 ******************************************************************************/

#if 1
TEST(TCP_OPENING_TO_CLOSING, BY_S2C_HALF_FIN)
{
    char buffer[1024] = {0};
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;
    struct session_manager_stat *sess_mgr_stat = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // S2C FIN Packet
    printf("\n=> Packet Parse: TCP S2C FIN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_pkt10_s2c_fin, sizeof(tcp_pkt10_s2c_fin));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    EXPECT_TRUE(session_get_id(sess) != 0);
    tuple6_to_str(session_get_tuple6(sess), buffer, sizeof(buffer));
    EXPECT_STREQ(buffer, "192.168.38.105:60111-93.184.216.34:80-6-0");
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSING);
    EXPECT_TRUE(session_get_type(sess) == SESSION_TYPE_TCP);
    EXPECT_TRUE(session_has_duplicate_traffic(sess) == 0);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_SERVER_FIN);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_BYTES_RECEIVED) == 78);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_BYTES_RECEIVED) == 66);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_C2S, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_stat(sess, FLOW_TYPE_S2C, STAT_RAW_PACKETS_RECEIVED) == 1);
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_START));
    EXPECT_TRUE(session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    EXPECT_TRUE(session_get_current_packet(sess) == &pkt);
    EXPECT_TRUE(session_get_flow_type(sess) == FLOW_TYPE_S2C);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_C2S) != NULL);
    EXPECT_TRUE(session_get_first_packet(sess, FLOW_TYPE_S2C) != NULL);
    session_print(sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 1);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 1);

    // expire session
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 2 + sess_mgr_cfg.tcp_timeout_ms.half_closed);
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_SERVER_FIN);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    // check stat
    sess_mgr_stat = session_manager_rte_get_stat(sess_mgr_rte);
    EXPECT_TRUE(sess_mgr_stat);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_used == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_opening == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_active == 0);
    EXPECT_TRUE(sess_mgr_stat->tcp_sess_closing == 0);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}