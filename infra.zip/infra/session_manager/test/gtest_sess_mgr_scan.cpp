#include "test_utils.h"

static inline void mached_session_print(const char *title, struct session_manager_rte *sess_mgr_rte, uint64_t mached_sess_id[], uint64_t mached_sess_num)
{
    printf("%-*s mached_sess_num: %lu\n", 40, title, mached_sess_num);
    for (uint64_t i = 0; i < mached_sess_num; i++)
    {
        struct session *sess = session_manager_rte_lookup_session_by_id(sess_mgr_rte, mached_sess_id[i]);
        printf("session id: %lu, addr: %s, type: %s, state: %s, start: %lu, last: %lu\n",
               mached_sess_id[i], session_get_readable_addr(sess),
               session_type_to_str(session_get_type(sess)),
               session_state_to_str(session_get_current_state(sess)),
               session_get_timestamp(sess, SESSION_TIMESTAMP_START),
               session_get_timestamp(sess, SESSION_TIMESTAMP_LAST));
    }
}

#if 1
TEST(SESS_MGR_SCAN, OPTS)
{
    char buff[1500] = {0};
    uint64_t mached_sess_num = 0;
    uint64_t mached_sess_id[1460];
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;

    struct in_addr v4_src_addr1 = {};
    struct in_addr v4_src_addr2 = {};
    struct in_addr v4_src_addr3 = {};
    struct in_addr v4_dst_addr = {};
    struct in_addr v4_min_addr = {};
    struct in_addr v4_max_addr = {};
    struct in_addr v4_src_subnet_beg = {};
    struct in_addr v4_src_subnet_end = {};
    struct in_addr v4_dst_subnet_beg = {};
    struct in_addr v4_dst_subnet_end = {};

    v4_src_addr1.s_addr = inet_addr("192.168.1.1");
    v4_src_addr2.s_addr = inet_addr("192.168.1.2");
    v4_src_addr3.s_addr = inet_addr("192.168.1.3");
    v4_dst_addr.s_addr = inet_addr("93.184.216.34");

    v4_min_addr.s_addr = inet_addr("0.0.0.0");
    v4_max_addr.s_addr = inet_addr("255.255.255.255");

    v4_src_subnet_beg.s_addr = inet_addr("192.168.1.0");
    v4_src_subnet_end.s_addr = inet_addr("192.168.1.255");

    v4_dst_subnet_beg.s_addr = inet_addr("93.184.216.0");
    v4_dst_subnet_end.s_addr = inet_addr("93.184.216.255");

    struct in6_addr v6_src_addr = {};
    struct in6_addr v6_dst_addr = {};
    struct in6_addr v6_min_addr = {};
    struct in6_addr v6_max_addr = {};
    struct in6_addr v6_src_subnet_beg = {};
    struct in6_addr v6_src_subnet_end = {};
    struct in6_addr v6_dst_subnet_beg = {};
    struct in6_addr v6_dst_subnet_end = {};

    inet_pton(AF_INET6, "dead::beef", &v6_src_addr);
    inet_pton(AF_INET6, "cafe::babe", &v6_dst_addr);

    inet_pton(AF_INET6, "0000:0000:0000:0000:0000:0000:0000:0000", &v6_min_addr);
    inet_pton(AF_INET6, "ffff:ffff:ffff:ffff:ffff:ffff:ffff:ffff", &v6_max_addr);

    inet_pton(AF_INET6, "dead::0000", &v6_src_subnet_beg);
    inet_pton(AF_INET6, "dead::ffff", &v6_src_subnet_end);

    inet_pton(AF_INET6, "cafe::0000", &v6_dst_subnet_beg);
    inet_pton(AF_INET6, "cafe::ffff", &v6_dst_subnet_end);

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // new session
    memset(&pkt, 0, sizeof(pkt));
    memcpy(buff, tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    packet_parse(&pkt, (const char *)buff, sizeof(tcp_pkt1_c2s_syn));
    packet_overwrite_v4_saddr(&pkt, &v4_src_addr1);
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    // new session
    memset(&pkt, 0, sizeof(pkt));
    memcpy(buff, tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    packet_parse(&pkt, (const char *)buff, sizeof(tcp_pkt1_c2s_syn));
    packet_overwrite_v4_saddr(&pkt, &v4_src_addr2);
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 2);
    EXPECT_TRUE(sess);

    // new session
    memset(&pkt, 0, sizeof(pkt));
    memcpy(buff, tcp_pkt1_c2s_syn, sizeof(tcp_pkt1_c2s_syn));
    packet_parse(&pkt, (const char *)buff, sizeof(tcp_pkt1_c2s_syn));
    packet_overwrite_v4_saddr(&pkt, &v4_src_addr3);
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 3);
    EXPECT_TRUE(sess);

    // new session
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)ipv6_in_ipv6_udp, sizeof(ipv6_in_ipv6_udp));
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 4);
    EXPECT_TRUE(sess);

    struct session_filter filter = {};

    /**************************************************************************
     * scan session type
     **************************************************************************/

    // TCP
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.type = SESSION_TYPE_TCP;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 3);
    mached_session_print("scan session type: TCP", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // UDP
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.type = SESSION_TYPE_UDP;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 1);
    mached_session_print("scan session type: UDP", sess_mgr_rte, mached_sess_id, mached_sess_num);

    /**************************************************************************
     * scan session state
     **************************************************************************/

    // OPENING
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.state = SESSION_STATE_OPENING;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 4);
    mached_session_print("scan session state: OPENING", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // ACTIVE
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.state = SESSION_STATE_ACTIVE;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 0);
    mached_session_print("scan session state: ACTIVE", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // CLOSING
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.state = SESSION_STATE_CLOSING;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 0);
    mached_session_print("scan session state: CLOSING", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // DISCARD
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.state = SESSION_STATE_DISCARD;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 0);
    mached_session_print("scan session state: DISCARD", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // CLOSED
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.state = SESSION_STATE_CLOSED;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 0);
    mached_session_print("scan session state: CLOSED", sess_mgr_rte, mached_sess_id, mached_sess_num);

    /**************************************************************************
     * scan source address
     **************************************************************************/

    // IPv4
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.src_family = AF_INET;
    filter.src_addr_range[0].v4 = v4_src_addr1;
    filter.src_addr_range[1].v4 = v4_src_addr1;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 1);
    mached_session_print("scan source address: IPv4", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv4 subnet
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.src_family = AF_INET;
    filter.src_addr_range[0].v4 = v4_src_subnet_beg;
    filter.src_addr_range[1].v4 = v4_src_subnet_end;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 3);
    mached_session_print("scan source address: IPv4 subnet", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv4 min max
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.src_family = AF_INET;
    filter.src_addr_range[0].v4 = v4_min_addr;
    filter.src_addr_range[1].v4 = v4_max_addr;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 3);
    mached_session_print("scan source address: IPv4 min max", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv6
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.src_family = AF_INET6;
    memcpy(&filter.src_addr_range[0].v6, &v6_src_addr, sizeof(v6_src_addr));
    memcpy(&filter.src_addr_range[1].v6, &v6_src_addr, sizeof(v6_src_addr));

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 1);
    mached_session_print("scan source address: IPv6", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv6 subnet
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.src_family = AF_INET6;
    memcpy(&filter.src_addr_range[0].v6, &v6_src_subnet_beg, sizeof(v6_src_subnet_beg));
    memcpy(&filter.src_addr_range[1].v6, &v6_src_subnet_end, sizeof(v6_src_subnet_end));

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 1);
    mached_session_print("scan source address: IPv6 subnet", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv6 min max
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.src_family = AF_INET6;
    memcpy(&filter.src_addr_range[0].v6, &v6_min_addr, sizeof(v6_min_addr));
    memcpy(&filter.src_addr_range[1].v6, &v6_max_addr, sizeof(v6_max_addr));

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 1);
    mached_session_print("scan source address: IPv6 min max", sess_mgr_rte, mached_sess_id, mached_sess_num);

    /**************************************************************************
     * scan destination address
     **************************************************************************/

    // IPv4
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.dst_family = AF_INET;
    filter.dst_addr_range[0].v4 = v4_dst_addr;
    filter.dst_addr_range[1].v4 = v4_dst_addr;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 3);
    mached_session_print("scan destination address: IPv4", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv4 subnet
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.dst_family = AF_INET;
    filter.dst_addr_range[0].v4 = v4_dst_subnet_beg;
    filter.dst_addr_range[1].v4 = v4_dst_subnet_end;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 3);
    mached_session_print("scan destination address: IPv4 subnet", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv4 min max
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.dst_family = AF_INET;
    filter.dst_addr_range[0].v4 = v4_min_addr;
    filter.dst_addr_range[1].v4 = v4_max_addr;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 3);
    mached_session_print("scan destination address: IPv4 min max", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv6
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.dst_family = AF_INET6;
    memcpy(&filter.dst_addr_range[0].v6, &v6_dst_addr, sizeof(v6_dst_addr));
    memcpy(&filter.dst_addr_range[1].v6, &v6_dst_addr, sizeof(v6_dst_addr));

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 1);
    mached_session_print("scan destination address: IPv6", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv6 subnet
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.dst_family = AF_INET6;
    memcpy(&filter.dst_addr_range[0].v6, &v6_dst_subnet_beg, sizeof(v6_dst_subnet_beg));
    memcpy(&filter.dst_addr_range[1].v6, &v6_dst_subnet_end, sizeof(v6_dst_subnet_end));

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 1);
    mached_session_print("scan destination address: IPv6 subnet", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // IPv6 min max
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.dst_family = AF_INET6;
    memcpy(&filter.dst_addr_range[0].v6, &v6_min_addr, sizeof(v6_min_addr));
    memcpy(&filter.dst_addr_range[1].v6, &v6_max_addr, sizeof(v6_max_addr));

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 1);
    mached_session_print("scan destination address: IPv6 min max", sess_mgr_rte, mached_sess_id, mached_sess_num);

    /**************************************************************************
     * scan source port
     **************************************************************************/

    // hit
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.src_port = htons(60111);

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 3);
    mached_session_print("scan source port: hit", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // miss
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.src_port = htons(60110);

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 0);
    mached_session_print("scan source port: miss", sess_mgr_rte, mached_sess_id, mached_sess_num);

    /**************************************************************************
     * scan destination port
     **************************************************************************/

    // hit
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.dst_port = htons(80);

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 3);
    mached_session_print("scan destination port: hit", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // miss
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.dst_port = htons(81);

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 0);
    mached_session_print("scan destination port: miss", sess_mgr_rte, mached_sess_id, mached_sess_num);

    /**************************************************************************
     * scan session create time
     **************************************************************************/

    // hit
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.sess_created_ts_in_ms = 1;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 4);
    mached_session_print("scan session create time: hit", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // miss
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.sess_created_ts_in_ms = 5;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 0);
    mached_session_print("scan session create time: miss", sess_mgr_rte, mached_sess_id, mached_sess_num);

    /**************************************************************************
     * scan last packet receive time
     **************************************************************************/

    // hit
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.pkt_received_ts_in_ms = 1;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 4);
    mached_session_print("scan last packet receive time: hit", sess_mgr_rte, mached_sess_id, mached_sess_num);

    // miss
    memset(&filter, 0, sizeof(filter));
    filter.cursor = 0;
    filter.count = 1460;
    filter.pkt_received_ts_in_ms = 5;

    mached_sess_num = session_manager_rte_scan_session(sess_mgr_rte, &filter, mached_sess_id, sizeof(mached_sess_id) / sizeof(mached_sess_id[0]));
    EXPECT_TRUE(mached_sess_num == 0);
    mached_session_print("scan last packet receive time: miss", sess_mgr_rte, mached_sess_id, mached_sess_num);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}