#include "test_utils.h"

TEST(SESSION_POOL, POP_PUSH)
{
    struct session *sess1 = NULL;
    struct session *sess2 = NULL;
    struct session *sess3 = NULL;
    struct session *sess4 = NULL;
    struct session_pool *sess_pool = NULL;

    // new
    sess_pool = session_pool_new(3);
    EXPECT_TRUE(sess_pool != NULL);
    EXPECT_TRUE(session_pool_get_free_num(sess_pool) == 3);
    EXPECT_TRUE(session_pool_get_used_num(sess_pool) == 0);

    // pop
    sess1 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess1 != NULL);
    EXPECT_TRUE(session_pool_get_free_num(sess_pool) == 2);
    EXPECT_TRUE(session_pool_get_used_num(sess_pool) == 1);

    sess2 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess2 != NULL);
    EXPECT_TRUE(session_pool_get_free_num(sess_pool) == 1);
    EXPECT_TRUE(session_pool_get_used_num(sess_pool) == 2);

    sess3 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess3 != NULL);
    EXPECT_TRUE(session_pool_get_free_num(sess_pool) == 0);
    EXPECT_TRUE(session_pool_get_used_num(sess_pool) == 3);

    sess4 = session_pool_acquire_sessoin(sess_pool);
    EXPECT_TRUE(sess4 == NULL);
    EXPECT_TRUE(session_pool_get_free_num(sess_pool) == 0);
    EXPECT_TRUE(session_pool_get_used_num(sess_pool) == 3);

    // push
    session_pool_release_sessoin(sess_pool, sess1);
    EXPECT_TRUE(session_pool_get_free_num(sess_pool) == 1);
    EXPECT_TRUE(session_pool_get_used_num(sess_pool) == 2);

    session_pool_release_sessoin(sess_pool, sess2);
    EXPECT_TRUE(session_pool_get_free_num(sess_pool) == 2);
    EXPECT_TRUE(session_pool_get_used_num(sess_pool) == 1);

    session_pool_release_sessoin(sess_pool, sess3);
    EXPECT_TRUE(session_pool_get_free_num(sess_pool) == 3);
    EXPECT_TRUE(session_pool_get_used_num(sess_pool) == 0);

    // free
    session_pool_free(sess_pool);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
