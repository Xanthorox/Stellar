#include "test_utils.h"

#if 1
TEST(SESS_MGR_TCP_REASSEMBLY, OUT_OF_ORDER)
{
    struct tcp_segment *seg;
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_out_of_order_pkt1, sizeof(tcp_out_of_order_pkt1));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg == NULL);

    // C2S ACK Packet
    printf("\n=> Packet Parse: TCP C2S ACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_out_of_order_pkt2, sizeof(tcp_out_of_order_pkt2));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg == NULL);

    // C2S Data Packet 2222
    printf("\n=> Packet Parse: TCP C2S Data packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_out_of_order_pkt3, sizeof(tcp_out_of_order_pkt3));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg == NULL);

    // C2S Data Packet 3333
    printf("\n=> Packet Parse: TCP C2S Data packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_out_of_order_pkt4, sizeof(tcp_out_of_order_pkt4));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 4) == 0);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg == NULL);

    // C2S Data Packet 4444
    printf("\n=> Packet Parse: TCP C2S Data packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_out_of_order_pkt5, sizeof(tcp_out_of_order_pkt5));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 5) == 0);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg == NULL);

    // C2S Data Packet 5555
    printf("\n=> Packet Parse: TCP C2S Data packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_out_of_order_pkt6, sizeof(tcp_out_of_order_pkt6));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 6) == 0);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg == NULL);

    // C2S Data Packet 1111
    printf("\n=> Packet Parse: TCP C2S Data packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_out_of_order_pkt7, sizeof(tcp_out_of_order_pkt7));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 7) == 0);

    /*
     * 11111111111111111111111111111111111111111111111111111111111111
     * 22222222222222222222222222222222222222222222222222222222222222
     * 33333333333333333333333333333333333333333333333333333333333333
     * 44444444444444444444444444444444444444444444444444444444444444
     * 55555555555555555555555555555555555555555555555555555555555555
     */

    unsigned char payload1[] = {
        0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31,
        0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31,
        0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x31, 0x0a};
    unsigned char payload2[] = {
        0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32,
        0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32,
        0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x32, 0x0a};
    unsigned char payload3[] = {
        0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33,
        0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33,
        0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x33, 0x0a};
    unsigned char payload4[] = {
        0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34,
        0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34,
        0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x34, 0x0a};
    unsigned char payload5[] = {
        0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35,
        0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35,
        0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x35, 0x0a};

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg != NULL);
    EXPECT_TRUE(seg->len == sizeof(payload1));
    EXPECT_TRUE(memcmp((void *)seg->data, payload1, sizeof(payload1)) == 0);
    hexdump_to_fd(STDOUT_FILENO, 0, (const char *)seg->data, seg->len);
    session_free_tcp_segment(sess, seg);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg != NULL);
    EXPECT_TRUE(seg->len == sizeof(payload2));
    EXPECT_TRUE(memcmp((void *)seg->data, payload2, sizeof(payload2)) == 0);
    hexdump_to_fd(STDOUT_FILENO, 0, (const char *)seg->data, seg->len);
    session_free_tcp_segment(sess, seg);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg != NULL);
    EXPECT_TRUE(seg->len == sizeof(payload3));
    EXPECT_TRUE(memcmp((void *)seg->data, payload3, sizeof(payload3)) == 0);
    hexdump_to_fd(STDOUT_FILENO, 0, (const char *)seg->data, seg->len);
    session_free_tcp_segment(sess, seg);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg != NULL);
    EXPECT_TRUE(seg->len == sizeof(payload4));
    EXPECT_TRUE(memcmp((void *)seg->data, payload4, sizeof(payload4)) == 0);
    hexdump_to_fd(STDOUT_FILENO, 0, (const char *)seg->data, seg->len);
    session_free_tcp_segment(sess, seg);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg != NULL);
    EXPECT_TRUE(seg->len == sizeof(payload5));
    EXPECT_TRUE(memcmp((void *)seg->data, payload5, sizeof(payload5)) == 0);
    hexdump_to_fd(STDOUT_FILENO, 0, (const char *)seg->data, seg->len);
    session_free_tcp_segment(sess, seg);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 7 + sess_mgr_cfg.tcp_timeout_ms.data) == NULL);                      // active -> closing
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 7 + sess_mgr_cfg.tcp_timeout_ms.data + sess_mgr_cfg.tcp_timeout_ms.data); // closing -> closed
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

#if 1
TEST(SESS_MGR_TCP_REASSEMBLY, SEQ_WRAPAROUND)
{
    struct tcp_segment *seg;
    struct packet pkt;
    struct session *sess = NULL;
    struct session_manager_rte *sess_mgr_rte = NULL;

    sess_mgr_rte = session_manager_rte_new(&sess_mgr_cfg, 1);
    EXPECT_TRUE(sess_mgr_rte != NULL);

    // C2S SYN Packet
    printf("\n=> Packet Parse: TCP C2S SYN packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_seq_wraparound_pkt1, sizeof(tcp_seq_wraparound_pkt1));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    EXPECT_TRUE(session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt) == NULL);

    // new session
    sess = session_manager_rte_new_session(sess_mgr_rte, &pkt, 1);
    EXPECT_TRUE(sess);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg == NULL);

    // C2S ACK Packet
    printf("\n=> Packet Parse: TCP C2S ACK packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_seq_wraparound_pkt2, sizeof(tcp_seq_wraparound_pkt2));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 2) == 0);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg == NULL);

    // C2S Data Packet
    printf("\n=> Packet Parse: TCP C2S Data packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_seq_wraparound_pkt3, sizeof(tcp_seq_wraparound_pkt3));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 3) == 0);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg != NULL);
    EXPECT_TRUE(seg->len == sizeof(tcp_seq_wraparound_pkt3_payload));
    EXPECT_TRUE(memcmp((void *)seg->data, tcp_seq_wraparound_pkt3_payload, sizeof(tcp_seq_wraparound_pkt3_payload)) == 0);
    hexdump_to_fd(STDOUT_FILENO, 0, (const char *)seg->data, seg->len);
    session_free_tcp_segment(sess, seg);

    // C2S Data Packet
    printf("\n=> Packet Parse: TCP C2S Data packet\n");
    memset(&pkt, 0, sizeof(pkt));
    packet_parse(&pkt, (const char *)tcp_seq_wraparound_pkt4, sizeof(tcp_seq_wraparound_pkt4));
    printf("<= Packet Parse: done\n\n");

    // lookup session
    sess = session_manager_rte_lookup_session_by_packet(sess_mgr_rte, &pkt);
    EXPECT_TRUE(sess);

    // update session
    EXPECT_TRUE(session_manager_rte_update_session(sess_mgr_rte, sess, &pkt, 4) == 0);

    seg = session_get_tcp_segment(sess);
    EXPECT_TRUE(seg != NULL);
    EXPECT_TRUE(seg->len == sizeof(tcp_seq_wraparound_pkt4_payload));
    EXPECT_TRUE(memcmp((void *)seg->data, tcp_seq_wraparound_pkt4_payload, sizeof(tcp_seq_wraparound_pkt4_payload)) == 0);
    hexdump_to_fd(STDOUT_FILENO, 0, (const char *)seg->data, seg->len);
    session_free_tcp_segment(sess, seg);

    // expire session
    EXPECT_TRUE(session_manager_rte_get_expired_session(sess_mgr_rte, 4 + sess_mgr_cfg.tcp_timeout_ms.data) == NULL);                      // active -> closing
    sess = session_manager_rte_get_expired_session(sess_mgr_rte, 4 + sess_mgr_cfg.tcp_timeout_ms.data + sess_mgr_cfg.tcp_timeout_ms.data); // closing -> closed
    EXPECT_TRUE(sess);
    EXPECT_TRUE(session_get_current_state(sess) == SESSION_STATE_CLOSED);
    EXPECT_TRUE(session_get_closing_reason(sess) == CLOSING_BY_TIMEOUT);
    session_print(sess);

    // free session
    session_manager_rte_free_session(sess_mgr_rte, sess);

    session_manager_rte_free(sess_mgr_rte);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}