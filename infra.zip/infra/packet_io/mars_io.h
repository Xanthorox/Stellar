#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "packet_io.h"

void *mars_io_new(const char *toml_file);
void mars_io_free(void *handle);
int mars_io_is_done(void *handle);

int mars_io_init(void *handle, uint16_t thr_idx);
int mars_io_recv(void *handle, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void mars_io_send(void *handle, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void mars_io_drop(void *handle, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void mars_io_yield(void *handle, uint16_t thr_idx);
void mars_io_polling(void *handle, uint16_t thr_idx);
struct packet_io_stat *mars_io_stat(void *handle, uint16_t thr_idx);

#ifdef __cplusplus
}
#endif
