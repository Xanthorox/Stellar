#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>

#include "log_internal.h"
#include "stellar/packet.h"

#define PACKET_IO_LOG_INFO(format, ...) STELLAR_LOG_INFO(__thread_local_logger, "packet IO", format, ##__VA_ARGS__)
#define PACKET_IO_LOG_ERROR(format, ...) STELLAR_LOG_ERROR(__thread_local_logger, "packet IO", format, ##__VA_ARGS__)
#define PACKET_IO_LOG_FATAL(format, ...) STELLAR_LOG_FATAL(__thread_local_logger, "packet IO", format, ##__VA_ARGS__)

struct packet_io_stat
{
    // device packet
    uint64_t pkts_rx;
    uint64_t bytes_rx;

    uint64_t pkts_tx;
    uint64_t bytes_tx;

    // keep-alive packet
    uint64_t keep_alive_pkts;
    uint64_t keep_alive_bytes;

    // drop packet
    uint64_t pkts_dropped;
    uint64_t bytes_dropped;

    // inject packet
    uint64_t pkts_injected;
    uint64_t bytes_injected;

    // user freed
    uint64_t pkts_user_freed;
    uint64_t bytes_user_freed;
} __attribute__((aligned(64)));

#define PKT_IO_STAT_MAP(XX)                            \
    XX(PKT_IO_STAT_PKTS_RX, pkts_rx)                   \
    XX(PKT_IO_STAT_BYTES_RX, bytes_rx)                 \
    XX(PKT_IO_STAT_PKTS_TX, pkts_tx)                   \
    XX(PKT_IO_STAT_BYTES_TX, bytes_tx)                 \
    XX(PKT_IO_STAT_KEEP_ALIVE_PKTS, keep_alive_pkts)   \
    XX(PKT_IO_STAT_KEEP_ALIVE_BYTES, keep_alive_bytes) \
    XX(PKT_IO_STAT_PKTS_DROPPED, pkts_dropped)         \
    XX(PKT_IO_STAT_BYTES_DROPPED, bytes_dropped)       \
    XX(PKT_IO_STAT_PKTS_INJECTED, pkts_injected)       \
    XX(PKT_IO_STAT_BYTES_INJECTED, bytes_injected)     \
    XX(PKT_IO_STAT_PKTS_USER_FREED, pkts_user_freed)   \
    XX(PKT_IO_STAT_BYTES_USER_FREED, bytes_user_freed)

enum pkt_io_stat_type
{
#define XX(type, name) type,
    PKT_IO_STAT_MAP(XX)
#undef XX
    PKT_IO_STAT_MAX
};

__attribute__((unused)) static const char pkt_io_stat_str[PKT_IO_STAT_MAX][64] =
{
#define XX(type, name) #name,
    PKT_IO_STAT_MAP(XX)
#undef XX
};

struct packet_io;
struct packet_io *packet_io_new(const char *toml_file);
void packet_io_free(struct packet_io *pkt_io);
// only used in pcap mode, to check if all pcap has been processed
int packet_io_is_done(struct packet_io *pkt_io);

int packet_io_init(struct packet_io *pkt_io, uint16_t thr_idx);
int packet_io_recv(struct packet_io *pkt_io, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void packet_io_send(struct packet_io *pkt_io, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void packet_io_drop(struct packet_io *pkt_io, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void packet_io_yield(struct packet_io *pkt_io, uint16_t thr_idx);
void packet_io_clean(struct packet_io *pkt_io, uint16_t thr_idx);

uint64_t packet_io_stat_get(struct packet_io_stat *stat, enum pkt_io_stat_type type);

#ifdef __cplusplus
}
#endif
