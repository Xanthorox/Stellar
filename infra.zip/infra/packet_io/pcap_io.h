#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "packet_io.h"

void *pcap_io_new(const char *toml_file);
void pcap_io_free(void *handle);
int pcap_io_is_done(void *handle);

int pcap_io_init(void *handle, uint16_t thr_idx);
int pcap_io_recv(void *handle, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void pcap_io_send(void *handle, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void pcap_io_drop(void *handle, uint16_t thr_idx, struct packet *pkts[], int nr_pkts);
void pcap_io_yield(void *handle, uint16_t thr_idx);
void pcap_io_polling(void *handle, uint16_t thr_idx);
struct packet_io_stat *pcap_io_stat(void *handle, uint16_t thr_idx);

#ifdef __cplusplus
}
#endif
