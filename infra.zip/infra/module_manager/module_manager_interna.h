#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/module.h"

#include <limits.h>
#include <stdbool.h>

struct module
{
	char name[NAME_MAX];
	void *ctx;
};

struct module_descriptor
{
    struct module_hooks hooks;
	struct module *mod;
    bool initialized;
}__attribute__((aligned(sizeof(void*))));


struct polling_node
{
    on_polling_callback *on_polling;
    void *polling_arg;
    struct polling_node *next;
};

struct module_manager
{
    struct module_descriptor *descriptors;
    int n_descriptor;
    struct polling_node *node_list;
    struct
    {
        char *toml_path;
        int max_thread_num;
        struct logger *logger;
    }config;
    
}__attribute__((aligned(sizeof(void*))));



#ifdef __cplusplus
}
#endif