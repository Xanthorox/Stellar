#pragma GCC diagnostic ignored "-Wunused-parameter"

#include <gtest/gtest.h>


#include "module_manager/module_manager_interna.h"

#include <unistd.h>
#include <stdlib.h>


/***********************************
 * TEST MODUEL MANAGER INTERNAL API *
 ***********************************/

extern "C" struct module *gtest_mock_init(struct module_manager *mod_mgr){return NULL;}
extern "C" void gtest_mock_exit(struct module_manager *mod_mgr, struct module *mod){}
const char *gtest_mock_spec_toml = 
    "[[module]]\n"
    "path = \"\"\n"
    "init = \"gtest_mock_init\"\n"
    "exit = \"gtest_mock_exit\"\n";

TEST(module_manager_internal, stellar_module_manager_new_with_toml) {


	char toml_template[] = "./stellar.toml.XXXXXX";
	int fd = mkstemp(toml_template); 
	EXPECT_TRUE(fd>=0);
	write(fd, gtest_mock_spec_toml, strlen(gtest_mock_spec_toml));
	close(fd);

	struct module_manager *mod_mgr=module_manager_new_with_toml(toml_template, 10, NULL);
	
	EXPECT_TRUE(mod_mgr!=NULL);
	EXPECT_TRUE(module_manager_get_module(mod_mgr, "test")==NULL);
	EXPECT_EQ(module_manager_get_max_thread_num(mod_mgr), 10);
	EXPECT_STREQ(module_manager_get_toml_path(mod_mgr), toml_template);

	EXPECT_EQ(module_manager_get_thread_id(mod_mgr), -1);// no thread registered

	module_manager_free(mod_mgr);	

	unlink(toml_template); 
}

/***********************************
 * TEST STELLAR MODULE API *
 ***********************************/

TEST(stellar_module, basic_new_and_free) {

	struct module *mod = module_new("test", NULL);
	EXPECT_TRUE(mod!=NULL);

	module_set_name(mod, "test1");
	EXPECT_STREQ(module_get_name(mod), "test1");

	module_set_ctx(mod, (void*)1);
	EXPECT_EQ((long)module_get_ctx(mod), 1);	

	module_free(mod);
}

/***********************************
 * TEST MODULE MANAGER API *
 ***********************************/

TEST(stellar_module_manager, new_with_null_toml) {

	struct module_manager *mod_mgr = module_manager_new_with_toml(NULL, 10, NULL);
	EXPECT_TRUE(mod_mgr!=NULL);
	EXPECT_TRUE(module_manager_get_module(mod_mgr, "test")==NULL);
	EXPECT_EQ(module_manager_get_max_thread_num(mod_mgr), 10);

	EXPECT_EQ(module_manager_get_thread_id(mod_mgr), -1);// no thread registered

	module_manager_free(mod_mgr);
}

TEST(stellar_module_manager, new_with_empty_toml) {

	struct module_manager *mod_mgr = module_manager_new_with_toml("/dev/null", 10,  NULL);
	EXPECT_TRUE(mod_mgr!=NULL);
	EXPECT_TRUE(module_manager_get_module(mod_mgr, "test")==NULL);
	EXPECT_EQ(module_manager_get_max_thread_num(mod_mgr), 10);

	EXPECT_EQ(module_manager_get_thread_id(mod_mgr), -1);// no thread registered

	module_manager_free(mod_mgr);
}

TEST(stellar_module_manager, register_thread) {

	struct module_manager *mod_mgr=module_manager_new_with_toml(NULL, 10,  NULL);

	EXPECT_TRUE(mod_mgr!=NULL);


	EXPECT_EQ(module_manager_get_thread_id(mod_mgr), -1);// no thread registered

	module_manager_register_thread(mod_mgr, 1);
	
	EXPECT_EQ(module_manager_get_thread_id(mod_mgr), 1);

	module_manager_unregister_thread(mod_mgr, 1);

	EXPECT_EQ(module_manager_get_thread_id(mod_mgr), -1);

	module_manager_free(mod_mgr);	

}

/***********************************
 * TEST MODULE MANAGER API *
 ***********************************/

extern "C" struct module *gtest_module_init(struct module_manager *mod_mgr)
{
	struct module *mod = module_new("gtest", NULL);
	EXPECT_STREQ(module_get_name(mod), "gtest");
	module_set_ctx(mod, (void*)1);

	return mod;
}

extern "C" void gtest_module_exit(struct module_manager *mod_mgr, struct module *mod)
{
	EXPECT_STREQ(module_get_name(mod), "gtest");
	EXPECT_EQ((long)module_get_ctx(mod), 1);

	EXPECT_EQ(module_manager_get_module(mod_mgr, "gtest"), mod);

	EXPECT_EQ(module_manager_get_thread_id(mod_mgr), -1);

	module_free(mod);
}

extern "C" void gtest_thread_init(struct module_manager *mod_mgr, int thread_id, struct module *mod)
{
	EXPECT_STREQ(module_get_name(mod), "gtest");
	EXPECT_EQ((long)module_get_ctx(mod), 1);
}

extern "C" void gtest_thread_exit(struct module_manager *mod_mgr, int thread_id, struct module *mod)
{
	EXPECT_STREQ(module_get_name(mod), "gtest");
	EXPECT_EQ((long)module_get_ctx(mod), 1);
}

const char *gtest_module_spec_toml = 
    "[[module]]\n"
    "path = \"\"\n"
    "init = \"gtest_module_init\"\n"
    "exit = \"gtest_module_exit\"\n"
	"thread_init = \"gtest_thread_init\"\n"
    "thread_exit = \"gtest_thread_exit\"\n";

TEST(module_manager, basic_module) {


	char toml_template[] = "./stellar.toml.XXXXXX";
	int fd = mkstemp(toml_template); 
	EXPECT_TRUE(fd>=0);
	write(fd, gtest_module_spec_toml, strlen(gtest_module_spec_toml));
	close(fd);

	struct module_manager *mod_mgr=module_manager_new_with_toml(toml_template, 10, NULL);
	EXPECT_TRUE(mod_mgr!=NULL);

	EXPECT_TRUE(module_manager_get_module(mod_mgr, "gtest")!=NULL);

	EXPECT_EQ(module_manager_get_max_thread_num(mod_mgr), 10);
	EXPECT_STREQ(module_manager_get_toml_path(mod_mgr), toml_template);
	
	module_manager_register_thread(mod_mgr, 1);
	
	EXPECT_EQ((long)module_manager_get_thread_id(mod_mgr), 1);

	module_manager_unregister_thread(mod_mgr, 1);
	EXPECT_EQ((long)module_manager_get_thread_id(mod_mgr), -1);

	module_manager_free(mod_mgr);	
	unlink(toml_template);
}

/***********************************
 * TEST POLLING MANAGER POLLING API *
 ***********************************/

struct test_module_polling_env
{
	int N_round;
	int polling_count;
	int polling_active_count;
};

 void test_module_on_polling(struct module_manager* mod_mgr, void *polling_arg)
 {
	struct test_module_polling_env *env = (struct test_module_polling_env*)polling_arg;
	env->polling_count++;
	if(env->polling_count%2==0)
	{
		//module_manager_polling_active(mod_mgr);
		//env->polling_active_count++;
	}
 }


TEST(module_manager, basic_polling_module) {

	struct module_manager *mod_mgr=module_manager_new_with_toml(NULL, 10,  NULL);
	EXPECT_TRUE(mod_mgr!=NULL);


	EXPECT_EQ(module_manager_get_max_thread_num(mod_mgr), 10);

	struct test_module_polling_env env={};
	env.N_round=10;

	module_manager_register_polling_node(mod_mgr, test_module_on_polling, &env);

	module_manager_register_thread(mod_mgr, 1);
	
	EXPECT_EQ((long)module_manager_get_thread_id(mod_mgr), 1);

	for(int i=0; i<env.N_round; i++)
	{
		module_manager_polling_dispatch(mod_mgr);
	}

	module_manager_unregister_thread(mod_mgr, 1);

	module_manager_free(mod_mgr);	
	
	EXPECT_EQ(env.polling_count, env.N_round+env.polling_active_count);


}

/**********************************************
 * GTEST MAIN *
 **********************************************/

int main(int argc, char ** argv)
{
	int ret=0;
	::testing::InitGoogleTest(&argc, argv);
	ret=RUN_ALL_TESTS();
	return ret;
}