#include <stdio.h>
#include <stddef.h>
#include <signal.h>
#include <stdlib.h>

#include "stellar/log.h"
#include "stellar/stellar.h"

struct stellar *st = NULL;
static void signal_handler(int signo)
{
    struct logger *logger = stellar_get_logger(st);

    if (signo == SIGINT)
    {
        STELLAR_LOG_FATAL(logger, "signal", "SIGINT received, force exit");
        exit(0);
    }

    if (signo == SIGSTOP)
    {
        STELLAR_LOG_FATAL(logger, "signal", "SIGSTOP received, notify threads graceful exit");
        stellar_loopbreak(st);
    }

    if (signo == SIGHUP)
    {
        STELLAR_LOG_FATAL(logger, "signal", "SIGHUP received, reload log level");
        stellar_reload_log_level(st);
    }
}

int main(int argc __attribute__((__unused__)), char **argv __attribute__((__unused__)))
{
    signal(SIGINT, signal_handler);
    signal(SIGQUIT, signal_handler);
    signal(SIGTERM, signal_handler);
    signal(SIGHUP, signal_handler);

    st = stellar_new("./conf/stellar.toml");
    if (st == NULL)
    {
        return 0;
    }

    stellar_run(st);

    stellar_free(st);

    return 0;
}