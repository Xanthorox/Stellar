#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>

struct ip_reassembly_stat
{
    // IPv4 frag stat
    uint64_t ip4_defrags_expected;
    uint64_t ip4_defrags_succeed;
    uint64_t ip4_defrags_failed;

    uint64_t ip4_frags;
    uint64_t ip4_frags_freed;
    uint64_t ip4_frags_buffered;
    uint64_t ip4_frags_no_buffer;
    uint64_t ip4_frags_timeout;
    uint64_t ip4_frags_invalid_length;
    uint64_t ip4_frags_overlap;
    uint64_t ip4_frags_too_many;

    // IPv6 frag stat
    uint64_t ip6_defrags_expected;
    uint64_t ip6_defrags_succeed;
    uint64_t ip6_defrags_failed;

    uint64_t ip6_frags;
    uint64_t ip6_frags_freed;
    uint64_t ip6_frags_buffered;
    uint64_t ip6_frags_no_buffer;
    uint64_t ip6_frags_timeout;
    uint64_t ip6_frags_invalid_length;
    uint64_t ip6_frags_overlap;
    uint64_t ip6_frags_too_many;
} __attribute__((aligned(64)));

#define IP_REASS_STAT_MAP(XX)                                            \
    XX(IP_REASS_STAT_IP4_DEFRAGS_EXPECTED, ip4_defrags_expected)         \
    XX(IP_REASS_STAT_IP4_DEFRAGS_SUCCEED, ip4_defrags_succeed)           \
    XX(IP_REASS_STAT_IP4_DEFRAGS_FAILED, ip4_defrags_failed)             \
    XX(IP_REASS_STAT_IP4_FRAGS, ip4_frags)                               \
    XX(IP_REASS_STAT_IP4_FRAGS_FREED, ip4_frags_freed)                   \
    XX(IP_REASS_STAT_IP4_FRAGS_BUFFERED, ip4_frags_buffered)             \
    XX(IP_REASS_STAT_IP4_FRAGS_NO_BUFFER, ip4_frags_no_buffer)           \
    XX(IP_REASS_STAT_IP4_FRAGS_TIMEOUT, ip4_frags_timeout)               \
    XX(IP_REASS_STAT_IP4_FRAGS_INVALID_LENGTH, ip4_frags_invalid_length) \
    XX(IP_REASS_STAT_IP4_FRAGS_OVERLAP, ip4_frags_overlap)               \
    XX(IP_REASS_STAT_IP4_FRAGS_TOO_MANY, ip4_frags_too_many)             \
    XX(IP_REASS_STAT_IP6_DEFRAGS_EXPECTED, ip6_defrags_expected)         \
    XX(IP_REASS_STAT_IP6_DEFRAGS_SUCCEED, ip6_defrags_succeed)           \
    XX(IP_REASS_STAT_IP6_DEFRAGS_FAILED, ip6_defrags_failed)             \
    XX(IP_REASS_STAT_IP6_FRAGS, ip6_frags)                               \
    XX(IP_REASS_STAT_IP6_FRAGS_FREED, ip6_frags_freed)                   \
    XX(IP_REASS_STAT_IP6_FRAGS_BUFFERED, ip6_frags_buffered)             \
    XX(IP_REASS_STAT_IP6_FRAGS_NO_BUFFER, ip6_frags_no_buffer)           \
    XX(IP_REASS_STAT_IP6_FRRAGS_TIMEOUT, ip6_frags_timeout)              \
    XX(IP_REASS_STAT_IP6_FRAGS_INVALID_LENGTH, ip6_frags_invalid_length) \
    XX(IP_REASS_STAT_IP6_FRAGS_OVERLAP, ip6_frags_overlap)               \
    XX(IP_REASS_STAT_IP6_FRAGS_TOO_MANY, ip6_frags_too_many)

enum ip_reass_stat_type
{
#define XX(type, name) type,
    IP_REASS_STAT_MAP(XX)
#undef XX
    IP_REASS_STAT_MAX
};

__attribute__((unused)) static const char ip_reass_stat_str[IP_REASS_STAT_MAX][64] =
{
#define XX(type, name) #name,
    IP_REASS_STAT_MAP(XX)
#undef XX
};

struct ip_reassembly *ip_reassembly_new(uint64_t timeout_ms, uint64_t frag_queue_num, uint64_t frag_queue_size);
void ip_reassembly_free(struct ip_reassembly *ip_reass);

struct packet *ip_reassembly_defrag(struct ip_reassembly *ip_reass, struct packet *pkt, uint64_t now);
struct packet *ip_reassembly_clean(struct ip_reassembly *ip_reass, uint64_t now_ms);

struct ip_reassembly_stat *ip_reassembly_get_stat(struct ip_reassembly *ip_reass);
void ip_reassembly_print_stat(struct ip_reassembly *ip_reass);

uint64_t ip_reassembly_stat_get(struct ip_reassembly_stat *stat, enum ip_reass_stat_type type);

#ifdef __cplusplus
}
#endif
