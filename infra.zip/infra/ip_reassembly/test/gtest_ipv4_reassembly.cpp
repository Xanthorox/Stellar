#include <gtest/gtest.h>

#include "packet_parser.h"
#include "packet_helper.h"
#include "packet_internal.h"
#include "ip_reassembly.h"

static inline void packet_overwrite_v4_saddr(struct packet *pkt, uint32_t saddr)
{
    const struct layer_internal *ipv4_layer = packet_get_innermost_layer(pkt, LAYER_PROTO_IPV4);
    EXPECT_TRUE(ipv4_layer);
    struct ip *hdr = (struct ip *)ipv4_layer->hdr_ptr;
    ip4_hdr_set_src_addr(hdr, saddr);
}

static inline void stat_cmp(struct ip_reassembly_stat *curr, struct ip_reassembly_stat *expect)
{
    EXPECT_TRUE(curr != NULL);
    EXPECT_TRUE(expect != NULL);

    EXPECT_TRUE(curr->ip4_defrags_expected == expect->ip4_defrags_expected);
    EXPECT_TRUE(curr->ip4_defrags_succeed == expect->ip4_defrags_succeed);
    EXPECT_TRUE(curr->ip4_defrags_failed == expect->ip4_defrags_failed);

    EXPECT_TRUE(curr->ip4_frags == expect->ip4_frags);
    EXPECT_TRUE(curr->ip4_frags_freed == expect->ip4_frags_freed);
    EXPECT_TRUE(curr->ip4_frags_buffered == expect->ip4_frags_buffered);
    EXPECT_TRUE(curr->ip4_frags_no_buffer == expect->ip4_frags_no_buffer);
    EXPECT_TRUE(curr->ip4_frags_timeout == expect->ip4_frags_timeout);
    EXPECT_TRUE(curr->ip4_frags_invalid_length == expect->ip4_frags_invalid_length);
    EXPECT_TRUE(curr->ip4_frags_overlap == expect->ip4_frags_overlap);
    EXPECT_TRUE(curr->ip4_frags_too_many == expect->ip4_frags_too_many);

    EXPECT_TRUE(curr->ip6_defrags_expected == expect->ip6_defrags_expected);
    EXPECT_TRUE(curr->ip6_defrags_succeed == expect->ip6_defrags_succeed);
    EXPECT_TRUE(curr->ip6_defrags_failed == expect->ip6_defrags_failed);

    EXPECT_TRUE(curr->ip6_frags == expect->ip6_frags);
    EXPECT_TRUE(curr->ip6_frags_freed == expect->ip6_frags_freed);
    EXPECT_TRUE(curr->ip6_frags_buffered == expect->ip6_frags_buffered);
    EXPECT_TRUE(curr->ip6_frags_no_buffer == expect->ip6_frags_no_buffer);
    EXPECT_TRUE(curr->ip6_frags_timeout == expect->ip6_frags_timeout);
    EXPECT_TRUE(curr->ip6_frags_invalid_length == expect->ip6_frags_invalid_length);
    EXPECT_TRUE(curr->ip6_frags_overlap == expect->ip6_frags_overlap);
    EXPECT_TRUE(curr->ip6_frags_too_many == expect->ip6_frags_too_many);
}

/*
 * Frame 4: 60 bytes on wire (480 bits), 60 bytes captured (480 bits)
 * Ethernet II, Src: Fortinet_cc:87:22 (e8:1c:ba:cc:87:22), Dst: EvocInte_2f:35:b8 (00:22:46:2f:35:b8)
 *     Destination: EvocInte_2f:35:b8 (00:22:46:2f:35:b8)
 *         Address: EvocInte_2f:35:b8 (00:22:46:2f:35:b8)
 *         .... ..0. .... .... .... .... = LG bit: Globally unique address (factory default)
 *         .... ...0 .... .... .... .... = IG bit: Individual address (unicast)
 *     Source: Fortinet_cc:87:22 (e8:1c:ba:cc:87:22)
 *         Address: Fortinet_cc:87:22 (e8:1c:ba:cc:87:22)
 *         .... ..0. .... .... .... .... = LG bit: Globally unique address (factory default)
 *         .... ...0 .... .... .... .... = IG bit: Individual address (unicast)
 *     Type: IPv4 (0x0800)
 *     Padding: 0000
 * Internet Protocol Version 4, Src: 192.168.36.103, Dst: 192.168.40.137
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 44
 *     Identification: 0xffff (65535)
 *     001. .... = Flags: 0x1, More fragments
 *         0... .... = Reserved bit: Not set
 *         .0.. .... = Don't fragment: Not set
 *         ..1. .... = More fragments: Set
 *     ...0 0000 0000 0000 = Fragment Offset: 0
 *     Time to Live: 127
 *     Protocol: TCP (6)
 *     Header Checksum: 0x4d8b [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0x4d8b]
 *     Source Address: 192.168.36.103
 *     Destination Address: 192.168.40.137
 *     [Reassembled IPv4 in frame: 5]
 * Data (24 bytes)
 *     Data: f4a5270f9107248703d518e75018ff005e9200003132330a
 *     [Length: 24]
 */

unsigned char frag1[] = {
    /* ETH */
    0x00, 0x22, 0x46, 0x2f, 0x35, 0xb8, 0xe8, 0x1c, 0xba, 0xcc, 0x87, 0x22, 0x08, 0x00,
    /* IP */
    0x45, 0x00,             // version & hdr len & tos
    0x00, 0x2c,             // total length
    0xff, 0xff,             // ip id
    0x20, 0x00,             // flags & frag offset
    0x7f, 0x06,             // ttl & protocol
    0x4d, 0x8b,             // checksum
    0xc0, 0xa8, 0x24, 0x67, // src addr
    0xc0, 0xa8, 0x28, 0x89, // dst addr
    /* TCP */
    0xf4, 0xa5,             // src port
    0x27, 0x0f,             // dst port
    0x91, 0x07, 0x24, 0x87, // seq
    0x03, 0xd5, 0x18, 0xe7, // ack
    0x50, 0x18,             // data offset & flags
    0xff, 0x00,             // windows
    0x5e, 0x92,             // checksum
    0x00, 0x00,             // urgent pointer
    /* DATA */
    0x31, 0x32, 0x33, 0x0a,
    /* Padding */
    0x00, 0x00};

/*
 * Frame 5: 60 bytes on wire (480 bits), 60 bytes captured (480 bits)
 * Ethernet II, Src: Fortinet_cc:87:22 (e8:1c:ba:cc:87:22), Dst: EvocInte_2f:35:b8 (00:22:46:2f:35:b8)
 *     Destination: EvocInte_2f:35:b8 (00:22:46:2f:35:b8)
 *         Address: EvocInte_2f:35:b8 (00:22:46:2f:35:b8)
 *         .... ..0. .... .... .... .... = LG bit: Globally unique address (factory default)
 *         .... ...0 .... .... .... .... = IG bit: Individual address (unicast)
 *     Source: Fortinet_cc:87:22 (e8:1c:ba:cc:87:22)
 *         Address: Fortinet_cc:87:22 (e8:1c:ba:cc:87:22)
 *         .... ..0. .... .... .... .... = LG bit: Globally unique address (factory default)
 *         .... ...0 .... .... .... .... = IG bit: Individual address (unicast)
 *     Type: IPv4 (0x0800)
 *     Padding: 0000
 * Internet Protocol Version 4, Src: 192.168.36.103, Dst: 192.168.40.137
 *     0100 .... = Version: 4
 *     .... 0101 = Header Length: 20 bytes (5)
 *     Differentiated Services Field: 0x00 (DSCP: CS0, ECN: Not-ECT)
 *         0000 00.. = Differentiated Services Codepoint: Default (0)
 *         .... ..00 = Explicit Congestion Notification: Not ECN-Capable Transport (0)
 *     Total Length: 44
 *     Identification: 0xffff (65535)
 *     000. .... = Flags: 0x0
 *         0... .... = Reserved bit: Not set
 *         .0.. .... = Don't fragment: Not set
 *         ..0. .... = More fragments: Not set
 *     ...0 0000 0000 0011 = Fragment Offset: 24
 *     Time to Live: 127
 *     Protocol: TCP (6)
 *     Header Checksum: 0x6d88 [correct]
 *     [Header checksum status: Good]
 *     [Calculated Checksum: 0x6d88]
 *     Source Address: 192.168.36.103
 *     Destination Address: 192.168.40.137
 *     [2 IPv4 Fragments (48 bytes): #4(24), #5(24)]
 *         [Frame: 4, payload: 0-23 (24 bytes)]
 *         [Frame: 5, payload: 24-47 (24 bytes)]
 *         [Fragment count: 2]
 *         [Reassembled IPv4 length: 48]
 *         [Reassembled IPv4 data: f4a5270f9107248703d518e75018ff005e9200003132330af4a5270f9107248b03d518e7…]
 * Transmission Control Protocol, Src Port: 62629, Dst Port: 9999, Seq: 1, Ack: 1, Len: 28
 *     Source Port: 62629
 *     Destination Port: 9999
 *     [Stream index: 0]
 *     [Conversation completeness: Complete, WITH_DATA (31)]
 *     [TCP Segment Len: 28]
 *     Sequence Number: 1    (relative sequence number)
 *     Sequence Number (raw): 2433164423
 *     [Next Sequence Number: 29    (relative sequence number)]
 *     Acknowledgment Number: 1    (relative ack number)
 *     Acknowledgment number (raw): 64297191
 *     0101 .... = Header Length: 20 bytes (5)
 *     Flags: 0x018 (PSH, ACK)
 *         000. .... .... = Reserved: Not set
 *         ...0 .... .... = Accurate ECN: Not set
 *         .... 0... .... = Congestion Window Reduced: Not set
 *         .... .0.. .... = ECN-Echo: Not set
 *         .... ..0. .... = Urgent: Not set
 *         .... ...1 .... = Acknowledgment: Set
 *         .... .... 1... = Push: Set
 *         .... .... .0.. = Reset: Not set
 *         .... .... ..0. = Syn: Not set
 *         .... .... ...0 = Fin: Not set
 *         [TCP Flags: ·······AP···]
 *     Window: 65280
 *     [Calculated window size: 65280]
 *     [Window size scaling factor: -2 (no window scaling used)]
 *     Checksum: 0x5e92 [correct]
 *     [Checksum Status: Good]
 *     [Calculated Checksum: 0x5e92]
 *     Urgent Pointer: 0
 *     [Timestamps]
 *         [Time since first frame in this TCP stream: 6.525912000 seconds]
 *         [Time since previous frame in this TCP stream: 6.525083000 seconds]
 *     [SEQ/ACK analysis]
 *         [iRTT: 0.000829000 seconds]
 *         [Bytes in flight: 28]
 *         [Bytes sent since last PSH flag: 28]
 *     TCP payload (28 bytes)
 * Data (28 bytes)
 *     Data: 3132330af4a5270f9107248b03d518e75018ff00301600006162630a
 *     [Length: 28]
 */

unsigned char frag2[] = {
    /* ETH */
    0x00, 0x22, 0x46, 0x2f, 0x35, 0xb8, 0xe8, 0x1c, 0xba, 0xcc, 0x87, 0x22, 0x08, 0x00,
    /* IP */
    0x45, 0x00,             // version & hdr len & tos
    0x00, 0x2c,             // total length
    0xff, 0xff,             // ip id
    0x00, 0x03,             // flags & frag offset
    0x7f, 0x06,             // ttl & protocol
    0x6d, 0x88,             // checksum
    0xc0, 0xa8, 0x24, 0x67, // src addr
    0xc0, 0xa8, 0x28, 0x89, // dst addr
    /* DATA */
    0xf4, 0xa5, 0x27, 0x0f, 0x91, 0x07, 0x24, 0x8b, 0x03, 0xd5, 0x18, 0xe7, 0x50, 0x18, 0xff, 0x00, 0x30, 0x16, 0x00, 0x00, 0x61, 0x62, 0x63, 0x0a,
    /* Padding */
    0x00, 0x00};

unsigned char expect[] = {
    /* ETH */
    0x00, 0x22, 0x46, 0x2f, 0x35, 0xb8, 0xe8, 0x1c, 0xba, 0xcc, 0x87, 0x22, 0x08, 0x00,
    /* IP */
    0x45, 0x00,             // version & hdr len & tos
    0x00, 0x44,             // total length         --------- need update ---------
    0xff, 0xff,             // ip id
    0x00, 0x00,             // flags & frag offset  --------- need update ---------
    0x7f, 0x06,             // ttl & protocol
    0x6d, 0x73,             // checksum             --------- need update ---------
    0xc0, 0xa8, 0x24, 0x67, // src addr
    0xc0, 0xa8, 0x28, 0x89, // dst addr
    /* TCP */
    0xf4, 0xa5,             // src port
    0x27, 0x0f,             // dst port
    0x91, 0x07, 0x24, 0x87, // seq
    0x03, 0xd5, 0x18, 0xe7, // ack
    0x50, 0x18,             // data offset & flags
    0xff, 0x00,             // windows
    0x5e, 0x92,             // checksum
    0x00, 0x00,             // urgent pointer
    /* DATA */
    0x31, 0x32, 0x33, 0x0a,                                                                                                                        // data from frag1
    0xf4, 0xa5, 0x27, 0x0f, 0x91, 0x07, 0x24, 0x8b, 0x03, 0xd5, 0x18, 0xe7, 0x50, 0x18, 0xff, 0x00, 0x30, 0x16, 0x00, 0x00, 0x61, 0x62, 0x63, 0x0a // data from frag2
};

#if 1
TEST(IPV4_REASSEMBLE, PADDING_ORDER)
{
    struct packet frag_pkt1 = {};
    struct packet frag_pkt2 = {};
    struct packet *frag_pkt = NULL;
    struct packet *defrag_pkt = NULL;
    const struct layer_internal *layer;
    struct ip_reassembly *ip_reass;
    struct ip_reassembly_stat *curr_stat;
    struct ip_reassembly_stat expect_stat;

    ip_reass = ip_reassembly_new(1, 1024, 64);
    EXPECT_TRUE(ip_reass != NULL);
    curr_stat = ip_reassembly_get_stat(ip_reass);
    EXPECT_TRUE(curr_stat != NULL);
    expect_stat = {
        0, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag1
    packet_parse(&frag_pkt1, (const char *)frag1, sizeof(frag1));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt1, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        1, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        1, 0, 1, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag2
    packet_parse(&frag_pkt2, (const char *)frag2, sizeof(frag2));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt2, 1);
    EXPECT_TRUE(defrag_pkt);
    expect_stat = {
        1, 1, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 2, 2, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // check packet
    EXPECT_TRUE(defrag_pkt->data_len == 14 /* ETH */ + 20 /* IPv4 */ + 20 /* TCP */ + 28 /* DATA */);
    EXPECT_TRUE(defrag_pkt->data_len == sizeof(expect));
    EXPECT_TRUE(memcmp(defrag_pkt->data_ptr, expect, defrag_pkt->data_len) == 0);

    // check IPv4
    layer = packet_get_innermost_layer(defrag_pkt, LAYER_PROTO_IPV4);
    EXPECT_TRUE(layer);
    struct ip *hdr = (struct ip *)layer->hdr_ptr;
    EXPECT_TRUE(ip4_hdr_get_version(hdr) == 4);
    EXPECT_TRUE(ip4_hdr_get_hdr_len(hdr) == 20 /* IPv4 */);
    EXPECT_TRUE(ip4_hdr_get_tos(hdr) == 0);
    EXPECT_TRUE(ip4_hdr_get_total_len(hdr) == 20 /* IPv4 */ + 20 /* TCP */ + 28 /* DATA */);
    EXPECT_TRUE(ip4_hdr_get_ipid(hdr) == 0xffff);
    EXPECT_TRUE(ip4_hdr_get_flags(hdr) == 0x0);
    EXPECT_TRUE(ip4_hdr_get_frag_offset(hdr) == 0);
    EXPECT_TRUE(ip4_hdr_get_ttl(hdr) == 127);
    EXPECT_TRUE(ip4_hdr_get_proto(hdr) == 6);
    EXPECT_TRUE(ip4_hdr_get_checksum(hdr) == 0x6d73); // NOTE this is correct checksum
    EXPECT_TRUE(ip4_hdr_get_src_addr(hdr) == 0xc0a82467);
    EXPECT_TRUE(ip4_hdr_get_dst_addr(hdr) == 0xc0a82889);
    EXPECT_TRUE(ip4_hdr_get_opt_len(hdr) == 0);
    EXPECT_TRUE(ip4_hdr_get_opt_data(hdr) == NULL);

    // check TCP
    layer = packet_get_innermost_layer(defrag_pkt, LAYER_PROTO_TCP);
    EXPECT_TRUE(layer);
    struct tcphdr *tcp_hdr = (struct tcphdr *)layer->hdr_ptr;
    EXPECT_TRUE(tcp_hdr_get_src_port(tcp_hdr) == 62629);
    EXPECT_TRUE(tcp_hdr_get_dst_port(tcp_hdr) == 9999);
    EXPECT_TRUE(tcp_hdr_get_seq(tcp_hdr) == 2433164423);
    EXPECT_TRUE(tcp_hdr_get_ack(tcp_hdr) == 64297191);
    EXPECT_TRUE(tcp_hdr_get_hdr_len(tcp_hdr) == 20);
    EXPECT_TRUE(tcp_hdr_get_flags(tcp_hdr) == 0x018);
    EXPECT_TRUE(tcp_hdr_get_window(tcp_hdr) == 65280);
    EXPECT_TRUE(tcp_hdr_get_checksum(tcp_hdr) == 0x5e92);
    EXPECT_TRUE(tcp_hdr_get_urg_ptr(tcp_hdr) == 0);
    EXPECT_TRUE(tcp_hdr_get_opt_len(tcp_hdr) == 0);
    EXPECT_TRUE(tcp_hdr_get_opt_data(tcp_hdr) == NULL);

    // free packet
    EXPECT_TRUE(packet_is_defraged(defrag_pkt));

    frag_pkt = packet_pop_frag(defrag_pkt);
    EXPECT_TRUE(frag_pkt);
    packet_free(frag_pkt);

    frag_pkt = packet_pop_frag(defrag_pkt);
    EXPECT_TRUE(frag_pkt);
    packet_free(frag_pkt);

    frag_pkt = packet_pop_frag(defrag_pkt);
    EXPECT_TRUE(frag_pkt == NULL);

    packet_free(defrag_pkt);

    EXPECT_TRUE(ip_reassembly_clean(ip_reass, 2) == NULL);
    expect_stat = {
        1, 1, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 2, 2, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    ip_reassembly_free(ip_reass);
}
#endif

#if 1
TEST(IPV4_REASSEMBLE, PADDING_UNORDER)
{
    struct packet frag_pkt1 = {};
    struct packet frag_pkt2 = {};
    struct packet *frag_pkt = NULL;
    struct packet *defrag_pkt = NULL;
    const struct layer_internal *layer;
    struct ip_reassembly *ip_reass;
    struct ip_reassembly_stat *curr_stat;
    struct ip_reassembly_stat expect_stat;

    ip_reass = ip_reassembly_new(1, 1024, 64);
    EXPECT_TRUE(ip_reass != NULL);
    curr_stat = ip_reassembly_get_stat(ip_reass);
    EXPECT_TRUE(curr_stat != NULL);
    expect_stat = {
        0, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag2
    packet_parse(&frag_pkt2, (const char *)frag2, sizeof(frag2));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt2, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        1, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        1, 0, 1, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag1
    packet_parse(&frag_pkt1, (const char *)frag1, sizeof(frag1));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt1, 1);
    EXPECT_TRUE(defrag_pkt);
    expect_stat = {
        1, 1, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 2, 2, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // check packet
    EXPECT_TRUE(defrag_pkt->data_len == 14 /* ETH */ + 20 /* IPv4 */ + 20 /* TCP */ + 28 /* DATA */);
    EXPECT_TRUE(defrag_pkt->data_len == sizeof(expect));
    EXPECT_TRUE(memcmp(defrag_pkt->data_ptr, expect, defrag_pkt->data_len) == 0);

    // check IPv4
    layer = packet_get_innermost_layer(defrag_pkt, LAYER_PROTO_IPV4);
    EXPECT_TRUE(layer);
    struct ip *hdr = (struct ip *)layer->hdr_ptr;
    EXPECT_TRUE(ip4_hdr_get_version(hdr) == 4);
    EXPECT_TRUE(ip4_hdr_get_hdr_len(hdr) == 20 /* IPv4 */);
    EXPECT_TRUE(ip4_hdr_get_tos(hdr) == 0);
    EXPECT_TRUE(ip4_hdr_get_total_len(hdr) == 20 /* IPv4 */ + 20 /* TCP */ + 28 /* DATA */);
    EXPECT_TRUE(ip4_hdr_get_ipid(hdr) == 0xffff);
    EXPECT_TRUE(ip4_hdr_get_flags(hdr) == 0x0);
    EXPECT_TRUE(ip4_hdr_get_frag_offset(hdr) == 0);
    EXPECT_TRUE(ip4_hdr_get_ttl(hdr) == 127);
    EXPECT_TRUE(ip4_hdr_get_proto(hdr) == 6);
    EXPECT_TRUE(ip4_hdr_get_checksum(hdr) == 0x6d73); // NOTE this is correct checksum
    EXPECT_TRUE(ip4_hdr_get_src_addr(hdr) == 0xc0a82467);
    EXPECT_TRUE(ip4_hdr_get_dst_addr(hdr) == 0xc0a82889);
    EXPECT_TRUE(ip4_hdr_get_opt_len(hdr) == 0);
    EXPECT_TRUE(ip4_hdr_get_opt_data(hdr) == NULL);

    // check TCP
    layer = packet_get_innermost_layer(defrag_pkt, LAYER_PROTO_TCP);
    EXPECT_TRUE(layer);
    struct tcphdr *tcp_hdr = (struct tcphdr *)layer->hdr_ptr;
    EXPECT_TRUE(tcp_hdr_get_src_port(tcp_hdr) == 62629);
    EXPECT_TRUE(tcp_hdr_get_dst_port(tcp_hdr) == 9999);
    EXPECT_TRUE(tcp_hdr_get_seq(tcp_hdr) == 2433164423);
    EXPECT_TRUE(tcp_hdr_get_ack(tcp_hdr) == 64297191);
    EXPECT_TRUE(tcp_hdr_get_hdr_len(tcp_hdr) == 20);
    EXPECT_TRUE(tcp_hdr_get_flags(tcp_hdr) == 0x018);
    EXPECT_TRUE(tcp_hdr_get_window(tcp_hdr) == 65280);
    EXPECT_TRUE(tcp_hdr_get_checksum(tcp_hdr) == 0x5e92);
    EXPECT_TRUE(tcp_hdr_get_urg_ptr(tcp_hdr) == 0);
    EXPECT_TRUE(tcp_hdr_get_opt_len(tcp_hdr) == 0);
    EXPECT_TRUE(tcp_hdr_get_opt_data(tcp_hdr) == NULL);

    // free packet
    EXPECT_TRUE(packet_is_defraged(defrag_pkt));

    frag_pkt = packet_pop_frag(defrag_pkt);
    EXPECT_TRUE(frag_pkt);
    packet_free(frag_pkt);

    frag_pkt = packet_pop_frag(defrag_pkt);
    EXPECT_TRUE(frag_pkt);
    packet_free(frag_pkt);

    frag_pkt = packet_pop_frag(defrag_pkt);
    EXPECT_TRUE(frag_pkt == NULL);

    packet_free(defrag_pkt);

    EXPECT_TRUE(ip_reassembly_clean(ip_reass, 2) == NULL);
    expect_stat = {
        1, 1, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 2, 2, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    ip_reassembly_free(ip_reass);
}
#endif

#if 1
TEST(IPV4_REASSEMBLE, EXPIRE)
{
    struct packet frag_pkt1 = {};
    struct packet *defrag_pkt = NULL;
    struct ip_reassembly *ip_reass;
    struct ip_reassembly_stat *curr_stat;
    struct ip_reassembly_stat expect_stat;

    ip_reass = ip_reassembly_new(1, 1024, 64);
    EXPECT_TRUE(ip_reass != NULL);
    curr_stat = ip_reassembly_get_stat(ip_reass);
    EXPECT_TRUE(curr_stat != NULL);
    expect_stat = {
        0, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag1
    packet_parse(&frag_pkt1, (const char *)frag1, sizeof(frag1));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt1, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        1, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        1, 0, 1, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    struct packet *pkt = NULL;
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt);
    packet_free(pkt);
    expect_stat = {
        1, 0, 1,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        1, 1, 1, 0, 1, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    ip_reassembly_free(ip_reass);
}
#endif

#if 1
TEST(IPV4_REASSEMBLE, DUP_FIRST_FRAG)
{
    struct packet frag_pkt1 = {};
    struct packet frag_pkt2 = {};
    struct packet *defrag_pkt = NULL;
    struct ip_reassembly *ip_reass;
    struct ip_reassembly_stat *curr_stat;
    struct ip_reassembly_stat expect_stat;

    ip_reass = ip_reassembly_new(1, 1024, 64);
    EXPECT_TRUE(ip_reass != NULL);
    curr_stat = ip_reassembly_get_stat(ip_reass);
    EXPECT_TRUE(curr_stat != NULL);
    expect_stat = {
        0, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag1
    packet_parse(&frag_pkt1, (const char *)frag1, sizeof(frag1));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt1, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        1, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        1, 0, 1, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag1
    packet_parse(&frag_pkt2, (const char *)frag1, sizeof(frag1));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt2, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        1, 0, 1,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 1, 1, 0, 0, 0, 1, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    struct packet *pkt = NULL;
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt);
    packet_free(pkt);
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt);
    packet_free(pkt);
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt == NULL);
    expect_stat = {
        1, 0, 1,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 1, 1, 0, 0, 0, 1, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    ip_reassembly_free(ip_reass);
}
#endif

#if 1
TEST(IPV4_REASSEMBLE, DUP_LAST_FRAG)
{
    struct packet frag_pkt1 = {};
    struct packet frag_pkt2 = {};
    struct packet *defrag_pkt = NULL;
    struct ip_reassembly *ip_reass;
    struct ip_reassembly_stat *curr_stat;
    struct ip_reassembly_stat expect_stat;

    ip_reass = ip_reassembly_new(1, 1024, 64);
    EXPECT_TRUE(ip_reass != NULL);
    curr_stat = ip_reassembly_get_stat(ip_reass);
    EXPECT_TRUE(curr_stat != NULL);
    expect_stat = {
        0, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag2
    packet_parse(&frag_pkt1, (const char *)frag2, sizeof(frag2));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt1, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        1, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        1, 0, 1, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // frag2
    packet_parse(&frag_pkt2, (const char *)frag2, sizeof(frag2));
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt2, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        1, 0, 1,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 1, 1, 0, 0, 0, 1, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    struct packet *pkt = NULL;
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt);
    packet_free(pkt);
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt);
    packet_free(pkt);
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt == NULL);
    expect_stat = {
        1, 0, 1,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 1, 1, 0, 0, 0, 1, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    ip_reassembly_free(ip_reass);
}
#endif

#if 1
TEST(IPV4_REASSEMBLE, FULL)
{
    struct packet frag_pkt1 = {};
    struct packet frag_pkt2 = {};
    struct packet frag_pkt3 = {};
    struct packet *defrag_pkt = NULL;
    struct ip_reassembly *ip_reass;
    struct ip_reassembly_stat *curr_stat;
    struct ip_reassembly_stat expect_stat;

    ip_reass = ip_reassembly_new(1, 2, 64);
    EXPECT_TRUE(ip_reass != NULL);
    curr_stat = ip_reassembly_get_stat(ip_reass);
    EXPECT_TRUE(curr_stat != NULL);
    expect_stat = {
        0, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    char dup1[sizeof(frag1)] = {0};
    char dup2[sizeof(frag1)] = {0};
    char dup3[sizeof(frag1)] = {0};

    memcpy(dup1, frag1, sizeof(frag1));
    memcpy(dup2, frag1, sizeof(frag1));
    memcpy(dup3, frag1, sizeof(frag1));

    // flow1
    packet_parse(&frag_pkt1, (const char *)dup1, sizeof(dup1));
    packet_overwrite_v4_saddr(&frag_pkt1, 1);
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt1, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        1, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        1, 0, 1, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // flow2
    packet_parse(&frag_pkt2, (const char *)dup2, sizeof(dup2));
    packet_overwrite_v4_saddr(&frag_pkt2, 2);
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt2, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        2, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        2, 0, 2, 0, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    // flow3
    packet_parse(&frag_pkt3, (const char *)dup3, sizeof(dup3));
    packet_overwrite_v4_saddr(&frag_pkt3, 3);
    defrag_pkt = ip_reassembly_defrag(ip_reass, &frag_pkt3, 1);
    EXPECT_TRUE(defrag_pkt == NULL);
    expect_stat = {
        2, 0, 0,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        3, 0, 2, 1, 0, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    struct packet *pkt = NULL;
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt);
    packet_free(pkt);
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt);
    packet_free(pkt);
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt);
    packet_free(pkt);
    pkt = ip_reassembly_clean(ip_reass, 2);
    EXPECT_TRUE(pkt == NULL);
    expect_stat = {
        2, 0, 2,                // ip4: defrags_expected, defrags_succeed, defrags_failed
        3, 2, 2, 1, 2, 0, 0, 0, // ip4: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
        0, 0, 0,                // ip6: defrags_expected, defrags_succeed, defrags_failed
        0, 0, 0, 0, 0, 0, 0, 0  // ip6: frags, frags_freed, frags_buffered, frags_no_buffer, timeout, invalid_length, overlap, too_many
    };
    stat_cmp(curr_stat, &expect_stat);

    ip_reassembly_free(ip_reass);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
