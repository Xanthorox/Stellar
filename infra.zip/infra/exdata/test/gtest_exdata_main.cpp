#pragma GCC diagnostic ignored "-Wunused-parameter"

#include <gtest/gtest.h>


#include "exdata_internal.h"

/******************************************
 * TEST EXDATA SCHEMA *
 ******************************************/
void gtest_mock_free(int idx, void *ex_ptr, void *arg){};
void gtest_mock_overwirte_free(int idx, void *ex_ptr, void *arg){};

TEST(exdata_schema, basic_new_index)
{
    struct exdata_schema *schema=exdata_schema_new();
	int exdata_idx=exdata_schema_new_index(schema, "gtest", gtest_mock_free,
                                NULL);
	EXPECT_GE(exdata_idx, 0);
    EXPECT_EQ(exdata_schema_get_idx_by_name(schema, "gtest"), exdata_idx);								
    EXPECT_EQ(exdata_schema_get_idx_by_name(schema, "error"), -1);								
    exdata_schema_free(schema);
}

TEST(exdata_schema, exdata_new_index_overwrite) {
	struct exdata_schema *schema=exdata_schema_new();
	const char *exdata_name="PACKET_EXDATA";
	int exdata_idx=exdata_schema_new_index(schema,exdata_name, gtest_mock_free, NULL);
	EXPECT_GE(exdata_idx, 0);

	int overwrite_idx=exdata_schema_new_index(schema,exdata_name, gtest_mock_overwirte_free, schema);
	EXPECT_GE(overwrite_idx, 0);
	EXPECT_EQ(overwrite_idx, exdata_idx);

    {
        SCOPED_TRACE("White-box test, check stellar internal schema");
        struct exdata_meta *exdata_schema = (struct exdata_meta *)utarray_eltptr(
            schema->exdata_meta_array, (unsigned int)exdata_idx);
        EXPECT_EQ(exdata_schema->free_func, (void *)gtest_mock_overwirte_free);
        EXPECT_EQ(exdata_schema->free_arg, schema);
        EXPECT_EQ(exdata_schema->idx, exdata_idx);
        EXPECT_STREQ(exdata_schema->name, exdata_name);

        int exdata_num = utarray_len(schema->exdata_meta_array);
        EXPECT_EQ(exdata_num, 1);
    }

	EXPECT_EQ(exdata_schema_get_idx_by_name(schema, exdata_name), exdata_idx);								
    EXPECT_EQ(exdata_schema_get_idx_by_name(schema, "error"), -1);	

    exdata_schema_free(schema);
}

/******************************************
 * TEST EXDATA RUNTIME *
 ******************************************/

struct gtest_exdata_runtime_env
{
	int exdata_free_called;
};

void gtest_exdata_runtime_free(int idx, void *ex_ptr, void *arg)
{
	struct gtest_exdata_runtime_env *env=(struct gtest_exdata_runtime_env *)arg;
	env->exdata_free_called++;
}

TEST(exdata_runtime, basic_set_get)
{
	gtest_exdata_runtime_env env={};
    struct exdata_schema *schema=exdata_schema_new();
	int exdata_idx=exdata_schema_new_index(schema, "gtest", gtest_exdata_runtime_free,
                                &env);
	struct exdata_runtime *exdata_rt=exdata_runtime_new(schema);

	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx), (void *)0);//default value null

	EXPECT_EQ(exdata_set(exdata_rt, exdata_idx, (void *)1), 0);
	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx), (void *)1);

	EXPECT_EQ(exdata_set(exdata_rt, exdata_idx, (void *)2), 0);
	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx), (void *)2);

	exdata_runtime_reset(exdata_rt);//call free_func, and set ex_ptr to NULL
	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx), (void *)0);

	EXPECT_EQ(exdata_set(exdata_rt, exdata_idx, (void *)3), 0);
	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx), (void *)3);

	exdata_runtime_free(exdata_rt);
    exdata_schema_free(schema);

	EXPECT_EQ(env.exdata_free_called, 2);//runtime_reset_cnt+runtime_free
}

TEST(exdata_runtime, illegal_set_get)
{
	gtest_exdata_runtime_env env={};
    struct exdata_schema *schema=exdata_schema_new();
	int exdata_idx=exdata_schema_new_index(schema, "gtest", gtest_exdata_runtime_free,
                                &env);
	struct exdata_runtime *exdata_rt=exdata_runtime_new(schema);

	EXPECT_EQ(exdata_set(exdata_rt, -1, (void *)1), -1);//illegal idx
	EXPECT_EQ(exdata_set(exdata_rt, exdata_idx+10, (void *)1), -1);//illegal idx

	EXPECT_EQ(exdata_get(exdata_rt, -1), (void *)0);//illegal idx
	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx+10), (void *)0);//illegal idx
	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx), (void *)0);//default value null

	EXPECT_EQ(exdata_set(exdata_rt, exdata_idx, (void *)1), 0);
	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx), (void *)1);
	
	exdata_runtime_reset(exdata_rt);//call free_func, and set ex_ptr to NULL

	EXPECT_EQ(exdata_get(exdata_rt, exdata_idx), (void *)0);

	exdata_runtime_free(exdata_rt);
    exdata_schema_free(schema);

	EXPECT_EQ(env.exdata_free_called, 1);
}

/**********************************************
 * GTEST MAIN *
 **********************************************/

int main(int argc, char ** argv)
{
	int ret=0;
	::testing::InitGoogleTest(&argc, argv);
	ret=RUN_ALL_TESTS();
	return ret;
}