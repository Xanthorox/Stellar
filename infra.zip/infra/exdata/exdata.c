#include "stellar/utils.h"

#include "exdata_internal.h"


/*******************************
 * STELLAR EXDATA SCHEMA API*
 *******************************/

struct exdata_schema *exdata_schema_new()
{
	struct exdata_schema *s = CALLOC(struct exdata_schema, 1);
	return s;
}

void exdata_schema_free(struct exdata_schema *s)
{
	if(s==NULL)return;
	if(s->exdata_meta_array)
	{
		utarray_free(s->exdata_meta_array);
	}
	FREE(s);
}

int exdata_schema_get_idx_by_name(struct exdata_schema *schema, const char *name)
{
	if(schema==NULL || schema->exdata_meta_array == NULL || name == NULL)return -1;
	unsigned int len = utarray_len(schema->exdata_meta_array);
	struct exdata_meta *t_schema;
	for(unsigned int i = 0; i < len; i++)
	{
		t_schema = (struct exdata_meta *)utarray_eltptr(schema->exdata_meta_array, i);
		if(strcmp(t_schema->name, name) == 0)
		{
			return t_schema->idx;
		}
	}
	return -1;
}

static void stellar_exdata_met_copy(void *_dst, const void *_src)
{
    struct exdata_meta *dst = (struct exdata_meta *)_dst, *src = (struct exdata_meta *)_src;
    dst->free_func = src->free_func;
    dst->free_arg = src->free_arg;
    dst->idx = src->idx;
    dst->name = src->name ? strdup(src->name) : NULL;
}

static void stellar_exdata_met_dtor(void *_elt)
{
    struct exdata_meta *elt = (struct exdata_meta *)_elt;
    if (elt->name)
        FREE(elt->name);
}

UT_icd stellar_exdata_meta_icd = {sizeof(struct exdata_meta), NULL, stellar_exdata_met_copy, stellar_exdata_met_dtor};

int exdata_schema_new_index(struct exdata_schema *s, const char *name, exdata_free *free_func,void *free_arg) 
{
	if(s==NULL || name==NULL)return -1;
	if(s->exdata_meta_array == NULL)
	{
		utarray_new(s->exdata_meta_array, &stellar_exdata_meta_icd);
	}
	if(s->exdata_meta_array == NULL)return -1;
	unsigned int len = utarray_len(s->exdata_meta_array);
	struct exdata_meta *t_schema;
	for(unsigned int i = 0; i < len; i++)
	{
		t_schema = (struct exdata_meta *)utarray_eltptr(s->exdata_meta_array, i);
		if(strcmp(t_schema->name, name) == 0)
		{
			t_schema->free_func=free_func;
			t_schema->free_arg=free_arg;
			return t_schema->idx;
		}
	}
	struct exdata_meta new_schema;
	memset(&new_schema, 0, sizeof(struct exdata_schema));
	new_schema.free_func=free_func;
	new_schema.name=(char *)name;
	new_schema.idx=len;
	new_schema.free_arg=free_arg;
	utarray_push_back(s->exdata_meta_array, &new_schema);
	return new_schema.idx;
}

/*******************************
 * STELLAR EXDATA HANDLE API *
 *******************************/
struct exdata_runtime *exdata_runtime_new(struct exdata_schema *s)
{
	if(s==NULL || s->exdata_meta_array==NULL)return NULL;
	struct exdata_runtime *h = CALLOC(struct exdata_runtime, 1);
	h->schema=s;
	unsigned int len = utarray_len(s->exdata_meta_array);
	if(len > 0)
	{
		h->exdata_array=CALLOC(struct exdata, len);
	}
	return h;
}

void exdata_runtime_reset(struct exdata_runtime *h)
{
	if(h==NULL||h->schema==NULL||h->exdata_array==NULL)return;
	unsigned int len=utarray_len(h->schema->exdata_meta_array);
	for (unsigned int i = 0; i < len; i++)
	{
		void *exdata = (h->exdata_array + i)->exdata;
		(h->exdata_array + i)->state=EXIT;
		struct exdata_meta *schema = (struct exdata_meta *)utarray_eltptr(h->schema->exdata_meta_array, i);
		if (exdata)
		{
			if (schema->free_func)
			{
				schema->free_func(i, exdata, schema->free_arg);
				(h->exdata_array + i)->exdata=NULL;
			}
		}
		(h->exdata_array + i)->state=INIT;
	}
	return;
}

void exdata_runtime_free(struct exdata_runtime *h)
{
	if(h==NULL)return;
	exdata_runtime_reset(h);
	if(h->exdata_array)FREE(h->exdata_array);	
	FREE(h);
}


int exdata_set(struct exdata_runtime *h, int idx, void *ex_ptr)
{
	if(h==NULL || h->schema == NULL|| h->exdata_array == NULL || idx<0)return -1;
	unsigned int len=utarray_len(h->schema->exdata_meta_array);
	if(len < (unsigned int)idx)return -1;
	if((h->exdata_array+idx)->state == EXIT)return -1;
	(h->exdata_array+idx)->exdata=ex_ptr;
	return 0;
}

void *exdata_get(struct exdata_runtime *h, int idx)
{
	if(h==NULL || h->schema == NULL|| h->exdata_array == NULL)return NULL;
	unsigned int len = utarray_len(h->schema->exdata_meta_array);
	if(len < (unsigned int)idx)return NULL;
	if((h->exdata_array+idx)->state == EXIT)return NULL;
	return (h->exdata_array+idx)->exdata;
}