#pragma once

#include "uthash/utarray.h"

#include "stellar/exdata.h"

struct exdata_schema
{
	UT_array *exdata_meta_array;
};

struct exdata_meta
{
	char *name;
	exdata_free *free_func;
	
	void *free_arg;
	int idx;
}__attribute__((aligned(sizeof(void*))));


enum exdata_state
{ INIT, ACTIVE, EXIT };

struct exdata
{
	void *exdata;
	enum exdata_state state;
};

struct exdata_runtime
{
	struct exdata_schema *schema;
	struct exdata *exdata_array;
};