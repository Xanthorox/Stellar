#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdint.h>
#include <stdbool.h>
#include "stellar/session.h"

#if 0
struct tcp_segment
{
     uint32_t len;
     const void *data;
     struct tcp_segment *next;
};
#endif

struct tcp_segment *tcp_segment_new(uint32_t seq, const void *data, uint32_t len);
void tcp_segment_free(struct tcp_segment *seg);
void tcp_segment_set_user_data(struct tcp_segment *seg, void *user_data);
void *tcp_segment_get_user_data(const struct tcp_segment *seg);

struct tcp_reassembly *tcp_reassembly_new(uint64_t max_timeout, uint64_t max_seg_num);
void tcp_reassembly_free(struct tcp_reassembly *tcp_reass);

/*
 * return:  1: push tcp segment success (segment overlap)
 * return:  0: push tcp segment success
 * return: -1: push tcp segment failed (no space)
 * return: -2: push tcp segment failed (segment repeat)
 */
int tcp_reassembly_push(struct tcp_reassembly *tcp_reass, struct tcp_segment *seg, uint64_t now);
struct tcp_segment *tcp_reassembly_pop(struct tcp_reassembly *tcp_reass);
struct tcp_segment *tcp_reassembly_expire(struct tcp_reassembly *tcp_reass, uint64_t now);

void tcp_reassembly_inc_recv_next(struct tcp_reassembly *tcp_reass, uint32_t offset);
void tcp_reassembly_set_recv_next(struct tcp_reassembly *tcp_reass, uint32_t seq);
uint32_t tcp_reassembly_get_recv_next(struct tcp_reassembly *tcp_reass);

/*
 * The next routines deal with comparing 32 bit unsigned ints
 * and worry about wraparound (automatic with unsigned arithmetic).
 */

static inline bool uint32_before(uint32_t seq1, uint32_t seq2)
{
     return (int32_t)(seq1 - seq2) < 0;
}

static inline uint32_t uint32_add(uint32_t seq, uint32_t inc)
{
     if (seq > UINT32_MAX - inc)
     {
          seq = ((uint64_t)seq + (uint64_t)inc) % (4294967296);
     }
     else
     {
          seq += inc;
     }

     return seq;
}

#ifdef __cplusplus
}
#endif
