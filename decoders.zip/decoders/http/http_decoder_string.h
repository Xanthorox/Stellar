#pragma once

#include "stellar/http.h"

enum string_state {
    STRING_STATE_INIT,
    STRING_STATE_REFER,
    STRING_STATE_CACHE,
    STRING_STATE_COMMIT,
};

/* state transition diagram
 *       +----------+
 *       |          |
 *      \|/         |
 *    +------+      |
 *    | init |      |
 *    +------+      |
 *       |          |
 * +---->|          |
 * |    \|/         |
 * |  +-------+     |
 * |  | refer |--+  |
 * |  +-------+  |  |
 * |     |       |  |
 * |    \|/      |  |
 * |  +-------+  |  |
 * +--| cache |  |  |
 *    +-------+  |  |
 *       |       |  |
 *       |<------+  |
 *      \|/         |
 *    +--------+    |
 *    | commit |    |
 *    +--------+    |
 *       |          |
 *      \|/         |
 *    +--------+    |
 *    | reset  |----+
 *    +--------+
 */


//http decoder string
struct http_decoder_string {
    hstring refer; // shallow copy
    hstring cache; // deep copy
    hstring commit;

    enum string_state state;
    size_t max_cache_size;
};

void http_decoder_string_refer(struct http_decoder_string *rstr,
                               const char *at, size_t length);

void http_decoder_string_cache(struct http_decoder_string *rstr);

void http_decoder_string_commit(struct http_decoder_string *rstr);

void http_decoder_string_reset(struct http_decoder_string *rstr);

void http_decoder_string_init(struct http_decoder_string *rstr,
                              size_t max_cache_size);

void http_decoder_string_reinit(struct http_decoder_string *rstr);

enum string_state http_decoder_string_state(const struct http_decoder_string *rstr);

int http_decoder_string_get(const struct http_decoder_string *rstr, char **name, size_t *name_len);

void http_decoder_string_dump(struct http_decoder_string *rstr, const char *desc);
 