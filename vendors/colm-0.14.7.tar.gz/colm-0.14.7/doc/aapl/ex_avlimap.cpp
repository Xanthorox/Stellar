#include "avlimap.h"

int main()
{
	AvliMap< char *, int, CmpStr > avlmap;
	avlmap.insert( "the key", 1 );
	return 0;
}
