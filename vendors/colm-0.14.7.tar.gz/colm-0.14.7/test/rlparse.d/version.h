#define VERSION "7.0.0.8"
#define PUBDATE "July 2016"
