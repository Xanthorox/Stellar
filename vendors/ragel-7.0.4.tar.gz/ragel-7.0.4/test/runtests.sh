#!/bin/bash

# Using the colm test driver.
bash @COLM_SHARE@/runtests "$@"

