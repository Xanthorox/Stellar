# dude, this is a comment
 # some more
hello
def dude():
    yes
    awesome;

    # Here we have a comment
    def realy_awesome(): # hi there
      in_more

      same_level 
      def one_liner(): first; second # both inside one_liner

    back_down

last_statement

# dude, this is a comment
 # some more
hello
if 1:
    yes
    awesome;

    # Here we have a comment
    if ('hello'): # hi there
      in_more

      same_level 
      if ['dude', 'dudess'].horsie(): first; second # both inside one_liner
      1

    back_down

last_statement

hello = 1.1(20);

# subscription
a[1] = b[2];

# simple slicing
c[1:1] = d[2:2];

# simple slicing
e[1:1, 2:2] = f[3:3, 4:4];
