#include <gtest/gtest.h>

#include "log_internal.h"

#if 1
TEST(LOG, STDERR)
{
    char buffer[1024] = {0};
    const char *config = "./conf/log_stderr.toml";
    snprintf(buffer, sizeof(buffer), "sed -i 's/DEBUG/ERROR/g' %s", config);
    struct logger *logger = log_new(config);
    EXPECT_TRUE(logger);

    STELLAR_LOG_TRACE(logger, "test", "test log 1");
    STELLAR_LOG_DEBUG(logger, "test", "test log 1");
    STELLAR_LOG_INFO(logger, "test", "test log 1");
    STELLAR_LOG_WARN(logger, "test", "test log 1");
    STELLAR_LOG_ERROR(logger, "test", "test log 1");
    STELLAR_LOG_FATAL(logger, "test", "test log 1");

    system(buffer);
    log_reload_level(logger);

    STELLAR_LOG_TRACE(logger, "test", "test log 2");
    STELLAR_LOG_DEBUG(logger, "test", "test log 2");
    STELLAR_LOG_INFO(logger, "test", "test log 2");
    STELLAR_LOG_WARN(logger, "test", "test log 2");
    STELLAR_LOG_ERROR(logger, "test", "test log 2");
    STELLAR_LOG_FATAL(logger, "test", "test log 2");

    log_free(logger);
}
#endif

#if 1
TEST(LOG, FILE)
{
    char buffer[1024] = {0};
    const char *config = "./conf/log_file.toml";
    snprintf(buffer, sizeof(buffer), "sed -i 's/DEBUG/ERROR/g' %s", config);
    struct logger *logger = log_new(config);
    EXPECT_TRUE(logger);

    STELLAR_LOG_TRACE(logger, "test", "test log 1");
    STELLAR_LOG_DEBUG(logger, "test", "test log 1");
    STELLAR_LOG_INFO(logger, "test", "test log 1");
    STELLAR_LOG_WARN(logger, "test", "test log 1");
    STELLAR_LOG_ERROR(logger, "test", "test log 1");
    STELLAR_LOG_FATAL(logger, "test", "test log 1");

    system(buffer);
    log_reload_level(logger);

    STELLAR_LOG_TRACE(logger, "test", "test log 2");
    STELLAR_LOG_DEBUG(logger, "test", "test log 2");
    STELLAR_LOG_INFO(logger, "test", "test log 2");
    STELLAR_LOG_WARN(logger, "test", "test log 2");
    STELLAR_LOG_ERROR(logger, "test", "test log 2");
    STELLAR_LOG_FATAL(logger, "test", "test log 2");

    log_free(logger);
}
#endif

// disable this test case because it will change the system date
#if 0
TEST(LOG, REOPEN)
{
    char buffer1[1024] = "date \"+%Y-%m-%d\" >> .date.txt";
    char buffer2[1024] = "date -s 2099/01/01";
    char buffer3[1024] = "cat .date.txt | xargs date -s && rm .date.txt";
    const char *config = "./conf/log_file.toml";

    system(buffer1); // record current date

    EXPECT_TRUE(log_init(config) == 0);

    for (int i = 0; i < 3; i++)
    {
        STELLAR_LOG_TRACE(logger, "test", "test log %d", i);
        STELLAR_LOG_DEBUG(logger, "test", "test log %d", i);
        STELLAR_LOG_INFO(logger, "test", "test log %d", i);
        STELLAR_LOG_WARN(logger, "test", "test log %d", i);
        STELLAR_LOG_ERROR(logger, "test", "test log %d", i);
        STELLAR_LOG_FATAL(logger, "test", "test log %d", i);
        if (i == 1)
        {
            system(buffer2); // set date to 2099/01/01
        }
        else if (i == 2)
        {
            system(buffer3); // recover date
        }
    }

    log_free(logger);
}
#endif

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
