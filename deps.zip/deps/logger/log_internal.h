#pragma once

#ifdef __cplusplus
extern "C"
{
#endif

#include "stellar/log.h"

extern __thread struct logger *__thread_local_logger;

struct logger *log_new(const char *toml_file);
void log_free(struct logger *logger);
void log_reload_level(struct logger *logger);

#ifdef __cplusplus
}
#endif
