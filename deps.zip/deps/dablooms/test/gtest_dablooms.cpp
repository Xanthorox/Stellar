#include <gtest/gtest.h>

#include "dablooms.h"

struct packet_idetify
{
    unsigned int tcp_seq;
    unsigned int tcp_ack;
    unsigned short sport;
    unsigned short dport;
    unsigned short checksum;
    unsigned short ip_id;
    unsigned int ip_src;
    unsigned int ip_dst;
} __attribute__((packed, aligned(1)));

struct packet_idetify idetify = {
    .tcp_seq = 2172673142,
    .tcp_ack = 2198097831,
    .sport = 46582,
    .dport = 443,
    .checksum = 0x2c4b,
    .ip_id = 65535,
    .ip_src = 123456,
    .ip_dst = 789000,
};

TEST(DABLOOMS, TEST)
{
    struct expiry_dablooms_handle *handle = expiry_dablooms_new(1000000, 0.00001, 1, 3);
    EXPECT_TRUE(handle != nullptr);

    EXPECT_TRUE(expiry_dablooms_search(handle, (const char *)&idetify, sizeof(idetify), 1) != 1); // no exist
    EXPECT_TRUE(expiry_dablooms_add(handle, (const char *)&idetify, sizeof(idetify), 1) == 0);    // add
    EXPECT_TRUE(expiry_dablooms_search(handle, (const char *)&idetify, sizeof(idetify), 1) == 1); // exist
    EXPECT_TRUE(expiry_dablooms_search(handle, (const char *)&idetify, sizeof(idetify), 2) == 1); // exist
    EXPECT_TRUE(expiry_dablooms_search(handle, (const char *)&idetify, sizeof(idetify), 3) == 1); // exist
    EXPECT_TRUE(expiry_dablooms_search(handle, (const char *)&idetify, sizeof(idetify), 4) == 0); // not exist
    EXPECT_TRUE(expiry_dablooms_search(handle, (const char *)&idetify, sizeof(idetify), 5) == 0); // not exist

    expiry_dablooms_free(handle);
}

int main(int argc, char **argv)
{
    ::testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
