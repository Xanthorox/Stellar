#pragma once

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C"
{
#endif

/***********************************
 * utable_kv *
 ***********************************/

enum utable_value_type
{
    utable_value_type_undefined = 0,
    utable_value_type_cstring,
    utable_value_type_blob,
    utable_value_type_integer,
    utable_value_type_integer_array,
    utable_value_type_cstring_array
};

struct utable_kv {
    char *key;
    size_t key_sz;
    enum utable_value_type value_type;
    size_t value_sz;
    union {
        struct 
        {
            char *cstring;
            size_t cstring_sz;
        };
        struct
        {
            char *blob;
            size_t blob_sz;
        };
        struct
        {
            int64_t *interger_array;
            size_t n_integer;
        };
        struct
        {
            char **cstring_array;
            size_t *cstring_array_sz;
            size_t n_cstring;
        };        
        int64_t integer;
    };
};

struct utable_kv *utable_kv_new_with_cstring(const char *key, size_t key_sz, const char *value, size_t value_sz);
struct utable_kv *utable_kv_new_with_blob(const char *key, size_t key_sz, const char *blob, size_t blob_sz);
struct utable_kv *utable_kv_new_with_integer(const char *key, size_t key_sz, int64_t value);
struct utable_kv *utable_kv_new_with_integer_array(const char *key, size_t key_sz, int64_t value[], size_t n_value);
struct utable_kv *utable_kv_new_with_cstring_array(const char *key, size_t key_sz, const char* value[], size_t value_sz[], size_t n_value);

void utable_kv_free(struct utable_kv *kv);
struct utable_kv *utable_kv_duplicate(const struct utable_kv *kv);


/***********************************
 * utable API *
 ***********************************/

struct utable;
struct utable *utable_new(void);
struct utable *utable_new_with_size(size_t sz);
void utable_free(struct utable *table);

void utable_add_kv(struct utable *table, struct utable_kv *kv);
void utable_add_kv_array(struct utable *table, struct utable_kv *kv_array, size_t n_kv);

struct utable_kv *utable_get0_kv(struct utable *table, const char *key, size_t key_sz);
struct utable_kv *utable_next_kv(struct utable *table);

void utable_add_cstring(struct utable *table, const char *key, const char *value, size_t value_sz);
void utable_add_blob(struct utable *table, const char *key, const char *blob, size_t blob_sz);
void utable_add_integer(struct utable *table, const char *key, int64_t value);
void utable_add_integer_array(struct utable *table, const char *key, int64_t value_array[], size_t n_value);
void utable_add_cstring_array(struct utable *table, const char *key, const char* value_array[], size_t value_sz[], size_t n_value);
void utable_delete(struct utable *table, const char *key, size_t key_sz);


void utable_reset_iter(struct utable *table);
const char *utable_next_key(struct utable *table);
enum utable_value_type utable_get_value_type(const struct utable *table, const char *key);
int utable_get0_blob_value(const struct utable *table, const char *key, char **value, size_t *value_len);
int utable_get0_cstring_value(const struct utable *table, const char *key, char **value, size_t *value_len);
int utable_get0_integer_value(const struct utable *table, const char *key, int64_t *value);
int utable_get0_integer_value_array(const struct utable *table, const char *key, int64_t **value_array, size_t *n_value);
int utable_get0_cstring_value_array(const struct utable *table, const char *key, char ***value_array, size_t **value_len, size_t *n_value);

struct utable *utable_duplicate(const struct utable *table);
int utable_union(struct utable *dst, const struct utable *src);

void utable_serialize(const struct utable *table, char **blob, size_t *blob_len);
struct utable *utable_deserialize(const char *blob, size_t blob_len);

struct utable_stat
{
    size_t n_item;
    size_t n_item_size;
    size_t n_blob;
    size_t n_blob_size;
    size_t n_cstring;
    size_t n_cstring_size;
    size_t n_integer;
    size_t n_integer_size;
    size_t n_integer_array;
    size_t n_integer_array_size;
    size_t n_cstring_array;
    size_t n_cstring_array_size;
};

void utable_stat(struct utable *table, struct utable_stat *stat);

/***********************************
 * utable exporter API *
 ***********************************/

struct ipfix_exporter_schema;

// |domain_id|work_id|=source_id (16+16) domain_id is identifier of exporter instance
struct ipfix_exporter_schema *utable_ipfix_exporter_schema_new(const char *ipfix_schema_json_path, uint16_t domain_id, uint16_t n_worker);  
void utable_ipfix_exporter_schema_free(struct ipfix_exporter_schema *ipfix_schema);

uint32_t utable_ipfix_template_flow_refresh_interval_s(struct ipfix_exporter_schema *ipfix_schema);
const char *utable_ipfix_template_flow_get0(struct ipfix_exporter_schema *ipfix_schema, uint16_t worker_id, size_t *blob_len);

// return template id, -1 if not found
int utable_ipfix_template_get(struct ipfix_exporter_schema *ipfix_schema, const char *template_name);
int utable_ipfix_data_flow_exporter(const struct utable *table, struct ipfix_exporter_schema *ipfix_schema, int template_id, uint16_t worker_id, char **blob, size_t *blob_len);


int utable_json_export(const struct utable *table, char **blob, size_t *blob_len);
int utable_msgpack_export(const struct utable *table, char **blob, size_t *blob_len);

#ifdef __cplusplus
}
#endif