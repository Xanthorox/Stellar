#pragma once

#include <stdlib.h>

/*  ======================================
 *  ++++++++  Library Open API  ++++++++++
 *  ======================================
 */

struct nmx_pool_s;
typedef struct nmx_pool_s nmx_pool_t;

void *nmx_alloc (size_t size);

void *nmx_calloc (size_t size);

nmx_pool_t *nmx_create_pool (size_t size);

void nmx_destroy_pool (nmx_pool_t *pool);

void nmx_reset_pool (nmx_pool_t *pool);

void *nmx_palloc (nmx_pool_t *pool, size_t size);

void *nmx_pnalloc (nmx_pool_t *pool, size_t size);

void *nmx_prealloc (nmx_pool_t *pool, void *p, size_t size);

void *nmx_pcalloc (nmx_pool_t *pool, size_t size);

void *nmx_pmemalign (nmx_pool_t *pool, size_t size, size_t alignment);

int nmx_pfree (nmx_pool_t *pool, void *p);


