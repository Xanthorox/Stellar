#pragma once 

#include <stddef.h>

struct  mem_pool_s;
typedef struct mem_pool_s mem_pool_t;

mem_pool_t *create_mem_pool(size_t pool_size);
void destroy_mem_pool(mem_pool_t *mem_pool);

void *mem_alloc(mem_pool_t *mem_pool, size_t size);
void mem_free(mem_pool_t *mem_pool, void *ptr);