#pragma once

#include <stddef.h>
#include <uuid/uuid.h>

struct kv 
{
	char *key;
	size_t key_sz;
    enum 
    {
        KV_VALUE_TYPE_INTEGER,
        KV_VALUE_TYPE_DOUBLE,
        KV_VALUE_TYPE_STRING,
        KV_VALUE_TYPE_UUID,
        KV_VALUE_TYPE_INTERGE_ARRAY,
        KV_VALUE_TYPE_DOUBLE_ARRAY,
        KV_VALUE_TYPE_STRING_ARRAY,
        KV_VALUE_TYPE_UUID_ARRAY
    }vtype;
    union
	{
		long long value_longlong;
		double value_double;
		struct
		{
			char *str;
			size_t sz;
		}value_str;
		uuid_t value_uuid;
		struct 
		{
			long long *elems;
			size_t n_elems;
		}value_interger_array;
		struct 
		{
			double *elems;
			size_t n_elems;
		}value_double_array;
		struct 
		{
			char **elems;
			size_t *sz;
			size_t n_elems;
		}value_str_array;
		struct 
		{
			uuid_t *elems;
			size_t n_elems;
		}value_uuid_array;
/*		
		struct 
		{
			struct kv *elems;
			size_t n_elems;
		}value_list;
*/			
	};
};

struct kv *kv_new_with_interger(const char *key, size_t key_sz, long long value);
struct kv *kv_new_with_double(const char *key, size_t key_sz, double value);
struct kv *kv_new_with_string(const char *key, size_t key_sz, const char *value, size_t value_sz);
struct kv *kv_new_with_uuid(const char *key, size_t key_sz, const uuid_t value);
struct kv *kv_new_with_interger_array(const char *key, size_t key_sz, long long value[], size_t n_value);
struct kv *kv_new_with_double_array(const char *key, size_t key_sz, double value[], size_t n_value);
struct kv *kv_new_with_string_array(const char *key, size_t key_sz, const char* value[], size_t value_sz[], size_t n_value);
struct kv *kv_new_with_uuid_array(const char *key, size_t key_sz, const uuid_t value[], size_t n_value);

struct kv *kv_duplicate(const struct kv *kv);

void kv_free(struct kv *kv);

struct kv_table;

struct kv_table *kv_table_new(size_t initial_size);
void kv_table_free(struct kv_table *table);

//struct kv_table *kv_table_new_by_indexing(struct kv *kv);

int kv_table_add(struct kv_table *table, const struct kv *kv);
int kv_table_del(struct kv_table *table, const char *key, size_t key_sz);

typedef void (kv_ref_cleanup_cb)(const struct kv *kv, void *arg);
int kv_table_add_reference(struct kv_table *table, const struct kv *kv, kv_ref_cleanup_cb *cleanup_cb, void *arg);

const struct kv *kv_table_get0(struct kv_table *table, const char *key, size_t key_sz);

void kv_table_reset_iter(struct kv_table *table);
const struct kv *kv_table_next(struct kv_table *table);

struct kv_table *kv_table_duplicate(const struct kv_table *table);
int kv_table_union(struct kv_table *dst, const struct kv_table *src);

void kv_table_serialize(const struct kv_table *table, char **blob, size_t *blob_len);
struct kv_table *kv_table_deserialize(const char *blob, size_t blob_len);

int kv_table_export_json(const struct kv_table *table, char **blob, size_t *blob_len);
int kv_table_export_msgpack(const struct kv_table *table, char **blob, size_t *blob_len);